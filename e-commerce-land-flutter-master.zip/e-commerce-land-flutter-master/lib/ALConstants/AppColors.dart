import 'package:flutter/material.dart';

class AppColors {
  static const Color basicColor = Color(0xFF45C1A6);
  static const Color secondaryColor = Color(0xFFF7C633);
  static const Color secondaryColor2 = Color(0xFFF7C633);
  static const Color secondaryColor3 = Color(0xFFffe646);
  static const Color secondaryColor4 = Color(0xFFfeea49);

  // FEEE7D
  static const Color whiteColor = Color(0xFFf7f8f8);
  static const Color grayColor = Color(0xFF707070);
  static const Color readColor = Color(0xFFEF4B53);
}
