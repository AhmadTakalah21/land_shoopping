import 'dart:typed_data';

import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:rxdart/rxdart.dart';
class CLNotification {
  static final _note = FlutterLocalNotificationsPlugin();
   static final onNotefaction =BehaviorSubject<String>();
  Future<NotificationDetails>  notificationDetails ({Uint8List? bitmap,String? groupKey,String? id,}) async  {
     AndroidBitmap<Object>? largeIcon = bitmap != null ? ByteArrayAndroidBitmap(bitmap) : null;
// For BigPictureStyleInformation, you can use the same or a different AndroidBitmap object
     BigPictureStyleInformation? bigPictureStyleInformation = bitmap != null
         ? BigPictureStyleInformation(ByteArrayAndroidBitmap(bitmap),largeIcon: largeIcon)
         : null;




    return  NotificationDetails(
      android:  AndroidNotificationDetails(
        id.toString(),
        groupKey.toString(),
        channelDescription: '',
        showProgress: false,
        channelShowBadge: true,
        enableVibration: false,
        enableLights: false,
        playSound: true,
        priority: Priority.max,
        groupKey: groupKey,
        setAsGroupSummary: true,
        visibility: NotificationVisibility.public,
        importance: Importance.high,),
      iOS: const IOSNotificationDetails(),
    );
  }

 Future<void> configuration({Uint8List? bitmap}) async {
    const AndroidInitializationSettings initializationSettingsAndroid =
    AndroidInitializationSettings('@mipmap/ic_launcher');
    const IOSInitializationSettings initializationSettingsIOS =
    IOSInitializationSettings(requestAlertPermission: true, requestBadgePermission: true, requestSoundPermission: true);
    const InitializationSettings initializationSettings =  InitializationSettings(android: initializationSettingsAndroid, iOS: initializationSettingsIOS);
    await _note.initialize(initializationSettings, onSelectNotification: (payload) async{onNotefaction.add(payload!);});
  }
  Future showNote({String? groupKey,required int id  , String? title, String ?body, String ? payload , Uint8List? bitmap}) async {

    _note.show(id, title, body, await notificationDetails(bitmap: bitmap,id: id.toString()),payload:payload );

  }
  Future<void> cancelAllForGroup({required int id})async{
    _note.cancel(id);
  }
  Future<void> cancelAll()async{
    _note.cancelAll();
  }

}