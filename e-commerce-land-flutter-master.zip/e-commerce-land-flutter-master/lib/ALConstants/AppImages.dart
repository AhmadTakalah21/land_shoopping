
// ignore_for_file: non_constant_identifier_names

class AppImages {

  static String background1 = 'assets/images/background1.png';
  static String background2 = 'assets/images/background2.png';
  static String logo2 = 'assets/logo2.png';
}