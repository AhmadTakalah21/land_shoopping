import 'dart:convert';
import 'package:flutter/cupertino.dart';
import 'package:http/http.dart' as https;
import 'package:internet_connection_checker/internet_connection_checker.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/Configuration/config.dart';
import 'package:shopping_land/Model/Repositories/ApiClient/logger.dart';

class ALApiClient {
  static var client = https.Client();
  final LoggerService logger = LoggerService();
  String? methode;
  dynamic bodyData;

  ALApiClient({@required this.methode, @required this.bodyData});

  Future request({
    bool? get,
    bool? isPagination,
    bool? delete,
    bool? isMulti,
  }) async {
    try {
      https.Response response;
      var connectionStatus = await InternetConnectionChecker().connectionStatus;

      if (await InternetConnectionChecker().hasConnection &&
          connectionStatus == InternetConnectionStatus.connected) {
        final Uri uri = Uri.parse("$APIURL$methode")
            .replace(queryParameters: get == true ? bodyData : null);

        if (get != true && delete != true) {
          logger.logNetwork(
            message: "\n--- API Request ---\n"
                "URI: $uri\n"
                "Request Body Data: ${bodyData != null ? 'FormData' : ''}\n"
                "-------------------",
            level: LogLevel.info,
          );
        }

        if (isMulti != null) {
          var request = https.MultipartRequest('POST', uri);

          if (bodyData != null && bodyData is Map<String, dynamic>) {
            bodyData.forEach((key, value) {
              if (value is String) {
                // إضافة الحقول النصية
                request.fields[key] = value;
              } else if (value is https.MultipartFile) {
                // إضافة الملفات
                request.files.add(value);
              } else {
                logger.logDebug(
                  message:
                      "Unsupported value for key: $key -> Type: ${value.runtimeType}",
                );
              }
            });
          } else if (bodyData != null) {
            bodyData.fields.forEach((element) {
              request.fields[element.key] = element.value;
            });
          } else {
            logger.logDebug(
                message: "bodyData is null or not a Map<String, dynamic>.");
          }

          // إضافة الهيدرز
          request.headers.addAll(ALMethode.getApiHeader());

          // طباعة تفاصيل الريكويست
          logger.logNetwork(
            message: "\n--- Request Details ---\n"
                "URI: $uri\n"
                "Headers: ${request.headers}\n"
                "Fields: ${request.fields}\n"
                "Files: ${request.files.map((file) => file.filename)}\n"
                "-------------------------",
            level: LogLevel.info,
          );

          // إرسال الطلب
          var streamedResponse = await request.send();
          response = await https.Response.fromStream(streamedResponse);
        } else if (bodyData != null && get == null && delete == null) {
          // إرسال POST مباشرة مع bodyData كما في النسخة القديمة
          response = await https.post(uri,
              body: bodyData, headers: ALMethode.getApiHeader());
        } else {
          Map<String, String> header = {};
          header.addAll(ALMethode.getApiHeader());
          header.addAll({'Accept': 'application/json'});

          if (delete == null) {
            response = await https.get(uri, headers: header);
          } else {
            response = await https.delete(uri, body: bodyData, headers: header);
          }
        }

        // طباعة الرد بشكل مرتب بدون طباعة مكررة
        logger.logNetwork(
          message: "\n--- API Response ---\n"
              "URI: $uri\n"
              "Response: ${utf8.decode(response.bodyBytes)}\n"
              "-------------------",
          level: LogLevel.info,
        );

        var dataApi = json.decode(utf8.decode(response.bodyBytes));
        if ((dataApi['success'] != null || dataApi['status'] != null) &&
            dataApi['code'] == 401) {
          ALMethode.logout(message: true, messageT: dataApi['message'] ?? '');
          return false;
        }
        if (isPagination != null) {
          return json.encode([
            {
              'status': 1,
              'description': dataApi['message'] ?? '',
              'data':
                  dataApi['data'] != null ? json.encode(dataApi['data']) : null
            }
          ]);
        } else {
          return json.encode([
            {
              'status': ((dataApi['success'] != null && dataApi['success']) ||
                      (dataApi['status'] != null && dataApi['status']) ||
                      dataApi['code'] == 402)
                  ? 1
                  : 0,
              'description': dataApi['message'],
              'data': dataApi['data'] != null
                  ? json.encode(dataApi['data'])
                  : json.encode({'percent': dataApi['percent']})
            }
          ]);
        }
      } else {
        logger.logDebug(message: "No internet connection.");
        return json.encode([
          {'status': 0, 'description': 'no connection internet', 'data': null}
        ]);
      }
    } catch (e) {
      logger.logCatchDebug(
        message: "\n--- API Error ---\n"
            "Error in request.\n"
            "URI: $APIURL$methode\n"
            "Request Body Data: ${json.encode(bodyData)}\n"
            "Error Details: $e\n"
            "-------------------",
        error: e,
      );
      return false;
    }
  }
}
