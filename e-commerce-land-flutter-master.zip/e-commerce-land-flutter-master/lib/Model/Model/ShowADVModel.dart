



import 'dart:convert';

List<ShowADVModel> dataItemStoreCategoryFromJson(var str) => List<ShowADVModel>.from(json.decode(str).map((x) =>
    ShowADVModel.fromJson(x)));




class ShowADVModel {
  int? id;
  String? name;
  String? fromDate;
  String? toDate;
  bool? isActive;
  String? imageUrl;
  Item? item;
  Brand? brand;

  ShowADVModel(
      {this.id,
        this.name,
        this.fromDate,
        this.toDate,
        this.isActive,
        this.imageUrl,
        this.item,
        this.brand});

  ShowADVModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    fromDate = json['from_date'];
    toDate = json['to_date'];
    isActive = json['is_active'];
    imageUrl = json['image_url'];
    item = json['item'] != null ? new Item.fromJson(json['item']) : null;
    brand = json['brand'] != null ? new Brand.fromJson(json['brand']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['from_date'] = this.fromDate;
    data['to_date'] = this.toDate;
    data['is_active'] = this.isActive;
    data['image_url'] = this.imageUrl;
    if (this.item != null) {
      data['item'] = this.item!.toJson();
    }
    if (this.brand != null) {
      data['brand'] = this.brand!.toJson();
    }
    return data;
  }
}

class Item {
  int? id;
  String? name;
  int? price;
  String? brandName;
  int? priceAfterOffer;
  int? isFav;
  int? countFavourites;
  Image? image;

  Item(
      {this.id,
        this.name,
        this.price,
        this.brandName,
        this.priceAfterOffer,
        this.isFav,
        this.countFavourites,
        this.image});

  Item.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    price = json['price'];
    brandName = json['brand_name'];
    priceAfterOffer = json['price_after_offer'];
    isFav = json['is_fav'];
    countFavourites = json['count_favourites'];
    image = json['image'] != null ? new Image.fromJson(json['image']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['price'] = this.price;
    data['brand_name'] = this.brandName;
    data['price_after_offer'] = this.priceAfterOffer;
    data['is_fav'] = this.isFav;
    data['count_favourites'] = this.countFavourites;
    if (this.image != null) {
      data['image'] = this.image!.toJson();
    }
    return data;
  }
}

class Image {
  int? id;
  String? url;

  Image({this.id, this.url});

  Image.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['url'] = this.url;
    return data;
  }
}

class Brand {
  int? id;
  String? name;
  String? urlImage;
  Type? type;
  bool? isActive;
  List<Cities>? cities;


  Brand(
      {this.id,
        this.name,
        this.urlImage,
        this.type,
        this.isActive,
        this.cities,
       });

  Brand.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    urlImage = json['url_image'];
    type = json['type'] != null ? new Type.fromJson(json['type']) : null;
    isActive = json['is_active'];
    if (json['cities'] != null) {
      cities = <Cities>[];
      json['cities'].forEach((v) {
        cities!.add(new Cities.fromJson(v));
      });
    }

  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['url_image'] = this.urlImage;
    if (this.type != null) {
      data['type'] = this.type!.toJson();
    }
    data['is_active'] = this.isActive;
    if (this.cities != null) {
      data['cities'] = this.cities!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Type {
  int? id;
  String? name;
  bool? isActive;

  Type({this.id, this.name, this.isActive});

  Type.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    isActive = json['is_active'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['is_active'] = this.isActive;
    return data;
  }
}

class Cities {
  int? id;
  String? name;
  int? isActive;
  Type? country;

  Cities({this.id, this.name, this.isActive, this.country});

  Cities.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    isActive = json['is_active'];
    country =
    json['country'] != null ? new Type.fromJson(json['country']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['is_active'] = this.isActive;
    if (this.country != null) {
      data['country'] = this.country!.toJson();
    }
    return data;
  }
}

