

import 'dart:convert';

List<OrderModel> dataOrderHistoryMFromJson(var str) =>
    List<OrderModel>.from(json.decode(str).map((x) => OrderModel.fromJson(x)));



enum OrderHistoryStatus
{
  pending,
  delivered,
  canceled,
  unacceptable,
  under_delivery,
  processing
}



class OrderModel {
  int? id;
  int? totalPrice;
  int? discount;
  int? priceAfterDiscount;
  String? expectedDeliveryDate;
  String? status;
  String? reason;
  String? customerName;
  String? customerPhone;
  String? deliveryType;
  String? streetName;

  String? paymentMethodId;
  int? orderNumber;
  List<Cart>? cart;

  OrderModel(
      {this.id,
        this.totalPrice,
        this.discount,
        this.priceAfterDiscount,
        this.expectedDeliveryDate,
        this.status,
        this.reason,
        this.customerName,
        this.streetName,
        this.customerPhone,
        this.deliveryType,
        this.paymentMethodId,
        this.cart});

  OrderModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];


    orderNumber = json['order_number'];
    totalPrice = json['total_price'];
    discount = json['discount'];
    priceAfterDiscount = json['price_after_discount'];
    expectedDeliveryDate = json['expected_delivery_date'];
    status = json['status'];
    reason = json['reason'];
    customerName = json['customer_name'];
    customerPhone = json['customer_phone'];
    streetName = json['street_name'];
    deliveryType = json['delivery_type'];
    paymentMethodId = json['payment_method_id'].toString();
    if (json['cart'] != null) {
      cart = <Cart>[];
      json['cart'].forEach((v) {
        cart!.add(new Cart.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['total_price'] = this.totalPrice;
    data['discount'] = this.discount;
    data['price_after_discount'] = this.priceAfterDiscount;
    data['expected_delivery_date'] = this.expectedDeliveryDate;
    data['status'] = this.status;
    data['reason'] = this.reason;
    data['customer_name'] = this.customerName;
    data['customer_phone'] = this.customerPhone;
    data['delivery_type'] = this.deliveryType;
    data['payment_method_id'] = this.paymentMethodId;
    if (this.cart != null) {
      data['cart'] = this.cart!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Cart {
  int? id;
  int? price;
  int? quantity;
  Item? item;
  List<CartDetail>? cartDetail;

  Cart({this.id, this.price, this.quantity, this.item, this.cartDetail});

  Cart.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    price = json['price'];
    quantity = json['quantity'];
    item = json['item'] != null ? new Item.fromJson(json['item']) : null;
    if (json['cart_detail'] != null) {
      cartDetail = <CartDetail>[];
      json['cart_detail'].forEach((v) {
        cartDetail!.add(new CartDetail.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['price'] = this.price;
    data['quantity'] = this.quantity;
    if (this.item != null) {
      data['item'] = this.item!.toJson();
    }
    if (this.cartDetail != null) {
      data['cart_detail'] = this.cartDetail!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Item {
  int? id;
  String? name;
  int? price;
  String? brandName;
  int? priceAfterOffer;
  int? isFav;
  int? countFavourites;
  Image? image;

  Item(
      {this.id,
        this.name,
        this.price,
        this.brandName,
        this.priceAfterOffer,
        this.isFav,
        this.countFavourites,
        this.image});

  Item.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    price = json['price'];
    brandName = json['brand_name'];
    priceAfterOffer = json['price_after_offer'];
    isFav = json['is_fav'];
    countFavourites = json['count_favourites'];
    image = json['image'] != null ? new Image.fromJson(json['image']) : null;
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['price'] = this.price;
    data['brand_name'] = this.brandName;
    data['price_after_offer'] = this.priceAfterOffer;
    data['is_fav'] = this.isFav;
    data['count_favourites'] = this.countFavourites;
    if (this.image != null) {
      data['image'] = this.image!.toJson();
    }
    return data;
  }
}

class Image {
  int? id;
  String? url;

  Image({this.id, this.url});

  Image.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    url = json['url'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['url'] = this.url;
    return data;
  }
}

class CartDetail {
  String? name;
  List<Measurements>? measurements;

  CartDetail({this.name, this.measurements});

  CartDetail.fromJson(Map<String, dynamic> json) {
    name = json['name'];
    if (json['measurements'] != null) {
      measurements = <Measurements>[];
      json['measurements'].forEach((v) {
        measurements!.add(new Measurements.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['name'] = this.name;
    if (this.measurements != null) {
      data['measurements'] = this.measurements!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Measurements {
  int? id;
  String? name;

  Measurements({this.id, this.name});

  Measurements.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    return data;
  }
}

