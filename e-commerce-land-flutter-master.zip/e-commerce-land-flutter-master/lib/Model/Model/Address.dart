

import 'dart:convert';

List<Address> dataAddressFromJson(var str) =>
    List<Address>.from(
        json.decode(str).map((x) => Address.fromJson(x)));



class Address {
  int? id;
  String? address;
  String? streetName;

  Address({this.id, this.address, this.streetName});

  Address.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    address = json['address'];
    streetName = json['street_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['address'] = this.address;
    data['street_name'] = this.streetName;
    return data;
  }
}

