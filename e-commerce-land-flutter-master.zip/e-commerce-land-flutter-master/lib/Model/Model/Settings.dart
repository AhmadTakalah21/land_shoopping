
import 'dart:convert';

List<Settings> dataSettingsMFromJson(var str) =>
    List<Settings>.from(json.decode(str).map((x) => Settings.fromJson(x)));



class Settings {
  String? email;
  String? twitter;
  String? facebook;
  String? instagram;
  String? number;

  Settings(
      {this.email, this.twitter, this.facebook, this.instagram, this.number});

  Settings.fromJson(Map<String, dynamic> json) {
    email = json['email'];
    twitter = json['twitter'];
    facebook = json['facebook'];
    instagram = json['instagram'];
    number = json['number'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['email'] = this.email;
    data['twitter'] = this.twitter;
    data['facebook'] = this.facebook;
    data['instagram'] = this.instagram;
    data['number'] = this.number;
    return data;
  }
}
