

import 'dart:convert';

List<FiltersModel> dataFiltersModelFromJson(var str) =>
    List<FiltersModel>.from(json.decode(str).map((x) => FiltersModel.fromJson(x)));




class FiltersModel {
  int? id;
  String? name;
  List<Measurements>? measurements;

  FiltersModel({this.id, this.name, this.measurements});

  FiltersModel.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    if (json['measurements'] != null) {
      measurements = <Measurements>[];
      json['measurements'].forEach((v) {
        measurements!.add(new Measurements.fromJson(v));
      });
    }
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    if (this.measurements != null) {
      data['measurements'] = this.measurements!.map((v) => v.toJson()).toList();
    }
    return data;
  }
}

class Measurements {
  int? id;
  String? name;
  String? unitName;

  Measurements({this.id, this.name, this.unitName});

  Measurements.fromJson(Map<String, dynamic> json) {
    id = json['id'];
    name = json['name'];
    unitName = json['unit_name'];
  }

  Map<String, dynamic> toJson() {
    final Map<String, dynamic> data = new Map<String, dynamic>();
    data['id'] = this.id;
    data['name'] = this.name;
    data['unit_name'] = this.unitName;
    return data;
  }
}
