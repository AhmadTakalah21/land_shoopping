import 'dart:ui';

enum CurrencyType { sy }

Locale localTranslations = const Locale('en', '');

const currencyType = CurrencyType.sy;
//const APIURL = "https://shopback.le.sy/customer-api/";
 const APIURL = "http://e-commerce.medical-clinic.serv00.net/customer-api/";
const APIURLFile = "";
//https://api-cashlockv3.watanyia.com/storage/
//https://shopback.le.sy/customer-api/