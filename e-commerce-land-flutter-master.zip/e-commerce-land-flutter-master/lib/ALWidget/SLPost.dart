import 'dart:io';
import 'dart:typed_data';
import 'package:share_plus/share_plus.dart';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter_custom_carousel_slider/flutter_custom_carousel_slider.dart';
import 'package:shopping_land/Services/helper/status_bar.dart';
import 'package:get/get.dart';
import 'package:like_button/like_button.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/ALConstants/AppPages.dart';
import 'package:shopping_land/Model/Model/BrandModel.dart' as brand;
import 'package:shopping_land/Model/Model/OptionWidget.dart' as image;
import 'package:shopping_land/Model/Model/Post.dart';
import 'package:shopping_land/Pages/BuildScreens/Home/Home/Controllers/HomeController.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';

typedef OnLike = void Function(PostModel);

class SLPost extends StatefulWidget {
  PostModel post;
  HomeController controller;
  OnLike onLike;

  SLPost(
      {required this.post,
      required this.onLike,
      required this.controller,
      super.key});

  @override
  State<SLPost> createState() => _SLPostState();
}

class _SLPostState extends State<SLPost> {
  Future<void> shareImagesFromUrls() async {
    if (widget.post.files != null && widget.post.files!.isNotEmpty) {
      try {
        List<XFile> xFiles = [];
        for (var file in widget.post.files!) {
          if (file?.url != null) {
            final response = await http.get(Uri.parse(file!.url!));
            final tempDir = await getTemporaryDirectory();
            final tempFile = File(
                '${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
            await tempFile.writeAsBytes(response.bodyBytes);
            xFiles.add(XFile(tempFile.path));
          }
        }

        if (xFiles.isNotEmpty) {
          await Share.shareXFiles(
            xFiles,
            text: '${widget.post.title}\n${widget.post.description}',
          );
        } else {
          await Share.share('${widget.post.title}\n${widget.post.description}');
        }
      } catch (e) {
        print('Error downloading or sharing files: $e');
        await Share.share('${widget.post.title}\n${widget.post.description}');
      }
    } else {
      await Share.share('${widget.post.title}\n${widget.post.description}');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColors.basicColor.withOpacity(0.1),
      constraints: widget.post.files != null && widget.post.files!.isNotEmpty
          ? null
          : null,
      child: Column(
        mainAxisAlignment:
            widget.post.files != null && widget.post.files!.isNotEmpty
                ? MainAxisAlignment.start
                : MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Align(
              alignment: Alignment.centerRight,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Container(
                      child: Text(
                    widget.post.title.toString(),
                    textAlign: TextAlign.center,
                    maxLines: 2,
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w500,
                        color: Colors.black),
                  )),
                  SizedBox(
                    height: 5,
                  ),
                  Container(
                      child: Text(
                    widget.post.description.toString(),
                    textAlign: TextAlign.center,
                    style: TextStyle(
                        fontSize: 12,
                        fontWeight: FontWeight.w300,
                        color: Colors.black54),
                  )),
                ],
              ),
            ),
          ),
          SizedBox(
            height: 10,
          ),
          if (widget.post.files != null && widget.post.files!.isNotEmpty)
            Padding(
              padding: const EdgeInsets.all(8.0),
              child: CustomCarouselSlider(
                animationDuration: Duration(seconds: 1),
                items: widget.post.files!.isEmpty
                    ? []
                    : widget.post.files!
                        .map((e) => CarouselItem(
                              onImageTap: (v) async {
                                if (widget.post.item != null) {
                                  Get.toNamed(Routes.ItemsDetails,
                                      arguments: image.Items(
                                          id: widget.post.item!.id!,
                                          name: widget.post.item!.name!,
                                          image: image.Image(
                                              id: widget.post.item!.image!.id,
                                              url:
                                                  widget.post.item!.image!.url),
                                          brandName:
                                              widget.post.item!.brandName,
                                          price: widget.post.item!.price,
                                          priceAfterOffer: widget
                                              .post.item!.priceAfterOffer));
                                } else {
                                  if (widget.post.brand != null) {
                                    Get.toNamed(Routes.BrandsDetails,
                                        arguments: brand.BrandModel(
                                            name: widget.post.brand!.name,
                                            id: widget.post.brand!.id,
                                            cities: widget.post.brand!.cities!
                                                .map((e) {
                                              return brand.Cities(
                                                  id: e.id, name: e.name);
                                            }).toList(),
                                            type: widget.post.brand!.type!.name,
                                            urlImage:
                                                widget.post.brand!.urlImage));
                                  } else {
                                    await FlutterStatusbarcolor
                                        .setNavigationBarColor(Colors.black);
                                    await FlutterStatusbarcolor
                                        .setStatusBarColor(Colors.black);
                                    Get.to(Scaffold(
                                      backgroundColor: Colors.black,
                                      appBar: AppBar(
                                          backgroundColor: Colors.black,
                                          elevation: 0),
                                      body: PhotoViewGallery.builder(
                                        scrollPhysics:
                                            const BouncingScrollPhysics(),
                                        itemCount: widget.post.files!.length,
                                        builder:
                                            (BuildContext context, int index) {
                                          return PhotoViewGalleryPageOptions(
                                            imageProvider: NetworkImage(widget
                                                .post.files![index].url
                                                .toString()),
                                            initialScale: PhotoViewComputedScale
                                                    .contained *
                                                1,
                                            heroAttributes:
                                                PhotoViewHeroAttributes(
                                                    tag: widget
                                                        .post.files![index].id
                                                        .toString()),
                                          );
                                        },
                                        pageController:
                                            PageController(initialPage: v),
                                        backgroundDecoration:
                                            BoxDecoration(color: Colors.black),
                                      ),
                                    ))!
                                        .then((value) {
                                      FlutterStatusbarcolor
                                          .setNavigationBarColor(
                                              AppColors.basicColor);
                                      FlutterStatusbarcolor.setStatusBarColor(
                                          AppColors.basicColor);
                                    });
                                  }
                                }
                              },
                              image: ExtendedImage.network(
                                  e.url.toString().replaceAll('\\', ''),
                                  headers: ALMethode.getApiHeader(),
                                  fit: BoxFit.cover,
                                  cache: true,
                                  height: Get.height * 0.2,
                                  handleLoadingProgress: true,
                                  timeRetry: const Duration(seconds: 1),
                                  printError: true,
                                  timeLimit: const Duration(seconds: 1),
                                  borderRadius: BorderRadius.circular(0),
                                  loadStateChanged: (ExtendedImageState state) {
                                switch (state.extendedImageLoadState) {
                                  case LoadState.failed:
                                    return GestureDetector(
                                      key: UniqueKey(),
                                      onTap: () {
                                        state.reLoadImage();
                                      },
                                      child: Container(
                                        width: Get.width,
                                        height: Get.height * 0.20,
                                        decoration: BoxDecoration(
                                          color: Colors.grey.shade50,
                                          borderRadius:
                                              BorderRadius.circular(15),
                                        ),
                                        child: const Icon(
                                          CupertinoIcons.refresh_circled_solid,
                                          size: 40,
                                          color: AppColors.basicColor,
                                          semanticLabel: 'failed',
                                        ),
                                      ),
                                    );
                                  case LoadState.loading:
                                    return Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        Container(
                                          width: Get.width,
                                          height: Get.height * 0.20,
                                          decoration: BoxDecoration(
                                            color: Colors.grey.shade50,
                                            borderRadius:
                                                BorderRadius.circular(15),
                                          ),
                                        ),
                                        Container(
                                          child: Platform.isAndroid
                                              ? const CircularProgressIndicator(
                                                  color: AppColors.grayColor,
                                                  strokeWidth: 1,
                                                  backgroundColor:
                                                      AppColors.whiteColor,
                                                )
                                              : CupertinoActivityIndicator(
                                                  radius: 15),
                                        )
                                      ],
                                    );
                                  case LoadState.completed:
                                    // TODO: Handle this case.
                                    break;
                                }
                                return null;
                              }
                                  //cancelToken: cancellationToken,
                                  ).image,
                              boxDecoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: FractionalOffset.bottomCenter,
                                  end: FractionalOffset.topCenter,
                                  colors: [
                                    Colors.blueAccent.withOpacity(1),
                                    Colors.black.withOpacity(.3),
                                  ],
                                  stops: const [0.0, 1.0],
                                ),
                              ),
                            ))
                        .toList(),
                selectedDotWidth: 6,
                unselectedDotWidth: 4.5,
                selectedDotHeight: 6,
                unselectedDotHeight: 4.5,
                // borderRadius: 15,
                indicatorShape: BoxShape.circle,
                dotSpacing: 1,
                width: Get.width * 0.90,
                autoplay: true,
                showSubBackground: false,
                showText: false,
                unselectedDotColor: AppColors.grayColor,
                selectedDotColor: AppColors.basicColor,
              ),
            ),
          Padding(
            padding: const EdgeInsets.only(right: 16.0, bottom: 16, top: 8),
            child: Align(
              alignment: Alignment.centerRight,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  GetBuilder<HomeController>(
                      init: widget.controller,
                      builder: (builder) => Container(
                            margin: EdgeInsets.only(bottom: Get.height * 0.00),
                            child: LikeButton(
                              size: 20,
                              onTap: (v) async {
                                await Future.delayed(Duration(seconds: 1), () {
                                  widget.post.isFavChange = true;

                                  widget.onLike(widget.post);
                                });
                                return true;
                              },
                              isLiked: widget.post.isFavChange
                                  ? null
                                  : widget.post.isLike!.value == 1
                                      ? true
                                      : false,
                              circleColor: CircleColor(
                                  start: AppColors.readColor,
                                  end: AppColors.readColor),
                              bubblesColor: BubblesColor(
                                dotPrimaryColor: AppColors.readColor,
                                dotSecondaryColor: AppColors.readColor,
                              ),
                              // likeCount: widget.post.counterLikes,
                              likeBuilder: (bool isLiked) {
                                return Icon(
                                  isLiked
                                      ? CupertinoIcons.heart_fill
                                      : CupertinoIcons.heart,
                                  color: isLiked
                                      ? AppColors.readColor
                                      : Colors.grey,
                                  size: 20,
                                );
                              },
                            ),
                          )),
                  IconButton(
                      icon: Icon(
                        CupertinoIcons.eye,
                        color: Colors.grey,
                      ),
                      onPressed: () {
                        Get.toNamed(Routes.postdetailse,
                            arguments: widget.post);
                      }),
                  IconButton(
                      icon: Icon(
                        CupertinoIcons.location_fill,
                        color: Colors.grey,
                      ),
                      onPressed: () async {
                        await shareImagesFromUrls();
                      }),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
