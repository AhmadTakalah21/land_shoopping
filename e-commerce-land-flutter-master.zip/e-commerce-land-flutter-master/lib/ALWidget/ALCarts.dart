



import 'dart:io';

import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shopping_land/Services/helper/status_bar.dart';
import 'package:get/get.dart';
import 'package:photo_view/photo_view.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/Model/Model/OrderDetails.dart';



class ALCarts extends StatefulWidget {
  Cart carts;
  ALCarts({
    required this.carts,
    super.key});

  @override
  State<ALCarts> createState() => _ALCartsState();
}

class _ALCartsState extends State<ALCarts> {
  @override
  Widget build(BuildContext context) {
    return   Container(
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
            boxShadow:[BoxShadow(
              color: Colors.grey,
              spreadRadius: 0.1,
              blurRadius: 0.5,
              offset: const Offset(0, 1), // changes position of shadow
            )],
            color:  Colors.white,
            borderRadius: BorderRadius.circular(12),
            border: Border.all(width: .2,color: AppColors.grayColor)),
        child:   Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              Expanded(child:Container(
                child:Row(
                  children: [
                    ClipRRect(
                      borderRadius: BorderRadius.circular(0),
                      child: InkWell(
                        onTap: ()async{
                          await FlutterStatusbarcolor.setNavigationBarColor(Colors.black);
                          await FlutterStatusbarcolor.setStatusBarColor(Colors.black);
                          Get.to(
                              Scaffold(
                            backgroundColor: Colors.black,
                            appBar: AppBar(backgroundColor: Colors.black,elevation: 0),
                            body: PhotoView(
                              imageProvider: NetworkImage(widget.carts.item!.image!.url.toString(),),
                              backgroundDecoration: BoxDecoration(color: Colors.black),
                            ),)
                          )!.then((value) {
                            FlutterStatusbarcolor.setNavigationBarColor(AppColors.basicColor);
                            FlutterStatusbarcolor.setStatusBarColor(AppColors. basicColor);

                          });
                        },
                        child: ExtendedImage.network(
                            widget.carts.item!.image!.url.toString(),
                            width: Get.width*0.3,
                            height: Get.width*0.4,
                            headers: ALMethode.getApiHeader(),
                            fit: BoxFit.cover,
                            cache: true,
                            handleLoadingProgress: true,
                            timeRetry: const Duration(seconds: 1),
                            printError: true,
                            timeLimit  :const Duration(seconds: 1),
                            borderRadius: BorderRadius.circular(0),
                            loadStateChanged: (ExtendedImageState state) {
                              switch (state.extendedImageLoadState) {
                                case LoadState.failed:
                                  return GestureDetector(
                                    key: UniqueKey(),
                                    onTap: () {
                                      state.reLoadImage();
                                    },
                                    child: Container(
                                      width: Get.width*0.3,
                                      height: Get.width*0.4,
                                      decoration: BoxDecoration(
                                        color: Colors.grey.shade50,
                                        borderRadius: BorderRadius.circular(0),
                                      ),
                                      child:const Icon(CupertinoIcons.refresh_circled_solid,size: 40,color: AppColors.basicColor,semanticLabel: 'failed',),
                                    ),
                                  );
                                case LoadState.loading:
                                  return Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        width: Get.width*0.3,
                                        height: Get.width*0.4,
                                        decoration: BoxDecoration(
                                          color: Colors.grey.shade50,
                                          borderRadius: BorderRadius.circular(0),
                                        ),
                                      ),
                                      Container(child:
                                      Platform.isAndroid? const CircularProgressIndicator(color: AppColors.grayColor,strokeWidth: 1,backgroundColor: AppColors.whiteColor,) :  CupertinoActivityIndicator(radius: 15),
                                      )
                                    ],
                                  );
                                case LoadState.completed:
                                // TODO: Handle this case.
                                  break;
                              }
                              return null;
                            }
                          //cancelToken: cancellationToken,
                        ),
                      ),
                    ),
                    SizedBox(width: Get.width*0.03,),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.carts.item!.name.toString(),style: const TextStyle(fontWeight: FontWeight.w500,fontSize: 19),),
                        const SizedBox(height: 5,),
                        Text(widget.carts.item!.brandName.toString(),style: const TextStyle(fontWeight: FontWeight.w300,fontSize: 16),),
                        Text(widget.carts.item!.name.toString(),style: const TextStyle(fontWeight: FontWeight.w300,fontSize: 15),),
                        SizedBox(height: Get.width*0.02,),
                        for(int i =0;i<widget.carts.cartDetail!.length;i++)
                          Row(children: [
                            Text(widget.carts.cartDetail![i].name.toString()+': ',style: TextStyle(color: Colors.black,fontWeight: FontWeight.w700)),
                            SizedBox(width: Get.width*0.02,),
                            Container(

                              child: Text(widget.carts.cartDetail![i].measurements!.first.name.toString(),style:TextStyle(fontSize: 13,fontWeight: FontWeight.w500,color:Color(0xff4B4B4B) ) ),
                            )
                          ],),
                        SizedBox(height: Get.width*0.02,),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceAround,
                          crossAxisAlignment: CrossAxisAlignment.center,
                          children: [

                            Text('عدد القطع:',style: TextStyle(color: Colors.black,fontWeight: FontWeight.w700)),
                            SizedBox(width: Get.width*0.02,),


                            Container(
                              child: Text( widget.carts.quantity.toString(),style:TextStyle(fontSize: 13,fontWeight: FontWeight.w500,color:Color(0xff4B4B4B) ) ),
                            )

                          ],
                        ),

                      ],)
                  ],
                ) ,
              )),


            ]

        ),);
  }
}
