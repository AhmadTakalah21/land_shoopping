




import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/Model/Model/OrderHistory.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';

typedef OnTap =void Function();
class ALOrderHistory extends StatefulWidget {
  OrderModel orderHistoryM;
  OnTap onTap;
  ALOrderHistory({
    super.key,
    required this.onTap,
    required this.orderHistoryM
  });

  @override
  State<ALOrderHistory> createState() => _ALOrderHistoryState();
}

class _ALOrderHistoryState extends State<ALOrderHistory> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: widget.onTap,
      child: Container(
        width: Get.width,
        height: Get.height*0.1,
        padding:  EdgeInsets.all(Get.width*0.04),
        decoration: BoxDecoration(
            boxShadow: [
              BoxShadow(
                color: Colors.grey.withOpacity(0.1),
                spreadRadius: 2,
                blurRadius: 2,
                offset: const Offset(0, 1), // changes position of shadow
              ),
            ],

            borderRadius: BorderRadius.circular(16),color: Colors.white),
        child: Column(
          children: [
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.start,
              children: [
                Text('${TranslationKeys.date.tr}: ',style: const TextStyle(color: Colors.black,fontSize: 12,fontWeight: FontWeight.w800),),
                Text(widget.orderHistoryM.expectedDeliveryDate.toString(),style: const TextStyle(color: Colors.black,fontSize: 12,fontWeight: FontWeight.w400),),
              ],
            ),
            SizedBox(height: 5,),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(flex: 1,
                  child: Container(
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text('${'تاريخ الاستلام: '}',style: const TextStyle(color: Colors.black,fontSize: 12,fontWeight: FontWeight.w800),),
                        Text(widget.orderHistoryM.expectedDeliveryDate.toString(),style: const TextStyle(color: Colors.black,fontSize: 12,fontWeight: FontWeight.w400),),
                      ],
                    ),
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [

                    Text(ALMethode.formatNumberWithSeparators(widget.orderHistoryM.totalPrice.toString()),style: const TextStyle(color:  AppColors.secondaryColor,fontSize: 12,fontWeight: FontWeight.w400),),
                  ],
                ),
              ],
            ),




            SizedBox(height: 5,),


          ],
        ),),
    );

  }
}
