// ignore_for_file: file_names
import 'dart:io';
import 'dart:typed_data';

import 'package:crop_your_image/crop_your_image.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:path_provider/path_provider.dart';
import 'package:shopping_land/ALConstants/ALConstantsWidget.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/OrderDetails/Controllers/OrderDetailsControllers.dart';



class MUCropPhoto extends StatefulWidget {
  const MUCropPhoto({super.key});

  @override

  _MUCropPhotoState createState() => _MUCropPhotoState();
}

class _MUCropPhotoState extends State<MUCropPhoto> {
  OrderDetailsControllers controller = Get.find();
  final _cropController = CropController();
  final _imageDataList = <Uint8List>[];
  final  _loadingImage = false;
  final _currentImage = 0;
  var _isMiniature = false;
  var _isCropping = false;
  var _isCroppingLoading = false;
  var _isCircleUi = false;
  Uint8List? _croppedData;

  @override
  void initState() {
    var imageBytesSync =controller.byteImage.readAsBytesSync();
    _imageDataList.add(imageBytesSync);
    super.initState();
  }
  @override
  Widget build(BuildContext context) {
    return SafeArea(child: Scaffold(
      backgroundColor:  AppColors.basicColor,
      appBar: AppBar(
          centerTitle: true,
          backgroundColor: AppColors.basicColor,elevation: 0,leading: Padding(
        padding:  EdgeInsets.only(right: Get.height*0.015,left:   Get.height*0.015,top: Get.height*0.00),
        child: IconButton(icon: const Icon(Icons.arrow_back_ios,color: Colors.white,size: 18),onPressed: (){Get.back();},),
      ),
      actions:  _isCropping &&  _croppedData != null ? [
        IconButton(onPressed:(){
          _imageDataList.clear();
          var imageBytesSync =controller.byteImage.readAsBytesSync();
          setState(() {
            _isCropping = false;
            _isCroppingLoading=true;
            _croppedData=null;
            _imageDataList.add(imageBytesSync);
          });
        }, icon: Padding(
          padding: const EdgeInsets.only(right: 55.0,),
          child: Container(width: 50,height: 50,margin: const EdgeInsets.only(right: 100),child: const Icon( Icons.replay_sharp,color: Colors.white,)),
        )),const SizedBox(width: 10,),

        IconButton(onPressed:() async{
          _imageDataList.clear();
          final tempDir = await getTemporaryDirectory();
          File file = await File('${tempDir.path}/${DateTime.now().toString()}_image.png').create();

           file.writeAsBytesSync(_croppedData!);
          controller.image=File('').obs;
          controller.image!.value = file;
          controller.isImage.value=true;
          controller.isImageFind.value=false;
          Get.back();
        }, icon: Padding(
          padding: const EdgeInsets.only(right: 55.0,),
          child: Container(width: 50,height: 50,margin: const EdgeInsets.only(right: 100),child: const Icon( Icons.check,color: Colors.white,)),
        ))

      ] :  [IconButton(onPressed: () async {
         await Future.delayed(Duration.zero,() async{
          _isCircleUi ?  _cropController.cropCircle() : _cropController.crop();
        });
        setState(() {
          _isCropping = true;
        });
       }, icon: _isCropping  && _croppedData == null? ALConstantsWidget.loading(height: Get.width/12,width:Get.width/12) :Padding(
        padding: const EdgeInsets.only(right: 55.0,),
        child: Container(width: 50,height: 50,margin: const EdgeInsets.only(right: 100),child:  const Icon(Icons.crop,color: Colors.white,)),
      )),const SizedBox(width: 10,)]),
      body: SizedBox(
      width: double.infinity,
      height: double.infinity,
      child: Center(
        child: Visibility(
          visible: !_loadingImage && !_isCropping || ( !_loadingImage && !_isCroppingLoading),
          replacement: ALConstantsWidget.loading(height: Get.width/12,width:Get.width/12),
          child: Column(
            children: [
              Expanded(
                child: Visibility(
                  visible: _croppedData == null,
                  replacement: Center(
                    child: _croppedData == null
                        ? const SizedBox.shrink()
                        :Image.memory(_croppedData!,height: Get.height,width: Get.width*0.9),
                  ),
                  child: Stack(
                    children: [
                      if (_imageDataList.isNotEmpty) ...[
                        Crop(
                          controller: _cropController,
                          image: _imageDataList[_currentImage],
                          onCropped: (croppedData) {
                            setState(() {

                              _croppedData = croppedData;
                              _isCroppingLoading = false;
                            });
                          },
                          withCircleUi: _isCircleUi,
                          initialSize: 0.5,
                          maskColor: _isMiniature ? Colors.white : null,
                          cornerDotBuilder: (size, edgeAlignment) =>
                          const SizedBox.shrink(),
                          interactive: true,
                          fixArea: true,
                          radius: 20,
                          initialAreaBuilder: (rect) {
                            return Rect.fromLTRB(
                              rect.left + 24,
                              rect.top + 24,
                              rect.right - 24,
                              rect.bottom - 24,
                            );
                          },
                        ),
                        IgnorePointer(
                          child: Padding(
                            padding: const EdgeInsets.all(24),
                            child: Container(
                              decoration: BoxDecoration(
                                border:
                                Border.all(width: 4, color: Colors.white),
                                borderRadius: BorderRadius.circular(20),
                              ),
                            ),
                          ),
                        ),
                      ],
                      Positioned(
                        right: 16,
                        bottom: 16,
                        child: GestureDetector(
                          onTapDown: (_) => setState(() => _isMiniature = true),
                          onTapUp: (_) => setState(() => _isMiniature = false),
                          child: CircleAvatar(
                            backgroundColor:
                            _isMiniature ? AppColors.basicColor.withOpacity(0.7) : AppColors.basicColor,
                            child:  Center(
                              child:  Icon(Icons.crop_free_rounded,color:Colors.white),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              if (_croppedData == null)
                Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Container(
                                margin: const EdgeInsets.only(bottom: 5),
                                child: IconButton(
                                  icon: const Icon(Icons.crop_7_5,color: Colors.white),
                                  onPressed: () {
                                    _isCircleUi = false;
                                    _cropController.aspectRatio = 16 / 4;
                                  },
                                ),
                              ),
                              const Text('16 : 9',style: TextStyle(color: Colors.white),),
                            ],
                          ),
                          const SizedBox(width: 5,),
                          Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Container(
                                margin: const EdgeInsets.only(bottom: 5),
                                child: IconButton(
                                  icon: const Icon(Icons.crop_16_9,color: Colors.white),
                                  onPressed: () {
                                    _isCircleUi = false;
                                    _cropController.aspectRatio = 16 / 9;
                                  },
                                ),
                              ),
                              const Text('8 : 5',style: TextStyle(color: Colors.white),),
                            ],
                          ),
                          const SizedBox(width: 5,),
                          Stack(
                            alignment: Alignment.bottomCenter,
                            children: [
                              Container(
                                margin: const EdgeInsets.only(bottom: 5),
                                child: IconButton(
                                  icon: const Icon(Icons.crop_5_4,color: Colors.white),
                                  onPressed: () {
                                    _isCircleUi = false;
                                    _cropController.aspectRatio = 4 / 3;
                                  },
                                ),
                              ),
                              const Text('7:5',style: TextStyle(color: Colors.white),),
                            ],
                          ),
                          const SizedBox(width: 5,),
                          Stack(
                            alignment: Alignment.bottomCenter,

                            children: [
                              Container(
                                margin: const EdgeInsets.only(bottom: 5),
                                child: IconButton(
                                  icon: const Icon(Icons.crop_square,color: Colors.white),
                                  onPressed: () {
                                    _isCircleUi = false;
                                    _cropController
                                      ..withCircleUi = false
                                      ..aspectRatio = 1;
                                  },
                                ),
                              ),
                              const Text('4 : 3',style: TextStyle(color: Colors.white),),

                            ],
                          ),
                          const SizedBox(width: 5,),
                          Stack(
                            alignment: Alignment.bottomCenter,

                            children: [
                              Container(
                                margin: const EdgeInsets.only(bottom: 5),
                                child: IconButton(
                                    icon: const Icon(Icons.circle_outlined,color: Colors.white),
                                    onPressed: () {
                                      _isCircleUi = true;
                                      _cropController.withCircleUi = true;
                                    }),
                              ),
                              const Text('Circle',style: TextStyle(color: Colors.white),),

                            ],
                          ),
                        ],
                      ),
                      const SizedBox(height: 16),
                    ],
                  ),
                ),
              const SizedBox(height: 16),
            ],
          ),
        ),
      ),
    )));
  }

}