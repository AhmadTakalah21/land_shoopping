import 'dart:io';

import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:intl/intl.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/Model/Model/NotificationsModel.dart';

class AlNotifications extends StatefulWidget {
  NotificationsModel notificationsModel;
  int index;
  AlNotifications(
      {required this.notificationsModel, required this.index, super.key});

  @override
  State<AlNotifications> createState() => _AlNotificationsState();
}

class _AlNotificationsState extends State<AlNotifications> {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      color: Colors.transparent,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              ClipRRect(
                child: ExtendedImage.network(
                    widget.notificationsModel.urlImage.toString(),
                    headers: ALMethode.getApiHeader(),
                    width: Get.width * 0.20,
                    height: Get.width * 0.20,
                    fit: BoxFit.cover,
                    cache: true,
                    handleLoadingProgress: true,
                    timeRetry: const Duration(seconds: 1),
                    printError: true,
                    timeLimit: const Duration(seconds: 1),
                    borderRadius: BorderRadius.circular(0),
                    loadStateChanged: (ExtendedImageState state) {
                  switch (state.extendedImageLoadState) {
                    case LoadState.failed:
                      return GestureDetector(
                        key: UniqueKey(),
                        onTap: () {
                          state.reLoadImage();
                        },
                        child: Container(
                          width: Get.width * 0.20,
                          height: Get.width * 0.20,
                          decoration: BoxDecoration(
                            color: Colors.grey.shade50,
                            borderRadius: BorderRadius.circular(0),
                          ),
                          child: const Icon(
                            CupertinoIcons.refresh_circled_solid,
                            size: 40,
                            color: AppColors.basicColor,
                            semanticLabel: 'failed',
                          ),
                        ),
                      );
                    case LoadState.loading:
                      return Stack(
                        alignment: Alignment.center,
                        children: [
                          Container(
                            width: Get.width,
                            height: Get.height * 0.20,
                            decoration: BoxDecoration(
                              color: Colors.grey.shade50,
                              borderRadius: BorderRadius.circular(0),
                            ),
                          ),
                          Container(
                            child: Platform.isAndroid
                                ? const CircularProgressIndicator(
                                    color: AppColors.grayColor,
                                    strokeWidth: 1,
                                    backgroundColor: AppColors.whiteColor,
                                  )
                                : CupertinoActivityIndicator(radius: 15),
                          )
                        ],
                      );
                    case LoadState.completed:
                      break;
                  }
                  return null;
                }
                    //cancelToken: cancellationToken,
                    ),
                borderRadius: BorderRadius.circular(8),
              ),

              SizedBox(
                width: 10,
              ),

              // Column(
              //   crossAxisAlignment: CrossAxisAlignment.start,
              //   mainAxisAlignment: MainAxisAlignment.start,
              //   children: [
              //     _buildNotificationSection(
              //         widget.notificationsModel.created_at,
              //         widget.notificationsModel),
              //   ],
              // ),

              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  Text(
                    widget.notificationsModel.title.toString(),
                    style: TextStyle(
                      color: Colors.black,
                      fontSize: 15,
                      fontWeight: FontWeight.w700,
                    ),
                    maxLines: 1,
                  ),
                  SizedBox(
                    height: 10,
                  ),
                  Text(
                    widget.notificationsModel.body.toString(),
                    style: TextStyle(
                        color: Colors.black,
                        fontSize: 14,
                        fontWeight: FontWeight.w500),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildNotificationSection(
      String? time, NotificationsModel notification) {
    DateFormat format = DateFormat("dd-MM-yyyy HH:mm");
    String status = getNotificationDateStatus(format.parse(time!));

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.all(8.0),
          child: Text(status,
              style: TextStyle(fontSize: 15, fontWeight: FontWeight.bold)),
        ),
        Container(
          width: 200,
          child: ListTile(
            title: Text(notification.title.toString()),
            subtitle: Text(notification.created_at!.toString()),
          ),
        ),
      ],
    );
  }

  String getNotificationDateStatus(DateTime date) {
    final now = DateTime.now();
    if (date.year == now.year &&
        date.month == now.month &&
        date.day == now.day) {
      return 'اليوم';
    } else if (date.year == now.year &&
        date.month == now.month &&
        date.day == now.day - 1) {
      return 'البارح';
    } else {
      return 'سابقًا';
    }
  }
}
