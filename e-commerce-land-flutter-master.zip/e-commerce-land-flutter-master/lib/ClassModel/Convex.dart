


import 'package:flutter/cupertino.dart';

class Convex {
  String title ;
  IconData icon ;
  Convex({required this.title,required this.icon});
}