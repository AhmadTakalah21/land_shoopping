import 'dart:io';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/ALNotification.dart';
import 'package:shopping_land/ALConstants/AppPages.dart';
import 'package:shopping_land/ALConstants/DefaultFirebaseOptions.dart';
import 'package:shopping_land/ALSettings/ALSettings.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Controllers/CartControllers.dart';
import 'package:shopping_land/Services/Translations/LocalConfigration/LocalString.dart';

ALSettings alSettings = Get.put(ALSettings());

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  HttpOverrides.global = MyHttpOverrides();

  await Firebase.initializeApp(
    name: "shopping",
    options: Platform.isAndroid
        ? DefaultFirebaseOptions.android
        : DefaultFirebaseOptions.ios,
  );
  ALMethode.initializeAppFirebaseMessaging();
  CLNotification().configuration();
  CLNotification().cancelAll();

  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return DefaultTextStyle(
      style: const TextStyle(overflow: TextOverflow.ellipsis),
      child: SafeArea(
        child: GetMaterialApp(
          debugShowCheckedModeBanner: false,
          title: "Shopping Land",
          initialRoute: Routes.SPLASH,
          theme: ThemeData(useMaterial3: false, fontFamily: 'Almarai-Light'),
          translations: LocalString(),
          getPages: AppPages.routes,
          routingCallback: (routing) {
            alSettings.routeName.value = routing!.current;
          },
        ),
      ),
    );
  }
}

class MyHttpOverrides extends HttpOverrides {
  @override
  HttpClient createHttpClient(SecurityContext? context) {
    return super.createHttpClient(context)
      ..badCertificateCallback =
          (X509Certificate cert, String host, int port) => true;
  }
}
