import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:flutter_staggered_grid_view/flutter_staggered_grid_view.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Controllers/CartControllers.dart';
import 'package:shopping_land/Pages/BuildScreens/Favorite/Controllers/FavoriteControllers.dart';
import 'package:shopping_land/Pages/BuildScreens/Favorite/Views/Favorite.dart';
import 'package:shopping_land/Pages/BuildScreens/Home/Home/Views/Home.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/Profile/Views/Profile.dart';
import 'package:shopping_land/Pages/MainScreenView/Controllers/MainScreenViewControllers.dart';
import 'package:shopping_land/Services/helper/status_bar.dart';
import 'package:flutter_xlider/flutter_xlider.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh_flutter3/pull_to_refresh_flutter3.dart';
import 'package:shopping_land/ALConstants/ALConstantsWidget.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/ALConstants/AppPages.dart';
import 'package:shopping_land/ALWidget/SLItem.dart';
import 'package:shopping_land/ALWidget/SLWidgetText.dart';
import 'package:shopping_land/Model/Model/OptionWidget.dart';
import 'package:shopping_land/Pages/BuildScreens/Brands/BrandsDetails/Controllers/BrandsDetailsControllers.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';
import 'package:shopping_land/main.dart';
import 'package:skeletonizer/skeletonizer.dart';

import '../../../Cart/Views/Cart.dart';

class BrandsDetails extends StatefulWidget {
  bool? cart;
  BrandsDetails({super.key});

  @override
  State<BrandsDetails> createState() => _BrandsDetailsState();
}

class _BrandsDetailsState extends State<BrandsDetails>
    with WidgetsBindingObserver {
  MainScreenViewControllers controller22 = Get.put(MainScreenViewControllers());

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (widget.cart != null) {
      controller22.currentpage.value = 3;
    }
  }

  @override
  void dispose() {
    super.dispose();
    WidgetsBinding.instance.removeObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    if (state == AppLifecycleState.resumed) {
      Future.delayed(Duration.zero, () async {
        alSettings.security.value = await ALMethode.security();

        if (alSettings.security.value) {
          alSettings.security.value = true;
          SystemNavigator.pop();
        }
      });
    }

    //   // Handle other states if needed
  }

  Widget _buildBottomBarItem(int index) {
    return Stack(
      // alignment: Alignment.center,
      children: [
        IconButton(
          icon: Icon(
            size: controller22.currentpage.value == index ? 30 : 30,
            controller22.listIcons[index],
            color: controller22.currentpage.value == index
                ? Colors.transparent
                : Colors.white,
          ),
          onPressed: () {
            setState(() {
              controller22.changePage(index);
            });
            try {
              CartControllers controllers = Get.find();
              controllers.isCheckDiscount.value = false;
              controllers.discountId.value = '';
              controllers.isCheckDiscount.value = false;
              controllers.discount.clear();
            } catch (E) {
              print(E);
            }
          },
        ),
        if (controller22.currentpage.value == index)
          Container(
            width: 60,
            height: 20,
            color: Color(0xFF45C1A6), // لإخفاء الأيقونة تحت الزر
          ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
            statusBarIconBrightness: Brightness.light,
            systemNavigationBarIconBrightness: Brightness.light,
            systemNavigationBarColor: AppColors.basicColor,
            statusBarColor: AppColors.basicColor,
            systemNavigationBarDividerColor: AppColors.basicColor),
        child: Material(child: Scaffold(
          body: GetBuilder<MainScreenViewControllers>(builder: (state) {
            switch (controller22.currentpage.value) {
              case 4:
                {
                  // try {
                  //   HomeController controllers = Get.find();
                  //   controllers.onInit();
                  // }
                  // catch(e){}
                  return Home();
                }
              case 3:
                {
                  return BrandsDetails();
                }
              case 2:
                {
                  try {
                    FavoriteControllers controllers = Get.find();
                    controllers.onInit();
                  } catch (e) {}
                  return const Favorite();
                }
              case 1:
                {
                  // try {
                  //   CartControllers controllers = Get.find();
                  //   controllers.onInit();
                  // }
                  // catch(e){}
                  return const Cart();
                }
              case 0:
                {
                  return const Profile();
                }

              default:
                {
                  return const SizedBox();
                }
            }
          }),
          // bottomNavigationBar: Directionality(
          //   key: ValueKey(controller22.currentpage.value),
          //   textDirection: TextDirection.ltr,
          //   child: Container(
          //     color: Colors.transparent,
          //     height: 100,
          //     child: Stack(
          //       children: [
          //         Positioned(
          //           bottom: 0,
          //           left: 0,
          //           right: 0,
          //           child: Container(
          //             decoration: BoxDecoration(
          //               borderRadius: BorderRadius.only(
          //                   topLeft: Radius.circular(35),
          //                   topRight: Radius.circular(35)),
          //               color: Color(0xFF45C1A6),
          //             ),
          //             height: 68,
          //             child: Row(
          //               mainAxisAlignment: MainAxisAlignment.spaceAround,
          //               children: List.generate(controller22.listIcons.length,
          //                   (index) {
          //                 return _buildBottomBarItem(index);
          //               }),
          //             ),
          //           ),
          //         ),
          //         AnimatedPositioned(
          //           duration: Duration(milliseconds: 200),
          //           curve: Curves.easeInOut,
          //           bottom: 28,
          //           left: MediaQuery.of(context).size.width /
          //                   5.4 *
          //                   controller22.currentpage.value +
          //               (MediaQuery.of(context).size.width / 5 - 60) / 2,
          //           child: Container(
          //             width: 70,
          //             height: 70,
          //             decoration: BoxDecoration(
          //               boxShadow: [
          //                 BoxShadow(
          //                     color: Colors.black.withOpacity(0.5),
          //                     spreadRadius: 0,
          //                     offset: const Offset(0, 3),
          //                     blurRadius: 5)
          //               ],
          //               shape: BoxShape.circle,
          //               color: Colors.white,
          //             ),
          //             child: Icon(
          //               controller22.listIcons[controller22.currentpage.value],
          //               color: Color(0xFFF7C633),
          //               size: 30,
          //             ),
          //           ),
          //         ),
          //       ],
          //     ),
          //   ),
          // ),
        )));
  }
}

class BrandsDetails2 extends StatefulWidget {
  final bool? withSection;

  BrandsDetails2({this.withSection, Key? key}) : super(key: key);

  @override
  _BrandsDetails2State createState() => _BrandsDetails2State();
}

class _BrandsDetails2State extends State<BrandsDetails2> {
  final GlobalKey<ScaffoldState> scaffoldKey = GlobalKey<ScaffoldState>();
  final ScrollController _scrollController = ScrollController();
  bool _showBackToTopButton = false;
  BrandsDetailsControllers controller = Get.put(BrandsDetailsControllers());

  @override
  void initState() {
    //  Get.put(BrandsDetailsControllers());
    super.initState();
    _scrollController.addListener(_scrollListener);
  }

  void _scrollListener() {
    if (_scrollController.offset >= 400) {
      if (!_showBackToTopButton) {
        setState(() {
          _showBackToTopButton = true;
        });
      }
    } else {
      if (_showBackToTopButton) {
        setState(() {
          _showBackToTopButton = false;
        });
      }
    }
  }

  @override
  void dispose() {
    _scrollController.dispose();
    super.dispose();
  }

  void _scrollToTop() {
    _scrollController.animateTo(0,
        duration: Duration(milliseconds: 500), curve: Curves.linear);
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
            statusBarIconBrightness: Brightness.light,
            systemNavigationBarIconBrightness: Brightness.light,
            systemNavigationBarColor: AppColors.basicColor,
            statusBarColor: AppColors.basicColor,
            systemNavigationBarDividerColor: AppColors.basicColor),
        child: Material(
            child: Scaffold(
                key: scaffoldKey,
                drawer: Container(
                  width: Get.width * 0.6,
                  decoration: BoxDecoration(color: Colors.white),
                  child: GetX<BrandsDetailsControllers>(
                      init: controller,
                      builder: (set) => controller.isGetFilter.value
                          ? loadingPage()
                          : Container(
                              width: Get.width * 0.6,
                              height: Get.height,
                              child: Stack(children: [
                                SingleChildScrollView(
                                  child: Column(
                                    children: [
                                      Container(
                                        padding: EdgeInsets.only(top: 10),
                                        color:
                                            Color(0xff707070).withOpacity(0.33),
                                        width: Get.width,
                                        height: Get.height * 0.06,
                                        child: Text('فلترة البحث',
                                            style: TextStyle(
                                                fontSize: 20,
                                                fontWeight: FontWeight.w900)),
                                      ),
                                      SizedBox(
                                        height: 20,
                                      ),
                                      ListView.builder(
                                          shrinkWrap: true,
                                          primary: false,
                                          itemCount:
                                              controller.filtersModel.length,
                                          itemBuilder: (c, index) {
                                            final parent =
                                                controller.filtersModel[index];
                                            return Padding(
                                              padding: const EdgeInsets.only(
                                                  right: 5, left: 5),
                                              child: Container(
                                                  child: Column(
                                                crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                children: [
                                                  Padding(
                                                    padding:
                                                        const EdgeInsets.only(
                                                            right: 10,
                                                            left: 10),
                                                    child: Text(
                                                        parent.name.toString(),
                                                        style: TextStyle(
                                                            fontSize: 22,
                                                            fontWeight:
                                                                FontWeight
                                                                    .w800)),
                                                  ),
                                                  Container(
                                                    margin: EdgeInsets.only(
                                                        top: 25, bottom: 25),
                                                    child: AnimationLimiter(
                                                        child: GridView.builder(
                                                            itemCount: parent
                                                                .measurements!
                                                                .length,
                                                            physics:
                                                                NeverScrollableScrollPhysics(),
                                                            shrinkWrap: true,
                                                            primary: true,
                                                            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                                                                crossAxisCount:
                                                                    2,
                                                                childAspectRatio:
                                                                    3,
                                                                crossAxisSpacing:
                                                                    0,
                                                                mainAxisSpacing:
                                                                    10),
                                                            itemBuilder:
                                                                (c, indexItem) {
                                                              var item = parent
                                                                      .measurements![
                                                                  indexItem];
                                                              return Padding(
                                                                padding: EdgeInsets.only(
                                                                    right: indexItem !=
                                                                            0
                                                                        ? Get.width *
                                                                            0.00
                                                                        : 0),
                                                                child: AnimationConfiguration.staggeredGrid(
                                                                    position: indexItem,
                                                                    duration: const Duration(milliseconds: 500),
                                                                    columnCount: 2,
                                                                    child: ScaleAnimation(
                                                                        duration: const Duration(milliseconds: 900),
                                                                        curve: Curves.fastLinearToSlowEaseIn,
                                                                        child: FadeInAnimation(
                                                                            child: Padding(
                                                                          padding: const EdgeInsets
                                                                              .only(
                                                                              top: 2.0),
                                                                          child: GetBuilder<BrandsDetailsControllers>(
                                                                              init: controller,
                                                                              builder: (c) => Row(
                                                                                    children: [
                                                                                      Checkbox(
                                                                                          value: controller.measurements.any((element) => element.id.toString() == item.id.toString()),
                                                                                          onChanged: (vale) {
                                                                                            if (controller.measurements.isEmpty) {
                                                                                              controller.measurements.add(item);
                                                                                            } else {
                                                                                              if (controller.measurements.any((element) => element.id.toString() == item.id.toString())) {
                                                                                                controller.measurements.removeWhere((element) => element.id.toString() == item.id.toString());
                                                                                              } else {
                                                                                                controller.measurements.add(item);
                                                                                              }
                                                                                            }
                                                                                            controller.update();
                                                                                          }),
                                                                                      Text(
                                                                                        item.name.toString(),
                                                                                        style: TextStyle(color: Colors.black),
                                                                                      ),
                                                                                    ],
                                                                                  )),
                                                                        )))),
                                                              );
                                                            })),
                                                  ),
                                                ],
                                              )),
                                            );
                                          }),
                                      FlutterSlider(
                                        jump: true,
                                        handler: FlutterSliderHandler(
                                            decoration: BoxDecoration(),
                                            child: CircleAvatar(
                                              radius: 8,
                                              backgroundColor:
                                                  AppColors.secondaryColor,
                                            )),
                                        rtl: true,
                                        tooltip: FlutterSliderTooltip(),
                                        values: [0],
                                        trackBar: FlutterSliderTrackBar(
                                          activeTrackBar: BoxDecoration(
                                              borderRadius:
                                                  BorderRadius.circular(4),
                                              color: AppColors.basicColor),
                                        ),
                                        max: 1000000,
                                        min: 0,
                                        fixedValues: generateList(),
                                        onDragging: (handlerIndex, lowerValue,
                                            upperValue) {
                                          controller.upperValue = handlerIndex;
                                          controller.lowerValue.value =
                                              lowerValue;
                                          controller.update();
                                        },
                                      ),
                                      GetBuilder<BrandsDetailsControllers>(
                                          init: controller,
                                          builder: (set) => Padding(
                                                padding:
                                                    const EdgeInsets.all(8.0),
                                                child: Row(
                                                  mainAxisAlignment:
                                                      MainAxisAlignment
                                                          .spaceBetween,
                                                  children: [
                                                    Text('0'),
                                                    Container(
                                                      height: Get.height * 0.05,
                                                      child: SLWidgetText(
                                                          title: controller
                                                                  .lowerValue
                                                                  .value
                                                                  .isNotEmpty
                                                              ? controller
                                                                  .lowerValue
                                                                  .value
                                                              : ALMethode.formatNumberWithSeparators(
                                                                  (controller.upperValue *
                                                                          10000)
                                                                      .toString()),
                                                          backGroundColor:
                                                              AppColors
                                                                  .grayColor,
                                                          isActive: false,
                                                          lightBorder: true),
                                                    )
                                                  ],
                                                ),
                                              )),
                                      TextButton(
                                        onPressed: () {
                                          controller.filterProductFilter();
                                        },
                                        child: Text('بحث'),
                                        style: ButtonStyle(
                                            overlayColor:
                                                MaterialStateProperty.all(
                                                    AppColors.basicColor
                                                        .withOpacity(0.1)),
                                            foregroundColor:
                                                MaterialStateProperty.all(
                                                    AppColors.basicColor)),
                                      )
                                    ],
                                  ),
                                )
                              ]))),
                ),
                appBar: AppBar(
                  backgroundColor: Colors.transparent,
                  elevation: 0,
                  leading: Padding(
                    padding: EdgeInsets.only(
                        right: Get.height * 0.015,
                        left: Get.height * 0.015,
                        top: Get.height * 0.0),
                    child: IconButton(
                      icon:
                          const Icon(Icons.arrow_back_ios, color: Colors.black),
                      onPressed: () {
                        Get.back();
                      },
                    ),
                  ),
                  actions: [
                    Padding(
                        padding: const EdgeInsets.only(
                            top: 10, bottom: 10, left: 10.0),
                        child: SizedBox(
                          width: Get.width * 0.85,
                          height: Get.height * 0.05,
                          child: GetBuilder<BrandsDetailsControllers>(
                            init: controller,
                            builder: (set) =>
                                ValueListenableBuilder<TextDirection>(
                              valueListenable: controller.textDir,
                              child: const SizedBox(),
                              builder: (context, valueTextDirection, child) =>
                                  GetX<BrandsDetailsControllers>(
                                      init: controller,
                                      builder: (set) => Row(
                                            children: [
                                              Expanded(
                                                child: TextFormField(
                                                  //   focusNode: controller.focusNode,
                                                  controller: controller
                                                      .searchController,
                                                  style: const TextStyle(
                                                      textBaseline: TextBaseline
                                                          .alphabetic),
                                                  cursorColor:
                                                      AppColors.basicColor,
                                                  decoration: InputDecoration(
                                                    prefixIcon: Icon(
                                                        CupertinoIcons.search,
                                                        color:
                                                            AppColors.grayColor,
                                                        size: 18),
                                                    suffixIcon: Padding(
                                                      padding:
                                                          const EdgeInsets.only(
                                                              left: 10.0),
                                                      child: Container(
                                                        width: Get.width * 0.15,
                                                        child: Row(
                                                          mainAxisAlignment:
                                                              MainAxisAlignment
                                                                  .end,
                                                          children: [
                                                            if (controller
                                                                .isClear.value)
                                                              InkWell(
                                                                  onTap: () {
                                                                    controller
                                                                        .isClear
                                                                        .value = false;
                                                                    controller
                                                                        .searchController
                                                                        .clear();
                                                                    controller
                                                                        .optionWidgetSearch
                                                                        .clear();
                                                                    controller
                                                                        .pageSearchBool
                                                                        .value = false;
                                                                    controller
                                                                        .update();
                                                                  },
                                                                  child: const Icon(
                                                                      Icons
                                                                          .clear,
                                                                      color: AppColors
                                                                          .secondaryColor)),
                                                          ],
                                                        ),
                                                      ),
                                                    ),
                                                    contentPadding:
                                                        const EdgeInsets.only(
                                                            top: 0,
                                                            left: 15,
                                                            right: 15),
                                                    hintText: TranslationKeys
                                                        .search.tr,
                                                    focusedBorder: OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(25),
                                                        borderSide:
                                                            const BorderSide(
                                                                width: 0.3,
                                                                color: AppColors
                                                                    .grayColor)),
                                                    enabledBorder: OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(25),
                                                        borderSide:
                                                            const BorderSide(
                                                                width: 0.2,
                                                                color: AppColors
                                                                    .grayColor)),
                                                    border: OutlineInputBorder(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(25),
                                                        borderSide:
                                                            const BorderSide(
                                                                width: 0.2,
                                                                color: AppColors
                                                                    .grayColor)),
                                                    hintMaxLines: 1,
                                                    fillColor:
                                                        const Color(0xFFF2F2F2),
                                                    filled: true,
                                                    hintStyle: const TextStyle(
                                                        fontSize: 14),
                                                  ),
                                                  readOnly: controller
                                                              .pageStateSearch
                                                              .value ==
                                                          0 ||
                                                      !controller
                                                          .isGetTypes.value,
                                                  onFieldSubmitted: (value) {
                                                    if (value.isNotEmpty) {
                                                      controller.pageSearchBool
                                                          .value = true;
                                                      controller.isClear.value =
                                                          true;
                                                      controller
                                                          .filterProduct();
                                                      controller.showSearch
                                                          .value = false;
                                                    } else {
                                                      controller.isClear.value =
                                                          false;
                                                      controller
                                                          .optionWidgetSearch
                                                          .clear();
                                                      controller.pageSearchBool
                                                          .value = false;
                                                      controller.showSearch
                                                          .value = true;
                                                    }
                                                  },
                                                  onChanged: (value) {
                                                    final dir =
                                                        ALMethode.getDirection(
                                                            value.trim());
                                                    if (dir !=
                                                        valueTextDirection) {
                                                      controller.textDir.value =
                                                          dir;
                                                    }
                                                    if (value.isNotEmpty) {
                                                      controller.isClear.value =
                                                          true;
                                                      controller.pageSearchBool
                                                          .value = true;
                                                    } else {
                                                      controller.isClear.value =
                                                          false;
                                                      controller.pageSearchBool
                                                          .value = false;
                                                      controller
                                                          .optionWidgetSearch
                                                          .clear();
                                                    }
                                                    controller.update();
                                                  },
                                                ),
                                              ),
                                              InkWell(
                                                  onTap: () async {
                                                    await controller
                                                        .display_measuremeny_by_masterId();
                                                    scaffoldKey.currentState!
                                                        .openDrawer();
                                                  },
                                                  child: Icon(
                                                    CupertinoIcons
                                                        .slider_horizontal_3,
                                                    color: AppColors.grayColor,
                                                    size: 20,
                                                  )),
                                            ],
                                          )),
                            ),
                          ),
                        )),
                  ],
                ),
                body: Stack(
                  children: [
                    Container(
                      child: Obx(() {
                        switch (controller.pageState.value) {
                          case 1:
                            {
                              return previewPage();
                            }
                          case 2:
                            {
                              return errorPage();
                            }
                          case 5:
                            {
                              return ALConstantsWidget.NotFoundData(
                                  TranslationKeys.notFoundData.tr);
                            }
                          default:
                            return Container(
                              width: Get.width,
                              height: Get.height,
                              color:
                                  Theme.of(Get.context!).colorScheme.background,
                            );
                        }
                      }),
                    ),
                    Positioned(
                      top:
                          // 625,
                          MediaQuery.of(context).size.height * 0.80,
                      left:
                          // 350,
                          MediaQuery.of(context).size.width * 0.85,
                      child: Container(
                        width: MediaQuery.of(context).size.width * 0.1,
                        height: MediaQuery.of(context).size.height * 0.05,
                        decoration: BoxDecoration(
                            color: AppColors.secondaryColor4,
                            shape: BoxShape.circle),
                        child: IconButton(
                            onPressed: _scrollToTop,
                            icon: Icon(
                              color: Colors.white,
                              CupertinoIcons.chevron_up,
                            )),
                      ),
                    ),
                  ],
                ))));
  }

  Widget loadingPage() {
    return Center(
      child: ALConstantsWidget.loading(
          height: Get.width / 12, width: Get.width / 12),
    );
  }

  Widget previewPage() {
    final RefreshController _refreshController1 = RefreshController();
    final RefreshController _refreshController2 = RefreshController();
    return Padding(
      padding: EdgeInsets.only(
        right: Get.width * 0.04,
        left: Get.width * 0.04,
      ),
      child: Column(
        children: [
          SingleChildScrollView(
            physics: NeverScrollableScrollPhysics(),
            child: Column(
              children: [
                Container(
                    padding: EdgeInsets.only(top: 10),
                    height: Get.height * 0.05,
                    width: Get.width,
                    alignment: Alignment.center,
                    child: Text(
                      controller.brand.name.toString(),
                      style: TextStyle(
                          color: AppColors.grayColor,
                          fontSize: 18,
                          fontWeight: FontWeight.w600),
                    )),
                if (!controller.isGetItems.value)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Container(
                      padding: const EdgeInsets.only(top: 1, bottom: 1),
                      height: Get.height * 0.055,
                      width: Get.width,
                      child: AnimationLimiter(
                          child: ListView.builder(
                              padding: EdgeInsets.only(bottom: 2),
                              scrollDirection: Axis.horizontal,
                              physics: const BouncingScrollPhysics(
                                  parent: AlwaysScrollableScrollPhysics()),
                              itemCount: 10,
                              itemBuilder: (BuildContext context, int index) {
                                return AnimationConfiguration.staggeredGrid(
                                    position: index,
                                    duration: const Duration(milliseconds: 500),
                                    columnCount: 2,
                                    child: ScaleAnimation(
                                        duration:
                                            const Duration(milliseconds: 900),
                                        curve: Curves.fastLinearToSlowEaseIn,
                                        child: FadeInAnimation(
                                          child: Padding(
                                              padding: EdgeInsets.only(
                                                  right: index != 0
                                                      ? Get.width * 0.02
                                                      : 0),
                                              child: Container(
                                                width: Get.width * 0.25,
                                                height: Get.height * 0.75,
                                                child: Skeletonizer(
                                                    enabled: true,
                                                    child: Skeleton.unite(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(100),
                                                        child: const Card(
                                                          color:
                                                              Color(0xFFE8E8E8),
                                                          child: ListTile(
                                                            focusColor: Color(
                                                                0xFFE8E8E8),
                                                          ),
                                                        ))),
                                              )),
                                        )));
                              })),
                    ),
                  ),
                if (controller.isGetItems.value)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Container(
                      padding: const EdgeInsets.only(top: 1, bottom: 1),
                      height: Get.height * 0.045,
                      width: Get.width,
                      child: AnimationLimiter(
                          child: ListView.builder(
                              padding: EdgeInsets.only(bottom: 2),
                              scrollDirection: Axis.horizontal,
                              physics: const BouncingScrollPhysics(
                                  parent: AlwaysScrollableScrollPhysics()),
                              itemCount:
                                  controller.masterCategories.value.length,
                              itemBuilder: (BuildContext context, int index) {
                                var item =
                                    controller.masterCategories.value[index];

                                return AnimationConfiguration.staggeredGrid(
                                    position: index,
                                    duration: const Duration(milliseconds: 500),
                                    columnCount: 2,
                                    child: ScaleAnimation(
                                        duration:
                                            const Duration(milliseconds: 900),
                                        curve: Curves.fastLinearToSlowEaseIn,
                                        child: FadeInAnimation(
                                          child: Padding(
                                              padding: EdgeInsets.only(
                                                  right: index != 0
                                                      ? Get.width * 0.02
                                                      : 0),
                                              child: InkWell(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          100),
                                                  onTap: controller
                                                              .pageStateProduct
                                                              .value ==
                                                          0
                                                      ? null
                                                      : () {
                                                          controller.masterId!
                                                                  .value =
                                                              item.id
                                                                  .toString();
                                                          controller.update();
                                                          controller
                                                              .display_sub_categories();
                                                        },
                                                  child: GetBuilder<
                                                      BrandsDetailsControllers>(
                                                    init: controller,
                                                    builder: (c) => SLWidgetText(
                                                        title: item.name
                                                            .toString(),
                                                        backGroundColor:
                                                            AppColors
                                                                .secondaryColor4,
                                                        isActive: controller
                                                                .masterId!
                                                                .value ==
                                                            item.id.toString(),
                                                        lightBorder: false),
                                                  ))),
                                        )));
                              })),
                    ),
                  ),
                if (!controller.isGetSub.value)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Container(
                      padding: const EdgeInsets.only(top: 1, bottom: 1),
                      height: Get.height * 0.055,
                      width: Get.width,
                      child: AnimationLimiter(
                          child: ListView.builder(
                              padding: EdgeInsets.only(bottom: 2),
                              scrollDirection: Axis.horizontal,
                              physics: const BouncingScrollPhysics(
                                  parent: AlwaysScrollableScrollPhysics()),
                              itemCount: 10,
                              itemBuilder: (BuildContext context, int index) {
                                return AnimationConfiguration.staggeredGrid(
                                    position: index,
                                    duration: const Duration(milliseconds: 500),
                                    columnCount: 2,
                                    child: ScaleAnimation(
                                        duration:
                                            const Duration(milliseconds: 900),
                                        curve: Curves.fastLinearToSlowEaseIn,
                                        child: FadeInAnimation(
                                          child: Padding(
                                              padding: EdgeInsets.only(
                                                  right: index != 0
                                                      ? Get.width * 0.02
                                                      : 0),
                                              child: Container(
                                                width: Get.width * 0.25,
                                                height: Get.height * 0.75,
                                                child: Skeletonizer(
                                                    enabled: true,
                                                    child: Skeleton.unite(
                                                        borderRadius:
                                                            BorderRadius
                                                                .circular(100),
                                                        child: const Card(
                                                          color:
                                                              Color(0xFFE8E8E8),
                                                          child: ListTile(
                                                            focusColor: Color(
                                                                0xFFE8E8E8),
                                                          ),
                                                        ))),
                                              )),
                                        )));
                              })),
                    ),
                  ),
                if (controller.isGetSub.value)
                  Padding(
                    padding: const EdgeInsets.only(top: 10),
                    child: Container(
                      padding: const EdgeInsets.only(top: 1, bottom: 1),
                      height: Get.height * 0.045,
                      width: Get.width,
                      child: AnimationLimiter(
                          child: ListView.builder(
                              padding: EdgeInsets.only(bottom: 2),
                              scrollDirection: Axis.horizontal,
                              physics: const BouncingScrollPhysics(
                                  parent: AlwaysScrollableScrollPhysics()),
                              itemCount: controller.subCategories.value.length,
                              itemBuilder: (BuildContext context, int index) {
                                var item =
                                    controller.subCategories.value[index];

                                return AnimationConfiguration.staggeredGrid(
                                    position: index,
                                    duration: const Duration(milliseconds: 500),
                                    columnCount: 2,
                                    child: ScaleAnimation(
                                        duration:
                                            const Duration(milliseconds: 900),
                                        curve: Curves.fastLinearToSlowEaseIn,
                                        child: FadeInAnimation(
                                          child: Padding(
                                              padding: EdgeInsets.only(
                                                  right: index != 0
                                                      ? Get.width * 0.02
                                                      : 0),
                                              child: InkWell(
                                                  borderRadius:
                                                      BorderRadius.circular(
                                                          100),
                                                  onTap: controller
                                                              .pageStateProduct
                                                              .value ==
                                                          0
                                                      ? null
                                                      : () {
                                                          controller
                                                                  .subId.value =
                                                              item.id
                                                                  .toString();
                                                          controller.update();
                                                          controller
                                                              .display_items();
                                                        },
                                                  child: GetBuilder<
                                                      BrandsDetailsControllers>(
                                                    init: controller,
                                                    builder: (c) => SLWidgetText(
                                                        title: item.name
                                                            .toString(),
                                                        backGroundColor:
                                                            AppColors
                                                                .secondaryColor,
                                                        isActive: controller
                                                                .subId.value ==
                                                            item.id.toString(),
                                                        lightBorder: true),
                                                  ))),
                                        )));
                              })),
                    ),
                  ),
                if (controller.isGetSub.value &&
                    controller.subCategories.isNotEmpty)
                  const SizedBox(
                    height: 10,
                  ),
                if (!controller.isGetTypes.value)
                  Container(
                    height: Get.height * 0.576,
                    child: AnimationLimiter(
                      child: GridView.builder(
                          physics: const BouncingScrollPhysics(
                              parent: AlwaysScrollableScrollPhysics()),
                          padding: EdgeInsets.only(bottom: Get.height * 0.01),
                          shrinkWrap: true,
                          primary: false,
                          gridDelegate:
                              const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 0.7,
                          ),
                          itemCount: 10,
                          itemBuilder: (BuildContext context, int index) {
                            return AnimationConfiguration.staggeredGrid(
                                position: index,
                                duration: const Duration(milliseconds: 500),
                                columnCount: 2,
                                child: ScaleAnimation(
                                    duration: const Duration(milliseconds: 900),
                                    curve: Curves.fastLinearToSlowEaseIn,
                                    child: FadeInAnimation(
                                      child: Padding(
                                          padding: EdgeInsets.only(
                                              bottom: Get.width * 0.05),
                                          child: Container(
                                            width: Get.width * 0.25,
                                            height: Get.height * 0.75,
                                            child: Skeletonizer(
                                                enabled: true,
                                                child: Skeleton.unite(
                                                    borderRadius:
                                                        BorderRadius.circular(
                                                            15),
                                                    child: const Card(
                                                      color: Color(0xFFE8E8E8),
                                                      child: ListTile(
                                                        focusColor:
                                                            Color(0xFFE8E8E8),
                                                      ),
                                                    ))),
                                          )),
                                    )));
                          }),
                    ),
                  ),
                if (!controller.isGetTypes.value)
                  SizedBox(
                    height: Get.height * 0.01,
                  ),
              ],
            ),
          ),
          if (controller.isGetTypes.value)
            if (controller.isGetSub.value &&
                controller.subCategories.isNotEmpty)
              SizedBox(
                height: Get.height * 0.01,
              )
            else
              SizedBox(
                height: Get.height * 0.000,
              ),
          if (controller.isGetTypes.value)
            Expanded(
              child: Container(
                  child: controller.pageStateProduct.value == 1 &&
                          (controller.masterCategories.isEmpty ||
                              (controller.optionWidgetSearch.isEmpty &&
                                  controller.searchController.text
                                      .trim()
                                      .isNotEmpty))
                      ? ALConstantsWidget.NotFoundData(
                          TranslationKeys.notFoundData.tr)
                      : controller.pageStateProduct.value == 0
                          ? loadingPage()
                          : Stack(
                              children: [
                                GetX<BrandsDetailsControllers>(
                                    init: controller,
                                    builder: (set) => Container(
                                          child: SmartRefresher(
                                            // scrollController: _scrollController,
                                            primary: true,
                                            enablePullDown: true,
                                            enablePullUp: true,
                                            header: WaterDropHeader(
                                                waterDropColor:
                                                    AppColors.secondaryColor,
                                                refresh:
                                                    ALConstantsWidget.loading(
                                                        width: Get.width * 0.1,
                                                        height: Get.width * 0.1,
                                                        color: AppColors
                                                            .basicColor),
                                                complete: ALConstantsWidget
                                                    .smartRefresh()),
                                            footer: CustomFooter(
                                              builder: (BuildContext context,
                                                  LoadStatus? mode) {
                                                Widget body;
                                                if (mode == LoadStatus.idle) {
                                                  body = Text(TranslationKeys
                                                      .moreProduct.tr);
                                                } else if (mode ==
                                                    LoadStatus.loading) {
                                                  body = Platform.isAndroid
                                                      ? const CircularProgressIndicator(
                                                          color: Colors.white,
                                                          strokeWidth: 1,
                                                          backgroundColor:
                                                              AppColors
                                                                  .secondaryColor,
                                                        )
                                                      : CupertinoActivityIndicator(
                                                          color: Theme.of(
                                                                  Get.context!)
                                                              .primaryColorDark);
                                                } else if (mode ==
                                                    LoadStatus.failed) {
                                                  body = const Text('');
                                                } else if (mode ==
                                                    LoadStatus.canLoading) {
                                                  body = Text(TranslationKeys
                                                      .moreProduct.tr);
                                                } else {
                                                  body = Text(TranslationKeys
                                                      .noMore.tr);
                                                }
                                                return DefaultTextStyle(
                                                  style: const TextStyle(
                                                      fontSize: 14,
                                                      color: Colors.white),
                                                  child: Padding(
                                                      padding: EdgeInsets.only(
                                                        left: Get.width * 0.27,
                                                        right: Get.width * 0.27,
                                                      ),
                                                      child: SizedBox(
                                                        height: mode ==
                                                                LoadStatus
                                                                    .loading
                                                            ? 55
                                                            : Get.height * 0.04,
                                                        child: Stack(
                                                          alignment: Alignment
                                                              .topCenter,
                                                          children: [
                                                            Container(
                                                              height: mode ==
                                                                      LoadStatus
                                                                          .loading
                                                                  ? 55
                                                                  : Get.height *
                                                                      0.045,
                                                              decoration: BoxDecoration(
                                                                  color: mode ==
                                                                          LoadStatus
                                                                              .loading
                                                                      ? Colors
                                                                          .transparent
                                                                      : AppColors
                                                                          .secondaryColor,
                                                                  borderRadius:
                                                                      BorderRadius
                                                                          .circular(
                                                                              18)),
                                                              child: Center(
                                                                  child: body),
                                                            ),
                                                          ],
                                                        ),
                                                      )),
                                                );
                                              },
                                            ),
                                            controller: _refreshController1,
                                            onRefresh:
                                                controller.getListOfRefresh,
                                            onLoading:
                                                controller.getListOfLoading,
                                            child: AnimationLimiter(
                                              child: MasonryGridView.count(
                                                  controller: _scrollController,
                                                  itemCount: controller
                                                          .optionWidgetSearch
                                                          .isNotEmpty
                                                      ? controller
                                                          .optionWidgetSearch
                                                          .length
                                                      : !controller
                                                                  .pageSearchBool
                                                                  .value &&
                                                              (controller
                                                                      .searchController
                                                                      .text
                                                                      .isNotEmpty ||
                                                                  controller
                                                                      .optionWidgetSearch
                                                                      .isNotEmpty)
                                                          ? controller
                                                              .optionWidgetSearch
                                                              .length
                                                          : controller
                                                              .optionWidget
                                                              .length,
                                                  crossAxisCount: 2,
                                                  mainAxisSpacing: 3.0,
                                                  crossAxisSpacing: 4.0,
                                                  itemBuilder:
                                                      (BuildContext context,
                                                          int index) {
                                                    dynamic item = controller
                                                            .optionWidgetSearch
                                                            .isNotEmpty
                                                        ? controller
                                                                .optionWidgetSearch[
                                                            index]
                                                        : !controller
                                                                    .pageSearchBool
                                                                    .value &&
                                                                (controller
                                                                        .searchController
                                                                        .text
                                                                        .isNotEmpty ||
                                                                    controller
                                                                        .optionWidgetSearch
                                                                        .isNotEmpty)
                                                            ? controller
                                                                    .optionWidgetSearch[
                                                                index]
                                                            : controller
                                                                    .optionWidget[
                                                                index];

                                                    return AnimationConfiguration
                                                        .staggeredGrid(
                                                            position: index,
                                                            duration:
                                                                const Duration(
                                                                    milliseconds:
                                                                        500),
                                                            columnCount: 2,
                                                            child:
                                                                ScaleAnimation(
                                                                    duration: const Duration(
                                                                        milliseconds:
                                                                            900),
                                                                    curve: Curves
                                                                        .fastLinearToSlowEaseIn,
                                                                    child:
                                                                        FadeInAnimation(
                                                                      child: Padding(
                                                                          padding: EdgeInsets.only(bottom: Get.width * 0.05),
                                                                          child: InkWell(
                                                                              onTap: () {
                                                                                FlutterStatusbarcolor.setNavigationBarColor(AppColors.whiteColor);
                                                                                FlutterStatusbarcolor.setStatusBarColor(AppColors.whiteColor);
                                                                                Get.toNamed(Routes.ItemsDetails, arguments: item)!.then((value) async {
                                                                                  await FlutterStatusbarcolor.setNavigationBarColor(AppColors.whiteColor);
                                                                                  FlutterStatusbarcolor.setStatusBarColor(AppColors.whiteColor);
                                                                                });
                                                                              },
                                                                              borderRadius: BorderRadius.circular(12),
                                                                              child: SLItem(
                                                                                  controller: controller,
                                                                                  item: item,
                                                                                  onLike: (Items item) {
                                                                                    item.isFav!.value = item.isFav!.value == 0 ? 1 : 0;
                                                                                    controller.add_item_or_cancel_favourite(item);
                                                                                  }))),
                                                                    )));
                                                  }),
                                            ),
                                          ),
                                        )),
                              ],
                            )),
            ),
        ],
      ),
    );
  }

  Widget errorPage() {
    return ALConstantsWidget.errorServer(callBack: () {
      controller.pageState.value = 1;
      controller.onInit();
      controller.refreshController;
    });
  }

  List<FlutterSliderFixedValue> generateList() {
    int target = 100; // Desired target value
    int multiplier = 10000; // Initial multiplier
    int index = 1; // Start index

    List<FlutterSliderFixedValue> resultList = [];

    // Generate list until reaching or exceeding target value
    while (index <= target) {
      resultList.add(FlutterSliderFixedValue(
          percent: index,
          value: ALMethode.formatNumberWithSeparators(
              (index * multiplier).toString())));
      index++;
    }

    return resultList;
  }
}
