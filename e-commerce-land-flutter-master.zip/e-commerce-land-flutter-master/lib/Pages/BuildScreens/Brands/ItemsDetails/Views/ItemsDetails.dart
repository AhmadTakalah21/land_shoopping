import 'dart:io';

import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_custom_carousel_slider/flutter_custom_carousel_slider.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:share_plus/share_plus.dart';
import 'package:shopping_land/Pages/BuildScreens/Home/Home/Views/Home.dart';
import 'package:shopping_land/Services/helper/status_bar.dart';
import 'package:get/get.dart';
import 'package:like_button/like_button.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:shopping_land/ALConstants/ALConstantsWidget.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/ALWidget/CustomTextInput.dart';
import 'package:shopping_land/ALWidget/SLWidgetText.dart';
import 'package:shopping_land/Pages/BuildScreens/Brands/ItemsDetails/Controllers/ItemsDetailsControllers.dart';
import 'package:shopping_land/Pages/MainScreenView/Controllers/MainScreenViewControllers.dart';
import 'package:shopping_land/Pages/MainScreenView/Views/MainScreenView.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';
import 'package:shopping_land/main.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;

class ItemsDetails extends GetView<ItemsDetailsControllers> {
  bool? withSection;

  ItemsDetails({this.withSection, Key? key}) : super(key: key);

  MainScreenViewControllers con = Get.find();
  Future<void> shareImagesFromUrls() async {
    if (controller.item.first.images != null &&
        controller.item.first.images!.isNotEmpty) {
      try {
        List<XFile> xFiles = [];
        for (var file in controller.item.first.images!) {
          if (file?.url != null) {
            final response = await http.get(Uri.parse(file!.url!));
            final tempDir = await getTemporaryDirectory();
            final tempFile = File(
                '${tempDir.path}/${DateTime.now().millisecondsSinceEpoch}.jpg');
            await tempFile.writeAsBytes(response.bodyBytes);
            xFiles.add(XFile(tempFile.path));
          }
        }

        if (xFiles.isNotEmpty) {
          await Share.shareXFiles(
            xFiles,
            text:
                '${controller.item.first.brandName}\n${controller.item.first.description}',
          );
        } else {
          await Share.share(
              '${controller.item.first.brandName}\n${controller.item.first.description}');
        }
      } catch (e) {
        print('Error downloading or sharing files: $e');
        await Share.share(
            '${controller.item.first.brandName}\n${controller.item.first.description}');
      }
    } else {
      await Share.share(
          '${controller.item.first.brandName}\n${controller.item.first.description}');
    }
  }

  @override
  Widget build(BuildContext context) {
    double luminance = controller.color.value.computeLuminance();
    bool islike = false;
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
            statusBarIconBrightness: Brightness.light,
            statusBarBrightness: Brightness.light,
            systemNavigationBarIconBrightness: Brightness.light,
            systemNavigationBarColor: controller.color.value,
            systemNavigationBarDividerColor: controller.color.value),
        child: Material(
            child: GetX<ItemsDetailsControllers>(
                init: controller,
                builder: (s) => Scaffold(
                    appBar:
                        // controller.isGetTypes.value
                        //  ? null
                        //  :
                        AppBar(
                            actions: [
                          PopupMenuButton<String>(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(30),
                            ),
                            icon: Icon(Icons.more_vert,
                                color:
                                    controller.color.value.computeLuminance() <
                                            0.5
                                        ? Colors.white
                                        : (controller.color.value)),
                            onSelected: (String result) {
                              switch (result) {
                                case 'share':
                                  shareImagesFromUrls();
                                  break;
                                case 'home':
                                  Get.offAll(() => MainScreenView());
                                  break;
                                case 'favorite':
                                  controller.item.first.isFavChange = true;
                                  islike = true;
                                  break;
                              }
                            },
                            itemBuilder: (BuildContext context) =>
                                <PopupMenuEntry<String>>[
                              const PopupMenuItem<String>(
                                value: 'home',
                                child: ListTile(
                                  leading: Icon(CupertinoIcons.house),
                                  title: Text('الصفحة الرئيسية'),
                                ),
                              ),
                              const PopupMenuItem<String>(
                                value: 'share',
                                child: ListTile(
                                  leading: Icon(
                                    CupertinoIcons.location,
                                    color: Colors.grey,
                                  ),
                                  title: Text('مشاركة'),
                                ),
                              ),
                              const PopupMenuItem<String>(
                                value: 'favorite',
                                child: ListTile(
                                  leading: Icon(CupertinoIcons.heart),
                                  title: Text('المفضلة'),
                                ),
                              ),
                            ],
                          ),
                        ],
                            backgroundColor: controller.color.value,
                            elevation: 0,
                            leading: Padding(
                              padding: EdgeInsets.only(
                                  right: Get.height * 0.015,
                                  left: Get.height * 0.015,
                                  top: Get.height * 0.01),
                              child: IconButton(
                                icon: Icon(Icons.arrow_back_ios,
                                    color: controller.color.value
                                                .computeLuminance() <
                                            0.5
                                        ? Colors.white
                                        : (controller.color.value)),
                                onPressed: () {
                                  Get.back();
                                },
                              ),
                            )),
                    bottomNavigationBar: !controller.isGetTypes.value
                        ? null
                        : Container(
                            padding: EdgeInsets.only(
                                left: Get.width * 0.01,
                                right: Get.width * 0.04,
                                bottom: Get.width * 0.02),
                            width: Get.width * 0.5,
                            child: Row(
                              children: [
                                Container(
                                  height: Get.height * 0.06,
                                  width: Get.width * 0.78,
                                  child:
                                      ALConstantsWidget.elevatedButtonWithStyle(
                                          text: TranslationKeys.addToCard.tr,
                                          colors: AppColors.basicColor,
                                          textColor: AppColors.whiteColor,
                                          onTap: () {
                                            controller.add_item_to_cart();
                                          }),
                                ),
                                SizedBox(width: Get.width * 0.02),
                                InkWell(
                                  onTap: () {
                                    Get.offAll(MainScreenView(
                                      cart: true,
                                    ));
                                  },
                                  splashColor: Colors.transparent,
                                  hoverColor: Colors.transparent,
                                  focusColor: Colors.transparent,
                                  highlightColor: Colors.transparent,
                                  child: Stack(
                                    children: [
                                      Container(
                                          padding:
                                              EdgeInsets.all(Get.width * 0.03),
                                          decoration: BoxDecoration(
                                              border: Border.all(
                                                  color: AppColors.basicColor,
                                                  width: 0.5),
                                              borderRadius:
                                                  BorderRadius.circular(15)),
                                          child: Icon(
                                            CupertinoIcons.cart,
                                            color: AppColors.basicColor,
                                          )),
                                      if (controller.mainScreenViewControllers
                                              .count !=
                                          '0')
                                        Padding(
                                          padding: const EdgeInsets.all(4.0),
                                          child: Container(
                                              margin: EdgeInsets.only(left: 0),
                                              child: CircleAvatar(
                                                radius: 7,
                                                backgroundColor:
                                                    AppColors.readColor,
                                                child: Text(
                                                  controller
                                                      .mainScreenViewControllers
                                                      .count
                                                      .toString(),
                                                  style: TextStyle(
                                                      color: Colors.white,
                                                      fontSize: 11),
                                                ),
                                              )),
                                        ),
                                    ],
                                  ),
                                ),
                              ],
                            ),
                          ),
                    body: Obx(() {
                      switch (controller.pageState.value) {
                        case 1:
                          {
                            return previewPage(islike);
                          }
                        case 2:
                          {
                            return errorPage();
                          }
                        default:
                          return Container(
                            width: Get.width,
                            height: Get.height,
                            color:
                                Theme.of(Get.context!).colorScheme.background,
                          );
                      }
                    })))));
  }

  Widget loadingPage() {
    return Center(
      child: ALConstantsWidget.loading(
          height: Get.width / 12, width: Get.width / 12),
    );
  }

  Widget previewPage(bool islike) {
    return ListView(
      children: [
        if (!controller.isGetTypes.value)
          Center(child: Container(height: Get.height, child: loadingPage())),
        if (controller.isGetTypes.value)
          Stack(
            children: [
              CustomCarouselSlider(
                items: controller.item.isEmpty
                    ? []
                    : controller.item.first.images!
                        .map((e) => CarouselItem(
                              image: ExtendedImage.network(
                                  e.url.toString().replaceAll('\\', ''),
                                  headers: ALMethode.getApiHeader(),
                                  fit: BoxFit.cover,
                                  cache: true,
                                  handleLoadingProgress: true,
                                  timeRetry: const Duration(seconds: 1),
                                  printError: true,
                                  timeLimit: const Duration(seconds: 1),
                                  borderRadius: BorderRadius.circular(0),
                                  loadStateChanged: (ExtendedImageState state) {
                                switch (state.extendedImageLoadState) {
                                  case LoadState.failed:
                                    return GestureDetector(
                                      key: UniqueKey(),
                                      onTap: () {
                                        state.reLoadImage();
                                      },
                                      child: Container(
                                        width: Get.width,
                                        height: Get.height * 0.20,
                                        decoration: BoxDecoration(
                                          color: Colors.grey.shade50,
                                          borderRadius:
                                              BorderRadius.circular(0),
                                        ),
                                        child: const Icon(
                                          CupertinoIcons.refresh_circled_solid,
                                          size: 40,
                                          color: AppColors.basicColor,
                                          semanticLabel: 'failed',
                                        ),
                                      ),
                                    );
                                  case LoadState.loading:
                                    return Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        Container(
                                          width: Get.width,
                                          height: Get.height * 0.20,
                                          decoration: BoxDecoration(
                                            color: Colors.grey.shade50,
                                            borderRadius:
                                                BorderRadius.circular(0),
                                          ),
                                        ),
                                        Container(
                                          child: Platform.isAndroid
                                              ? const CircularProgressIndicator(
                                                  color: AppColors.grayColor,
                                                  strokeWidth: 1,
                                                  backgroundColor:
                                                      AppColors.whiteColor,
                                                )
                                              : CupertinoActivityIndicator(
                                                  radius: 15),
                                        )
                                      ],
                                    );
                                  case LoadState.completed:
                                    // TODO: Handle this case.
                                    break;
                                }
                                return null;
                              }
                                  //cancelToken: cancellationToken,
                                  ).image,
                              onImageTap: (v) async {
                                await FlutterStatusbarcolor
                                    .setNavigationBarColor(Colors.black);
                                await FlutterStatusbarcolor.setStatusBarColor(
                                    Colors.black);
                                Get.to(Scaffold(
                                  backgroundColor: Colors.black,
                                  appBar: AppBar(
                                      backgroundColor: Colors.black,
                                      elevation: 0),
                                  body: PhotoViewGallery.builder(
                                    scrollPhysics:
                                        const BouncingScrollPhysics(),
                                    itemCount:
                                        controller.item.first.images!.length,
                                    builder: (BuildContext context, int index) {
                                      return PhotoViewGalleryPageOptions(
                                        imageProvider: NetworkImage(controller
                                            .item.first.images![index].url
                                            .toString()),
                                        initialScale:
                                            PhotoViewComputedScale.contained *
                                                1,
                                        heroAttributes: PhotoViewHeroAttributes(
                                            tag: controller
                                                .item.first.images![index].id
                                                .toString()),
                                      );
                                    },
                                    pageController:
                                        PageController(initialPage: v),
                                    backgroundDecoration:
                                        BoxDecoration(color: Colors.black),
                                  ),
                                ))!
                                    .then((value) {
                                  FlutterStatusbarcolor.setNavigationBarColor(
                                      AppColors.basicColor);
                                  FlutterStatusbarcolor.setStatusBarColor(
                                      AppColors.basicColor);
                                });
                              },
                              boxDecoration: BoxDecoration(
                                gradient: LinearGradient(
                                  begin: FractionalOffset.bottomCenter,
                                  end: FractionalOffset.topCenter,
                                  colors: [
                                    Colors.blueAccent.withOpacity(1),
                                    Colors.black.withOpacity(.3),
                                  ],
                                  stops: const [0.0, 1.0],
                                ),
                              ),
                            ))
                        .toList(),
                height: Get.height * 0.5,
                // borderRadius: 0,
                dotSpacing: 1,
                width: Get.width,
                autoplay: true,

                showSubBackground: false,
                showText: false,
                selectedDotWidth: 6,
                unselectedDotWidth: 4.5,
                selectedDotHeight: 6,
                unselectedDotHeight: 4.5,
                unselectedDotColor: AppColors.grayColor,
                selectedDotColor: AppColors.basicColor,
              ),
              Padding(
                padding: EdgeInsets.only(
                    left: Get.width * 0.02, right: Get.width * 0.02),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    // Padding(
                    //   padding: EdgeInsets.only(
                    //       right: Get.height * 0.015,
                    //       left: Get.height * 0.015,
                    //       top: Get.height * 0.01),
                    //   child: IconButton(
                    //     icon: const Icon(Icons.arrow_back_ios,
                    //         color: Colors.black),
                    //     onPressed: () {
                    //       Get.back();
                    //     },
                    //   ),
                    // ),
                    GetBuilder<ItemsDetailsControllers>(
                        init: controller,
                        builder: (builder) => Container(
                              width: Get.height * 0.07,
                              height: Get.height * 0.07,
                              margin:
                                  EdgeInsets.only(bottom: Get.height * 0.00),
                              child: LikeButton(
                                size: 30,
                                onTap: (v) async {
                                  await Future.delayed(Duration(seconds: 1),
                                      () {
                                    controller.item.first.isFavChange = true;
                                    controller.item.first.isFav!.value =
                                        controller.item.first.isFav!.value == 0
                                            ? 1
                                            : 0;
                                    controller.add_item_or_cancel_favourite(
                                        controller.item.first.id.toString());
                                  });
                                  return true;
                                },
                                isLiked: controller.item.first.isFavChange
                                    ? null
                                    : controller.item.first.isFav!.value == 1
                                        ? true
                                        : false,
                                likeCount:
                                    controller.item.first.countFavourites,
                                circleColor: CircleColor(
                                    start: AppColors.readColor,
                                    end: AppColors.readColor),
                                bubblesColor: BubblesColor(
                                  dotPrimaryColor: AppColors.readColor,
                                  dotSecondaryColor: AppColors.readColor,
                                ),
                                likeBuilder: (bool isLiked) {
                                  return Icon(
                                    isLiked || islike
                                        ? CupertinoIcons.heart_fill
                                        : CupertinoIcons.heart,
                                    color: isLiked || islike
                                        ? AppColors.readColor
                                        : Colors.grey,
                                    size: 30,
                                  );
                                },
                              ),
                            ))
                  ],
                ),
              )
            ],
          ),
        if (controller.isGetTypes.value)
          Container(
            padding: EdgeInsets.only(
                left: Get.width * 0.02,
                right: Get.width * 0.02,
                bottom: Get.width * 0.02,
                top: Get.width * 0.02),
            decoration: BoxDecoration(
                // color: Color(0xffF5F5F5),
                borderRadius: BorderRadius.only(
                    bottomLeft: Radius.circular(15),
                    bottomRight: Radius.circular(15))),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Container(
                  width: Get.width * 0.5,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    mainAxisAlignment: MainAxisAlignment.start,
                    children: [
                      Text(controller.item.first.name.toString(),
                          textAlign: TextAlign.center,
                          maxLines: 2,
                          style: TextStyle(
                              fontSize: 20,
                              fontWeight: FontWeight.w700,
                              color: Colors.black)),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        controller.item.first.brandName.toString(),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        style: TextStyle(
                            fontSize: 18,
                            fontWeight: FontWeight.w300,
                            color: Colors.black),
                      ),
                      SizedBox(
                        height: 5,
                      ),
                      Text(
                        controller.item.first.description.toString(),
                        textAlign: TextAlign.start,
                        maxLines: 10,
                        style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w300,
                            color: AppColors.grayColor),
                      ),
                    ],
                  ),
                ),
                SizedBox(
                  height: 3,
                ),
                Container(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if (controller.item.first.priceAfterOffer != null &&
                          controller.item.first.priceAfterOffer! > 0)
                        Text(
                          ALMethode.formatNumberWithSeparators(
                              controller.item.first.price.toString() +
                                  alSettings.currency),
                          style: TextStyle(
                              fontSize: 16,
                              fontWeight: FontWeight.w500,
                              decoration: TextDecoration.lineThrough,
                              color: AppColors.grayColor),
                        ),
                      if (controller.item.first.priceAfterOffer != null &&
                          controller.item.first.priceAfterOffer! > 0)
                        Text(
                          ALMethode.formatNumberWithSeparators(
                              controller.item.first.priceAfterOffer.toString() +
                                  alSettings.currency),
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: AppColors.secondaryColor),
                        ),
                      if (controller.item.first.priceAfterOffer == null)
                        Text(
                          ALMethode.formatNumberWithSeparators(
                              controller.item.first.price.toString() +
                                  alSettings.currency),
                          style: TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w700,
                              color: AppColors.secondaryColor),
                        ),
                      SizedBox(
                        height: Get.height * 0.02,
                      ),
                      CustomTextInput(
                          onTap: () {}, controller: controller.quantityTextE)
                    ],
                  ),
                ),
              ],
            ),
          ),
        if (controller.isGetTypes.value)
          Stack(children: [
            SingleChildScrollView(
              child: Column(
                children: [
                  ListView.builder(
                      shrinkWrap: true,
                      primary: false,
                      itemCount: controller.item.first.units!.length,
                      itemBuilder: (c, index) {
                        final parent = controller.item.first.units![index];
                        return Padding(
                          padding: const EdgeInsets.only(right: 5, left: 5),
                          child: Container(
                              child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Padding(
                                padding: const EdgeInsets.only(
                                    right: 10, left: 10, bottom: 10, top: 10),
                                child: Text(parent.name.toString(),
                                    style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w800)),
                              ),
                              Container(
                                height: Get.height * 0.045,
                                width: Get.width,
                                child: AnimationLimiter(
                                    child: ListView.builder(
                                        itemCount: parent.measurements!.length,
                                        scrollDirection: Axis.horizontal,
                                        itemBuilder: (c, indexItem) {
                                          var item =
                                              parent.measurements![indexItem];
                                          return Padding(
                                            padding: EdgeInsets.only(
                                                right: indexItem != 0
                                                    ? Get.width * 0.02
                                                    : 0),
                                            child: AnimationConfiguration
                                                .staggeredGrid(
                                                    position: indexItem,
                                                    duration: const Duration(
                                                        milliseconds: 500),
                                                    columnCount: 2,
                                                    child: ScaleAnimation(
                                                        duration:
                                                            const Duration(
                                                                milliseconds:
                                                                    900),
                                                        curve: Curves
                                                            .fastLinearToSlowEaseIn,
                                                        child: FadeInAnimation(
                                                            child: Padding(
                                                          padding:
                                                              const EdgeInsets
                                                                  .only(
                                                                  top: 2.0),
                                                          child: InkWell(
                                                            borderRadius:
                                                                BorderRadius
                                                                    .circular(
                                                                        100),
                                                            onTap: () {
                                                              if (controller
                                                                  .measurements
                                                                  .isEmpty) {
                                                                controller
                                                                    .measurements
                                                                    .add(item);
                                                              } else {
                                                                controller
                                                                    .measurements
                                                                    .removeWhere((element) =>
                                                                        element
                                                                            .unitName
                                                                            .toString() ==
                                                                        item.unitName
                                                                            .toString());
                                                                controller
                                                                    .measurements
                                                                    .add(item);
                                                              }
                                                              controller
                                                                  .update();
                                                            },
                                                            child: GetBuilder<
                                                                    ItemsDetailsControllers>(
                                                                init:
                                                                    controller,
                                                                builder: (c) => SLWidgetText(
                                                                    title: item
                                                                        .name
                                                                        .toString(),
                                                                    backGroundColor:
                                                                        AppColors
                                                                            .basicColor,
                                                                    isActive: controller
                                                                        .measurements
                                                                        .any((element) =>
                                                                            element.id.toString() ==
                                                                            item.id
                                                                                .toString()),
                                                                    lightBorder:
                                                                        false)),
                                                          ),
                                                        )))),
                                          );
                                        })),
                              ),
                            ],
                          )),
                        );
                      }),
                ],
              ),
            )
          ]),
      ],
    );
  }

  Widget errorPage() {
    return ALConstantsWidget.errorServer(callBack: () {
      controller.onInit();
    });
  }
}
