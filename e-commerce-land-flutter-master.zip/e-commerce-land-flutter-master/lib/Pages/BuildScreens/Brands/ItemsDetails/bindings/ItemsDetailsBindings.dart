import 'package:get/get.dart';
import 'package:shopping_land/Pages/BuildScreens/Brands/ItemsDetails/Controllers/ItemsDetailsControllers.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Controllers/CartControllers.dart';

class ItemsDetailsBindings extends Bindings {
  @override
  void dependencies() {
    Get.lazyPut(() => ItemsDetailsControllers());
   // Get.lazyPut(() => CartControllers());
  }
}
