import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:shopping_land/Model/Model/CartModel.dart';
import 'package:shopping_land/Services/helper/status_bar.dart';
import 'package:flutter_svprogresshud/flutter_svprogresshud.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh_flutter3/pull_to_refresh_flutter3.dart';
import 'package:shopping_land/packages/rounded_loading_button-2.1.0/rounded_loading_button.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/Model/Model/ItemStore.dart';
import 'package:shopping_land/Model/Model/ItemsDetailsModel.dart';
import 'package:shopping_land/Model/Model/MasterCategories.dart';
import 'package:shopping_land/Model/Model/OptionWidget.dart';
import 'package:shopping_land/Model/Model/SubCategories.dart';
import 'package:shopping_land/Pages/BuildScreens/Brands/ItemsDetails/Repositories/ItemsDetailsRepositories.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Controllers/CartControllers.dart';
import 'package:shopping_land/Pages/BuildScreens/Home/Home/Repositories/HomeRepositories.dart';
import 'package:shopping_land/Pages/MainScreenView/Controllers/MainScreenViewControllers.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';
import 'package:shopping_land/main.dart';

class ItemsDetailsControllers extends GetxController {
  late Items itemsView;
  // final CartControllers cartController = Get.find<CartControllers>();

  Rx<Color> color = Colors.white.obs;
  bool offer = false;
  RxInt pageStateProduct = 0.obs;
  RxInt pageState = 1.obs;
  Rx<ItemStore> itemStore = ItemStore().obs;
  TextEditingController controller = TextEditingController(text: '1');
  RoundedLoadingButtonController btnController =
      RoundedLoadingButtonController();

  RxInt pageStateSearch = 1.obs;
  final MainScreenViewControllers mainScreenViewControllers = Get.find();
  RxInt pageSearch = 1.obs;
  RxBool isGetTypes = false.obs;
  RxBool pageSearchBool = false.obs;
  RxList<MasterCategories> masterCategories = <MasterCategories>[].obs;
  RxList<SubCategories> subCategories = <SubCategories>[].obs;
  RxList<ItemsDetailsModel> item = <ItemsDetailsModel>[].obs;
  TextEditingController quantityTextE = TextEditingController(text: '1');
  RxList<Measurements2> measurements = <Measurements2>[].obs;
  late ValueNotifier<TextDirection> textDir;
  late RefreshController refreshController;

  ItemsDetailsControllers() {
    FlutterStatusbarcolor.setNavigationBarColor(AppColors.basicColor);

    itemsView = Get.arguments;
    textDir = ValueNotifier(
        alSettings.currentUser != null && alSettings.currentUser!.locale != 'ar'
            ? TextDirection.ltr
            : TextDirection.rtl);
    refreshController = RefreshController(initialRefresh: false);
  }

  Future<void> add_item_or_cancel_favourite(String id) async {
    HomeRepositories repositories = HomeRepositories();
    await repositories
        .add_item_or_cancel_favourite(bodyData: {'item_id': id.toString()});
  }

  // int getTotalCartQuantity() {
  //   int totalQuantity = 0;
  //   for (CartModel cartModel in cartController.carts) {
  //     if (cartModel.carts != null) {
  //       for (Carts cart in cartModel.carts!) {
  //         totalQuantity += cart.quantity ?? 0;
  //       }
  //     }
  //   }

  //   return totalQuantity;
  // }

  Future<void> add_item_to_cart() async {
    if (Platform.isIOS) {
      SVProgressHUD.setDefaultAnimationType(SVProgressHUDAnimationType.native);
    }
    SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.light);

    SVProgressHUD.show(status: 'اضافة');
    ItemsDetailsRepositories repositories = ItemsDetailsRepositories();

    FormData form = createFormData(json.decode(json.encode(measurements)));
    form.fields.add(MapEntry('quantity', quantityTextE.text.trim().toString()));
    form.fields.add(MapEntry('item_id', item.first.id.toString()));

    if (await repositories.add_item_to_cart(bodyData: form)) {
      // MainScreenViewControllers mainScreenViewControllers = Get.find();
      await mainScreenViewControllers.count_item_in_cart();
      try {
        // CartControllers controllers = Get.find();
        // controllers.onInit();
      } catch (e) {}
      SVProgressHUD.showSuccess(status: 'تم');
      await Future.delayed(Duration(seconds: 1));
      SVProgressHUD.dismiss();
      // getTotalCartQuantity();
      // Get.back();
    } else {
      SVProgressHUD.dismiss();
      ALMethode.showToast(
          title: TranslationKeys.somethingWentWrong.tr,
          message:
              repositories.message.description ?? TranslationKeys.errorEmail.tr,
          type: ToastType.error,
          context: Get.context!);
    }
  }

  Future<void> display_items() async {
    isGetTypes.value = false;
    ItemsDetailsRepositories repositories = ItemsDetailsRepositories();

    Map<String, String> body = {
      'city_id': alSettings.citiesId.value,
      'item_id': itemsView.id.toString(),
    };
    if (await repositories.display_item_by_id(bodyData: body)) {
      if (repositories.message.data != null) {
        var data = json.decode(json.decode(repositories.message.data));
        item.value = dataItemsDetailsModelFromJson(
            [json.encode(data)].toString().toString());

        if (item.first.units != null && item.first.units!.isNotEmpty) {
          item.first.units!.forEach((element) {
            measurements.add(element.measurements!.first);
          });
        }

        if (item.first.images != null) {
          isGetTypes.value = true;
          color.value = await ALMethode.getDominantColor(
              item.first.images!.first.url.toString());
          color.value = ALMethode.isColorCloseToWhite(color.value)
              ? AppColors.basicColor
              : color.value;
          await FlutterStatusbarcolor.setNavigationBarColor(color.value!);
          await FlutterStatusbarcolor.setStatusBarColor(color.value!);
        }
      }
      // MainScreenViewControllers controllers = Get.find();
      // await controllers.count_item_in_cart();
      isGetTypes.value = true;
      update();
    } else {
      pageState.value = 2;
    }
  }

  FormData createFormData(List<dynamic> percents) {
    FormData formData = FormData({});
    for (int i = 0; i < percents.length; i++) {
      formData.fields.add(MapEntry('item_measurements[$i][measurement_id]',
          percents[i]['id'].toString()));
    }

    return formData;
  }

  @override
  void onInit() {
    super.onInit();
    // showItemStoreOffers();

    display_items();
  }
}
