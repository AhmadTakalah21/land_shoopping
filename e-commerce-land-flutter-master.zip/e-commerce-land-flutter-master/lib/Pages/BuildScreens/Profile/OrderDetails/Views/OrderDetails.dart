










import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shopping_land/ALConstants/ALConstantsWidget.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/ALWidget/ALCarts.dart';
import 'package:shopping_land/ALWidget/MUCropPhoto.dart';
import 'package:shopping_land/Model/Model/OrderDetails.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/OrderDetails/Controllers/OrderDetailsControllers.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';
import 'package:uuid/uuid.dart';

class OrderDetails extends GetView<OrderDetailsControllers> {
  bool? withSection;

  OrderDetails({Key? key}) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
            statusBarIconBrightness: Brightness.dark,
            systemNavigationBarIconBrightness: Brightness.dark,
            systemNavigationBarColor: Colors.white,
            systemNavigationBarDividerColor: AppColors.whiteColor
        ), child: Material(
        child: Container(
            decoration: BoxDecoration(

            ),
            child: Scaffold(
              backgroundColor: Colors.transparent,
              appBar: AppBar(
                leadingWidth: Get.width*0.1,
                  titleSpacing: Get.width*0.001,
                  title: Text(TranslationKeys.orderHistory.tr,style: const TextStyle(color: Colors.black,fontSize: 21,fontWeight: FontWeight.w800),),
                  backgroundColor: Colors.transparent,elevation: 0,leading: Padding(
                padding:  EdgeInsets.only(right: Get.height*0.015,left:   Get.height*0.015,top: Get.height*0.00),
                child: IconButton(icon: const Icon(Icons.arrow_back_ios,color: Colors.black,size: 18),onPressed: (){Get.back();},),
              )),
              body:Obx(() {
                switch (controller.pageState.value) {
                  case 0:
                    {
                      return loadingPage();
                    }
                  case 1:
                    {
                      return previewPage();
                    }
                  case 2:
                    {
                      return errorPage();
                    }
                  default:
                    return Container(width: Get.width,height: Get.height,color: Theme.of(Get.context!).colorScheme.background,);
                }}),
            ))));
  }
  Widget loadingPage () {
    return Center(child: ALConstantsWidget.loading(height: Get.width/12,width:Get.width/12),);
  }

  Widget previewPage () {
    return   AnimationLimiter(
      child: ListView(

        children: [
          Container(width: Get.width,padding:  EdgeInsets.only(right: Get.width*0.05,left:Get.width*0.05,),color: Colors.white,child: Text(controller.title+' / تفاصيل الطلب',style: const TextStyle(fontSize: 18,fontWeight: FontWeight.w500),)),

          const SizedBox(height: 20,),
          Container(
            width: Get.width*0.93,
            decoration: BoxDecoration(
                boxShadow:[BoxShadow(
                  color: Colors.grey,
                  spreadRadius: 0.1,
                  blurRadius: 0.5,
                  offset: const Offset(0, 1), // changes position of shadow
                )],
              color: Colors.white,
                borderRadius: BorderRadius.circular(12)
            ),
            child: Column(
              children: [
                Container(

                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('رقم الطلب:',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 16)),
                        Text(controller.orderDetails.first.orderNumber.toString(),style: const TextStyle(color:AppColors.grayColor,fontWeight: FontWeight.w300,fontSize: 16)),

                      ],),
                  ),
                ),

                Container(

                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('اسم المرسل إليه:',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 16)),
                        Text(controller.orderDetails.first.customerName.toString(),style: const TextStyle(color:AppColors.grayColor,fontWeight: FontWeight.w300,fontSize: 16)),

                      ],),
                  ),
                ),

                Container(

                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('تاريخ الطلب:',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 16)),
                        Text(controller.orderDetails.first.expectedDeliveryDate.toString(),style: const TextStyle(color:AppColors.grayColor,fontWeight: FontWeight.w300,fontSize: 16)),

                      ],),
                  ),
                ),

                Container(

                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('تاريخ التسليم المتوقع:',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 16)),
                        Text(controller.orderDetails.first.expectedDeliveryDate.toString(),style: const TextStyle(color:AppColors.grayColor,fontWeight: FontWeight.w300,fontSize: 16)),

                      ],),
                  ),
                ),
                Container(

                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('طريقة الدفع:',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 16)),
                        Text(controller.orderDetails.first.paymentMethodName.toString(),style: const TextStyle(color:AppColors.grayColor,fontWeight: FontWeight.w300,fontSize: 16)),

                      ],),
                  ),
                ),


                Container(

                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('حالة الدفع:',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 16)),
                        Text(controller.orderDetails.first.isPayment==1?'تم الدفع':'معلقة',style: const TextStyle(color:AppColors.grayColor,fontWeight: FontWeight.w300,fontSize: 16)),

                      ],),
                  ),
                ),

                if(controller.orderDetails.first.reason!=null && controller.orderDetails.first.reason!.isNotEmpty)
                Container(

                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('سبب الرفض:',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 16)),
                        Text(controller.orderDetails.first.reason.toString(),style: const TextStyle(color:AppColors.grayColor,fontWeight: FontWeight.w300,fontSize: 16)),

                      ],),
                  ),
                ),


                Container(

                  child: Padding(
                    padding: const EdgeInsets.all(8.0),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text('السعر:',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 16)),
                        Text(ALMethode.formatNumberWithSeparators(controller.orderDetails.first.totalPrice.toString()),style: const TextStyle(color:AppColors.secondaryColor,fontWeight: FontWeight.w500,fontSize: 16)),

                      ],),
                  ),
                ),



                if(controller.orderDetails.first.status=='pending')
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      if(controller.orderDetails.first.isPayment==0)
                        ALConstantsWidget.elevatedButtonWithStyle(
                            text: 'دفع',
                            colors: AppColors.secondaryColor,
                            textColor: AppColors.whiteColor,
                            onTap: (){
                              ALConstantsWidget.awesomeDialog(
                                  controller: controller.btnController,
                                  child:SingleChildScrollView(
                                      physics: const NeverScrollableScrollPhysics(),
                                      child: Padding(
                                          padding: const EdgeInsets.only(left: 8.0,right: 8),
                                          child: StatefulBuilder(
                                              builder: (context, State) {

                                                return  Form(
                                                  key:controller.form,
                                                  child: Column(
                                                      children: [
                                                        Text('الدفع',style: const TextStyle(fontSize: 24,color: Colors.black,fontWeight: FontWeight.w800),),
                                                        SizedBox(height: Get.height*0.01,),

                                                        Text('تفاصيل الدفع',style: const TextStyle(fontSize: 18,color: AppColors.grayColor,fontWeight: FontWeight.w500),),

                                                        SizedBox(height: Get.height*0.025,),


                                                        SizedBox(height: Get.height*0.025,),

                                                        ...controller.detailPayment.map((element) => Container(

                                                          child: Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                              children: [
                                                                Text(element.key.toString()+':',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 16)),
                                                                Text(element.value.toString(),style: const TextStyle(color:AppColors.grayColor,fontWeight: FontWeight.w300,fontSize: 16)),

                                                              ],),
                                                          ),
                                                        )),


                                                        SizedBox(height: Get.height*0.025,),


                                                        Container(

                                                          child: Padding(
                                                            padding: const EdgeInsets.all(8.0),
                                                            child: Row(
                                                              mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                                              children: [
                                                                Text('صورة الاشعار:',style: const TextStyle(color:Colors.black,fontWeight: FontWeight.w500,fontSize: 14)),
                                                                GetX<OrderDetailsControllers>(init: controller,builder: (set)=>Stack(
                                                                  alignment: !controller.isImage.value?Alignment.center : Alignment.bottomRight,
                                                                  children: [
                                                                    GetX<OrderDetailsControllers>(init: controller,builder: (set){
                                                                      return
                                                                        !controller.isImage.value
                                                                            ? InkWell(
                                                                          onTap: () async {
                                                                            SystemChannels.textInput.invokeMethod('TextInput.hide');
                                                                            if(await  ALMethode.GetPermission(isStorage: true))
                                                                            {
                                                                              var uuid = const Uuid();
                                                                              var heroCamera = uuid.v4().toString();
                                                                              var heroGallery = uuid.v4().toString();
                                                                              showModalBottomSheet(context: Get.context!,
                                                                                  backgroundColor: AppColors.basicColor,
                                                                                  builder: (v){
                                                                                    return Container(
                                                                                      padding: EdgeInsets.only(top: Get.width/35,left: Get.width/25,right: Get.width/50,bottom:Get.width/35 ),
                                                                                      height: Get.height/3.5,
                                                                                      child: Column(
                                                                                        children: [
                                                                                          Expanded(
                                                                                            child: Row(
                                                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                                              children: [
                                                                                                Expanded(child: Text(TranslationKeys.select.tr,style: TextStyle(fontSize: 24,color:Colors.black ),)),
                                                                                                controller.image!=null || controller.isImageFind.value ?IconButton(onPressed: (){
                                                                                                  if(controller.image!=null || controller.isImageFind.value)
                                                                                                  {
                                                                                                    Get.back();
                                                                                                    controller.isImage.value=false;
                                                                                                    controller.image=null;
                                                                                                    State((){
                                                                                                      controller.image;
                                                                                                    });

                                                                                                  }
                                                                                                }, icon: Icon(Icons.delete,color:AppColors.basicColor,)):const SizedBox()
                                                                                              ],
                                                                                            ),
                                                                                          ),
                                                                                          SizedBox(height: Get.width/25,),
                                                                                          Row(
                                                                                            crossAxisAlignment: CrossAxisAlignment.center,
                                                                                            mainAxisAlignment: MainAxisAlignment.start,
                                                                                            children: [
                                                                                              Column(
                                                                                                children: [
                                                                                                  FloatingActionButton(onPressed: () async {
                                                                                                    Get.back();
                                                                                                    await  setAvatar(imageSource:ImageSource.camera);
                                                                                                    if(controller.imageUser.value.isNotEmpty)
                                                                                                    {
                                                                                                      Get.to(const MUCropPhoto(),transition: Transition.rightToLeft)!.then((value){
                                                                                                        State((){
                                                                                                          controller.image;
                                                                                                        });
                                                                                                      });
                                                                                                    }
                                                                                                  },backgroundColor: Colors.white,child:Icon(Icons.camera_alt,color: AppColors.basicColor) ,heroTag:heroCamera),
                                                                                                  const SizedBox(height: 5,),
                                                                                                  Text(TranslationKeys.camera.tr,style: TextStyle(color: Colors.black))
                                                                                                ],
                                                                                              ),
                                                                                              SizedBox(width: Get.width/25,),
                                                                                              Column(
                                                                                                children: [
                                                                                                  FloatingActionButton(onPressed: () async {
                                                                                                    Get.back();
                                                                                                    await  setAvatar(imageSource:ImageSource.gallery);
                                                                                                    if(controller.imageUser.value.isNotEmpty)
                                                                                                    {
                                                                                                      Get.to(const MUCropPhoto(),transition: Transition.rightToLeft)!.then((value){
                                                                                                        controller.image;
                                                                                                      });
                                                                                                    }
                                                                                                  },backgroundColor: Colors.white,child:Icon(Icons.photo_camera_back,color:AppColors.basicColor) ,heroTag:heroGallery),
                                                                                                  const SizedBox(height: 5,),
                                                                                                  Text(TranslationKeys.gallery.tr,style: TextStyle(color: Colors.black),)
                                                                                                ],
                                                                                              ),
                                                                                            ],
                                                                                          ),
                                                                                          SizedBox(height: Get.width/25,),
                                                                                        ],
                                                                                      ),
                                                                                    );
                                                                                  });
                                                                            }
                                                                          },
                                                                          child: Container(
                                                                              width: Get.width/4,
                                                                              height: Get.width/4,
                                                                              decoration: BoxDecoration(
                                                                                  color:AppColors.whiteColor,
                                                                                  borderRadius: BorderRadius.circular(18)
                                                                              ),

                                                                              child: Icon(Icons.add,
                                                                                  size: 20, color:Colors.black)),
                                                                        )
                                                                            : Container(
                                                                          decoration: BoxDecoration(
                                                                            borderRadius: BorderRadius.circular(18),
                                                                            border: Border.all(
                                                                                color: Colors.black, width: 2),
                                                                          ),
                                                                          child: ClipRRect(
                                                                              borderRadius: BorderRadius.circular(18),
                                                                              child: Image.file(
                                                                                width: Get.width/4,
                                                                                height: Get.width/4,
                                                                                controller.image!.value,
                                                                                fit: BoxFit.cover,
                                                                              )),
                                                                        );
                                                                    },),
                                                                    if(controller.isImage.value)
                                                                      CircleAvatar(
                                                                        backgroundColor: AppColors.basicColor,
                                                                        child: IconButton(
                                                                            onPressed: () async {
                                                                              SystemChannels.textInput.invokeMethod('TextInput.hide');
                                                                              if(await  ALMethode.GetPermission(isStorage: true))
                                                                              {
                                                                                var uuid = const Uuid();
                                                                                var heroCamera = uuid.v4().toString();
                                                                                var heroGallery = uuid.v4().toString();
                                                                                showModalBottomSheet(context: Get.context!,
                                                                                    backgroundColor: AppColors.basicColor,
                                                                                    builder: (v){
                                                                                      return Container(
                                                                                        padding: EdgeInsets.only(top: Get.width/35,left: Get.width/25,right: Get.width/50,bottom:Get.width/35 ),
                                                                                        height: Get.height/3.5,
                                                                                        child: Column(
                                                                                          children: [
                                                                                            Expanded(
                                                                                              child: Row(
                                                                                                crossAxisAlignment: CrossAxisAlignment.center,
                                                                                                mainAxisAlignment: MainAxisAlignment.start,
                                                                                                children: [
                                                                                                  Expanded(child: Text(TranslationKeys.select.tr,style: TextStyle(fontSize: 24,color:Colors.black ),)),
                                                                                                  controller.image!=null || controller.isImageFind.value?IconButton(onPressed: (){
                                                                                                    if(controller.image!=null || controller.isImageFind.value)
                                                                                                    {
                                                                                                      Get.back();
                                                                                                      controller.isImage.value=false;
                                                                                                      controller.image=null;

                                                                                                    }
                                                                                                  }, icon: Icon(Icons.delete,color:AppColors.readColor,)):const SizedBox()
                                                                                                ],
                                                                                              ),
                                                                                            ),
                                                                                            SizedBox(height: Get.width/25,),
                                                                                            Row(
                                                                                              crossAxisAlignment: CrossAxisAlignment.center,
                                                                                              mainAxisAlignment: MainAxisAlignment.start,
                                                                                              children: [
                                                                                                Column(
                                                                                                  children: [
                                                                                                    FloatingActionButton(onPressed: () async {
                                                                                                      Get.back();
                                                                                                      await  setAvatar(imageSource:ImageSource.camera);
                                                                                                      if(controller.imageUser.value.isNotEmpty)
                                                                                                      {
                                                                                                        Get.to(const MUCropPhoto(),transition: Transition.rightToLeft)!.then((value){
                                                                                                          controller.image;
                                                                                                        });
                                                                                                      }
                                                                                                    },backgroundColor: Colors.white,child:Icon(Icons.camera_alt,color: AppColors.basicColor) ,heroTag:heroCamera),
                                                                                                    const SizedBox(height: 5,),
                                                                                                    Text(TranslationKeys.camera.tr,style: TextStyle(color: Colors.black))
                                                                                                  ],
                                                                                                ),
                                                                                                SizedBox(width: Get.width/25,),
                                                                                                Column(
                                                                                                  children: [
                                                                                                    FloatingActionButton(onPressed: () async {
                                                                                                      Get.back();
                                                                                                      await  setAvatar(imageSource:ImageSource.gallery);
                                                                                                      if(controller.imageUser.value.isNotEmpty)
                                                                                                      {
                                                                                                        Get.to(const MUCropPhoto(),transition: Transition.rightToLeft)!.then((value){
                                                                                                          controller.image;
                                                                                                        });
                                                                                                      }
                                                                                                    },backgroundColor: Colors.white,child:Icon(Icons.photo_camera_back,color:AppColors.basicColor) ,heroTag:heroGallery),
                                                                                                    const SizedBox(height: 5,),
                                                                                                    Text(TranslationKeys.gallery.tr,style: TextStyle(color: Colors.black),)
                                                                                                  ],
                                                                                                ),
                                                                                              ],
                                                                                            ),
                                                                                            SizedBox(height: Get.width/25,),
                                                                                          ],
                                                                                        ),
                                                                                      );
                                                                                    });
                                                                              }
                                                                            },
                                                                            icon:  Icon(
                                                                              Icons.add_a_photo,
                                                                              color: Colors.white,
                                                                            )),
                                                                      ),
                                                                  ],
                                                                )),

                                                              ],),
                                                          ),
                                                        ),

                                                        SizedBox(height: Get.height*0.025,),

                                                        TextFormField(
                                                            validator: (val){
                                                              if (val!.trim().isEmpty)
                                                              {
                                                                return TranslationKeys.required.tr;
                                                              }
                                                              else {
                                                                return null;
                                                              }
                                                            },
                                                            keyboardType: TextInputType.number,
                                                            inputFormatters:  [
                                                              FilteringTextInputFormatter.deny(RegExp(r'[-,]')),
                                                            ],
                                                            enabled: true,
                                                            controller: controller.numberAccount,
                                                            textInputAction: null,
                                                            maxLines: 1,
                                                            decoration: InputDecoration(
                                                                contentPadding:  EdgeInsets.only(top: 5,left: Get.width*0.05,right: Get.width*0.05),
                                                                hintStyle: TextStyle(color: AppColors.grayColor,fontSize: 13),
                                                                alignLabelWithHint: true,
                                                                border: OutlineInputBorder(
                                                                  borderSide: const BorderSide(
                                                                      color: Colors.black, width: 0.5),
                                                                  borderRadius: BorderRadius.circular(100),
                                                                ),
                                                                focusedBorder: OutlineInputBorder(
                                                                  borderSide: const BorderSide(
                                                                      color: Colors.black, width: 0.5),
                                                                  borderRadius: BorderRadius.circular(100),
                                                                ),
                                                                enabledBorder: OutlineInputBorder(
                                                                  borderSide: const BorderSide(
                                                                      color: Colors.black, width: 0.5),
                                                                  borderRadius: BorderRadius.circular(100),
                                                                ),
                                                                hintText: 'رقم حساب الدفع'
                                                            ),
                                                            style: const TextStyle(color: Colors.black,fontSize: 18)),

                                                        SizedBox(height: Get.height*0.025,),





                                                        SizedBox(height: Get.height*0.03,)
                                                      ]),
                                                );}))),
                                  onPressed: ()async{
                                    SystemChannels.textInput.invokeMethod('TextInput.hide');
                                    var states = controller.form.currentState;
                                    if (states!.validate()) {
                                      await SystemChannels.textInput.invokeMethod('TextInput.hide');

                                      controller.payment_order();

                                    }
                                    else
                                    {
                                      controller.btnController.reset();
                                      SystemChannels.textInput.invokeMethod('TextInput.hide');
                                    }

                                  },
                                  title: 'عملية الدفع',
                                  btnOkText: 'دفع',
                                  btnCancelText: 'الغاء'
                              );
                            }
                        ),
                      if(controller.orderDetails.first.isPayment==0)
                        SizedBox(width: 10,),
                      ALConstantsWidget.elevatedButtonWithStyle(
                          text: TranslationKeys.cancel.tr,
                          colors: AppColors.secondaryColor,
                          textColor: AppColors.whiteColor,
                          onTap: (){
                            ALConstantsWidget.awesomeDialog(
                              controller: null,
                              child:Text('إلغاء الطلب؟',style: TextStyle(fontSize: 21,fontWeight: FontWeight.w800),) ,
                              onPressed: (){
                                controller.deleteOrder();
                              },
                              title: 'إلغاء الطلب؟',
                              btnOkText: 'نعم',
                              btnCancelText: 'لا'
                            );
                          }
                      ),
                    ],
                  ),
                if(controller.orderDetails.first.status=='pending')
                const SizedBox(height: 20,),
                if(controller.orderDetails.first.status=='under_delivery')
                  ALConstantsWidget.elevatedButtonWithStyle(
                      text: 'تم استلام',
                      colors: AppColors.secondaryColor,
                      textColor: AppColors.whiteColor,
                      onTap: (){
                        ALConstantsWidget.awesomeDialog(
                            controller: null,
                            child:Text('هل استلمت الطلب؟',style: TextStyle(fontSize: 21,fontWeight: FontWeight.w800),) ,
                            onPressed: (){
                              controller.received_order();
                            },
                            title: '',
                            btnOkText: 'نعم',
                            btnCancelText: 'لا'
                        );
                      }
                  ),
                if(controller.orderDetails.first.status=='under_delivery')
                  const SizedBox(height: 20,),

              ],
            ),


          ),



          Container(width: Get.width,margin: const EdgeInsets.only(top: 25),child:

          AnimationLimiter(
            child: ListView.builder(
                physics: NeverScrollableScrollPhysics(),
                padding: EdgeInsets.only(bottom: Get.height*0.01),
                shrinkWrap: true,
                primary: false,
                itemCount: controller.orderDetails.first.cart!.length,
                itemBuilder: (context,index){
                  Cart items =controller.orderDetails.first.cart![index];
                  return AnimationConfiguration.staggeredGrid(
                      position: index,
                      duration: const Duration(milliseconds: 500),
                      columnCount: 2,
                      child: ScaleAnimation(
                          duration: const Duration(milliseconds: 900),
                          curve: Curves.fastLinearToSlowEaseIn,
                          child: FadeInAnimation(
                            child:  Container(
                              margin: const EdgeInsets.only(top: 5),
                              child: ALCarts(
                                key: UniqueKey(),
                                carts: items,
                              ),
                            ),)));
                }),))
        ],
      ),
    );

  }

  Widget errorPage () {
    return ALConstantsWidget.errorServer(callBack: (){
      controller.onInit();
    });
  }

  Future setAvatar({required  ImageSource imageSource}) async {
    try {
      final image = await ImagePicker().pickImage(source: imageSource,imageQuality:Platform.isIOS ? 10:50);
      if (image == null) return;
      final imageUser = File(image.path);

      int sizeInBytes = imageUser.lengthSync();
      double sizeInMb = sizeInBytes / (1024 * 1024);
        controller.byteImage =imageUser;
        controller.imageUser.value=base64Encode(imageUser.readAsBytesSync());

    } on PlatformException {}
  }

}




