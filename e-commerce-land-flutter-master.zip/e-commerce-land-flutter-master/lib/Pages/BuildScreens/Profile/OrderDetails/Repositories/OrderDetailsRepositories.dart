import 'dart:io';

import 'package:http/http.dart';
import 'package:shopping_land/Model/Model/ServerResponse.dart';

import '../../../../../Model/Repositories/ApiClient/ALApiClient.dart';

class OrderDetailsRepositories {
  ServerResponse message = ServerResponse();

  Future<bool> display_order_by_id({dynamic bodyData}) async {
    try {
      var response = await ALApiClient(
        bodyData: bodyData,
        methode: 'display-order-by-id',
      ).request(get: true);

      if (response.runtimeType != bool) {
        message = dataServerResponseFromJson(response).first;
        if (message.state == 1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } catch (e) {
      print("Error Api login Hear: $e");
      return false;
    }
  }

  Future<bool> display_payment_method_by_id({dynamic bodyData}) async {
    try {
      var response = await ALApiClient(
        bodyData: bodyData,
        methode: 'display_payment_method_by_id',
      ).request(get: true);

      if (response.runtimeType != bool) {
        message = dataServerResponseFromJson(response).first;
        if (message.state == 1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } catch (e) {
      print("Error Api login Hear: $e");
      return false;
    }
  }

  Future<bool> add_rate({dynamic bodyData}) async {
    try {
      var response = await ALApiClient(
        bodyData: bodyData,
        methode: 'add-rate',
      ).request();

      if (response.runtimeType != bool) {
        message = dataServerResponseFromJson(response).first;
        if (message.state == 1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } catch (e) {
      print("Error Api login Hear: $e");
      return false;
    }
  }

  Future<bool> add_rate_service({dynamic bodyData}) async {
    try {
      var response = await ALApiClient(
        bodyData: bodyData,
        methode: 'add-rate-service',
      ).request();

      if (response.runtimeType != bool) {
        message = dataServerResponseFromJson(response).first;
        if (message.state == 1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } catch (e) {
      print("Error Api login Hear: $e");
      return false;
    }
  }

  Future<bool> received_order({dynamic bodyData}) async {
    try {
      var response = await ALApiClient(
        bodyData: bodyData,
        methode: 'received_order',
      ).request();

      if (response.runtimeType != bool) {
        message = dataServerResponseFromJson(response).first;
        if (message.state == 1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } catch (e) {
      print("Error Api login Hear: $e");
      return false;
    }
  }

  Future<bool> payment_order({dynamic bodyData}) async {
    try {
     

      var response = await ALApiClient(

        bodyData: bodyData,
        methode: 'payment_order',
      ).request(isMulti: true);

      if (response.runtimeType != bool) {
        message = dataServerResponseFromJson(response).first;
        if (message.state == 1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } catch (e) {
      print("Error Api payment_order: $e");
      return false;
    }
  }

  Future<bool> canceled_order({dynamic bodyData}) async {
    try {
      var response = await ALApiClient(
        bodyData: bodyData,
        methode: 'canceled-order',
      ).request();

      if (response.runtimeType != bool) {
        message = dataServerResponseFromJson(response).first;
        if (message.state == 1) {
          return true;
        } else {
          return false;
        }
      } else {
        return false;
      }
    } catch (e) {
      print("Error Api login Hear: $e");
      return false;
    }
  }
}
