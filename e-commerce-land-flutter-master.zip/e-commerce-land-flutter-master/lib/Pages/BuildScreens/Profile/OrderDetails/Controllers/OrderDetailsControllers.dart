import 'dart:convert';
import 'dart:io';

import 'package:animated_rating_bar/animated_rating_bar.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svprogresshud/flutter_svprogresshud.dart';
import 'package:get/get.dart';
import 'package:shopping_land/packages/rounded_loading_button-2.1.0/rounded_loading_button.dart';
import 'package:shopping_land/ALConstants/ALConstantsWidget.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/Model/Model/DetailPayment.dart';
import 'package:shopping_land/Model/Model/OrderDetails.dart';
import 'package:shopping_land/Model/Model/OrderHistory.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/OrderDetails/Repositories/OrderDetailsRepositories.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/OrderHistory/Controllers/OrderHistoryControllers.dart';
import 'package:http/http.dart' as http;

class OrderDetailsControllers extends GetxController {
  RoundedLoadingButtonController btnController =
      RoundedLoadingButtonController();
  Rx<File>? image;
  Rx<File>? pdfFile;

  var byteImage;
  RxList<DetailPayment> detailPayment = <DetailPayment>[].obs;
  RxString imageUser = ''.obs;
  RxBool isImage = false.obs;
  RxBool isImageFind = false.obs;
  RxList<OrderDetailsM> orderDetails = <OrderDetailsM>[].obs;
  late String title;
  int ratingVal = 1;
  GlobalKey<FormState> form = GlobalKey<FormState>();

  TextEditingController numberAccount = TextEditingController(text: '');

  RxInt pageState = 1.obs;
  late OrderModel order;
  OrderDetailsControllers() {
    order = Get.arguments['order'];
    title = Get.arguments['title'];
  }

  Future<void> display_order_by_id() async {
    try {
      pageState.value = 0;
      OrderDetailsRepositories repositories = OrderDetailsRepositories();
      if (await repositories
          .display_order_by_id(bodyData: {'order_id': order.id.toString()})) {
        if (repositories.message.data != null) {
          var data = json.decode(json.decode(repositories.message.data));
          orderDetails.value = dataOrderDetailsMFromJson(json.encode([data]));
        }
        if (orderDetails.first.isPayment == 0) {
          await display_payment_method_by_id();
        }
        pageState.value = 1;
      } else {
        pageState.value = 2;
      }
    } catch (E) {
      pageState.value = 2;
    }
  }

  Future<void> display_payment_method_by_id() async {
    try {
      pageState.value = 0;
      OrderDetailsRepositories repositories = OrderDetailsRepositories();
      if (await repositories.display_payment_method_by_id(bodyData: {
        'payment_method_id': orderDetails.first.paymentMethodId.toString()
      })) {
        if (repositories.message.data != null) {
          var data = json.decode(json.decode(repositories.message.data));
          print(json.encode([data]));
          detailPayment.value =
              dataDetailPaymentMFromJson(json.encode(data['detail_payment']));
        }
        pageState.value = 1;
      } else {
        pageState.value = 2;
      }
    } catch (E) {
      pageState.value = 2;
    }
  }

  Future<void> add_rate_service() async {
    if (Platform.isIOS) {
      SVProgressHUD.setDefaultAnimationType(SVProgressHUDAnimationType.native);
    }
    SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.light);

    SVProgressHUD.show();
    OrderDetailsRepositories repositories = OrderDetailsRepositories();
    if (await repositories.add_rate_service(bodyData: {
      'rate': ratingVal.toString(),
      'order_id': order.id.toString()
    })) {
      SVProgressHUD.dismiss();
    } else {
      SVProgressHUD.dismiss();
    }
  }

  Future<void> received_order() async {
    Get.back();
    if (Platform.isIOS) {
      SVProgressHUD.setDefaultAnimationType(SVProgressHUDAnimationType.native);
    }
    SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.light);

    SVProgressHUD.show();
    OrderDetailsRepositories repositories = OrderDetailsRepositories();
    if (await repositories
        .received_order(bodyData: {'order_id': order.id.toString()})) {
      SVProgressHUD.dismiss();
      try {
        OrderHistoryControllers controllers = Get.find();
        controllers.onInit();
        ALConstantsWidget.awesomeDialog(
            controller: null,
            child: SingleChildScrollView(
                physics: const NeverScrollableScrollPhysics(),
                child: Padding(
                    padding: const EdgeInsets.only(left: 8.0, right: 8),
                    child: StatefulBuilder(builder: (context, State) {
                      return Column(children: [
                        Text(
                          'ماهو تقيمك للخدمة؟',
                          style: const TextStyle(
                              fontSize: 24,
                              color: Colors.black,
                              fontWeight: FontWeight.w800),
                        ),
                        SizedBox(
                          height: Get.height * 0.025,
                        ),
                        AnimatedRatingBar(
                          activeFillColor: AppColors.basicColor,
                          strokeColor: AppColors.basicColor,
                          initialRating: 1.0,
                          height: 60,
                          width: Get.width,
                          animationColor: Colors.red,
                          onRatingUpdate: (rating) {
                            ratingVal = int.parse(
                                double.parse(rating.toString())
                                    .toStringAsFixed(0));
                          },
                        ),
                        SizedBox(
                          height: Get.height * 0.03,
                        )
                      ]);
                    }))),
            onPressed: () async {
              Get.back();
              await add_rate_service();
              Get.back();
            },
            btnOkOnPress: () {
              Get.back();
              Get.back();
            },
            title: '',
            btnOkText: 'تاكيد',
            btnCancelText: 'لا');
      } catch (E) {}
    } else {
      SVProgressHUD.dismiss();
    }
  }

  Future<void> deleteOrder() async {
    Get.back();
    if (Platform.isIOS) {
      SVProgressHUD.setDefaultAnimationType(SVProgressHUDAnimationType.native);
    }
    SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.light);

    SVProgressHUD.show();
    OrderDetailsRepositories repositories = OrderDetailsRepositories();
    if (await repositories.canceled_order(
        bodyData: {'order_id': order.id.toString(), 'status': 'canceled'})) {
      SVProgressHUD.dismiss();
      try {
        OrderHistoryControllers controllers = Get.find();
        controllers.onInit();
      } catch (E) {}
    } else {
      SVProgressHUD.dismiss();
    }
  }

  Future<void> payment_order() async {
    OrderDetailsRepositories repositories = OrderDetailsRepositories();

    if (await repositories.payment_order(
      bodyData: {
        'url_image': await http.MultipartFile.fromPath(
            'url_image', image?.value.path ?? ''),
        'number_account': numberAccount.text.toString(),
        'order_id': order.id.toString()
      },
    )) {
      btnController.success();
      Get.back();
      onInit();
    } else {
      btnController.reset();
    }
  }

  @override
  void onInit() {
    super.onInit();
    display_order_by_id();
  }
}
