import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh_flutter3/pull_to_refresh_flutter3.dart';
import 'package:shopping_land/ALConstants/ALConstantsWidget.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/ALConstants/AppPages.dart';
import 'package:shopping_land/ALWidget/ALOrderHistory.dart';
import 'package:shopping_land/Model/Model/OrderHistory.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/OrderHistory/Controllers/OrderHistoryControllers.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';

class OrderHistory extends GetView<OrderHistoryControllers> {
  bool? withSection;

  OrderHistory({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
            statusBarIconBrightness: Brightness.dark,
            systemNavigationBarIconBrightness: Brightness.dark,
            systemNavigationBarColor: Colors.white,
            systemNavigationBarDividerColor: AppColors.whiteColor),
        child: Material(
            color: Colors.white,
            child: Container(
                decoration: BoxDecoration(),
                child: Scaffold(
                  appBar: AppBar(
                      leadingWidth: Get.width * 0.1,
                      titleSpacing: Get.width * 0.001,
                      title: Text(
                        TranslationKeys.profile.tr,
                        style: const TextStyle(
                            color: Colors.black,
                            fontSize: 21,
                            fontWeight: FontWeight.w500),
                      ),
                      backgroundColor: Colors.transparent,
                      elevation: 0,
                      leading: Padding(
                        padding: EdgeInsets.only(
                            right: Get.height * 0.015,
                            left: Get.height * 0.015,
                            top: Get.height * 0.00),
                        child: IconButton(
                          icon: const Icon(Icons.arrow_back_ios,
                              color: Colors.black, size: 18),
                          onPressed: () {
                            Get.back();
                          },
                        ),
                      )),
                  body: Obx(() {
                    switch (controller.pageState.value) {
                      case 0:
                        {
                          return loadingPage();
                        }
                      case 1:
                        {
                          return previewPage();
                        }
                      case 2:
                        {
                          return errorPage();
                        }
                      default:
                        return Container(
                          width: Get.width,
                          height: Get.height,
                          color: Theme.of(Get.context!).colorScheme.background,
                        );
                    }
                  }),
                ))));
  }

  Widget loadingPage() {
    return Center(
      child: ALConstantsWidget.loading(
          height: Get.width / 12, width: Get.width / 12),
    );
  }

  Widget previewPage() {
    return AnimationLimiter(
      child: Stack(
        alignment: Alignment.bottomLeft,
        children: [
          ListView(
            physics: const NeverScrollableScrollPhysics(),
            children: [
              Container(
                  padding: EdgeInsets.only(
                    right: Get.width * 0.05,
                    left: Get.width * 0.05,
                  ),
                  color: Colors.white,
                  child: Text(
                    TranslationKeys.orderHistory.tr,
                    style: const TextStyle(
                        fontSize: 21, fontWeight: FontWeight.w800),
                  )),
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: TabBar(
                  onTap: (int index) {
                    controller.changedIndex(index: index);
                    controller.get_orders();
                  },
                  isScrollable: true,

                  indicatorPadding: EdgeInsets.symmetric(
                      horizontal: Get.width * 0.01,
                      vertical: Get.width * 0.025), // Adjust padding as needed
                  controller: controller.tapController,
                  indicatorColor: AppColors.secondaryColor,
                  unselectedLabelColor: Colors.black,
                  labelColor: AppColors.secondaryColor,

                  indicatorWeight: 3,

                  labelPadding:
                      EdgeInsets.only(top: 10, right: 10, left: 10, bottom: 10),
                  tabs: [
                    FittedBox(
                      child: Text(
                        TranslationKeys.pending.tr,
                        style: TextStyle(fontSize: 18),
                      ),
                    ),
                    FittedBox(
                      child: Text(TranslationKeys.delivered.tr,
                          style: TextStyle(fontSize: 18)),
                    ),
                    FittedBox(
                      child: Text(TranslationKeys.canceled.tr,
                          style: TextStyle(fontSize: 18)),
                    ),
                    FittedBox(
                      child: Text(TranslationKeys.unacceptable.tr,
                          style: TextStyle(fontSize: 18)),
                    ),
                    FittedBox(
                      child: Text(TranslationKeys.processing.tr,
                          style: TextStyle(fontSize: 18)),
                    ),
                    FittedBox(
                      child:
                          Text('الموافق عليها', style: TextStyle(fontSize: 18)),
                    ),
                  ],
                ),
              ),
            ],
          ),
          Container(
            height: Get.height / 1.3,
            child: TabBarView(
              physics: const NeverScrollableScrollPhysics(),
              controller: controller.tapController,
              children: [
                controller.changeIndexState.value
                    ? loadingPage()
                    : Container(
                        height: Get.height * 0.7,
                        width: Get.width,
                        margin:
                            const EdgeInsets.only(top: 0, left: 20, right: 20),
                        child: controller.orderHistory.isEmpty
                            ? ALConstantsWidget.NotFoundData(
                                TranslationKeys.notFoundData.tr)
                            : SmartRefresher(
                                primary: true,
                                enablePullDown: true,
                                enablePullUp: true,
                                header: WaterDropHeader(
                                    waterDropColor: AppColors.secondaryColor,
                                    refresh: ALConstantsWidget.loading(
                                        width: Get.width * 0.1,
                                        height: Get.width * 0.1,
                                        color: AppColors.basicColor),
                                    complete: ALConstantsWidget.smartRefresh()),
                                footer: CustomFooter(
                                  builder:
                                      (BuildContext context, LoadStatus? mode) {
                                    Widget body;
                                    if (mode == LoadStatus.idle) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else if (mode == LoadStatus.loading) {
                                      body = Platform.isAndroid
                                          ? const CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 1,
                                              backgroundColor:
                                                  AppColors.secondaryColor,
                                            )
                                          : CupertinoActivityIndicator(
                                              color: Theme.of(Get.context!)
                                                  .primaryColorDark);
                                    } else if (mode == LoadStatus.failed) {
                                      body = const Text('');
                                    } else if (mode == LoadStatus.canLoading) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else {
                                      body = Text(TranslationKeys.noMore.tr);
                                    }
                                    return DefaultTextStyle(
                                      style: const TextStyle(
                                          fontSize: 14, color: Colors.white),
                                      child: Padding(
                                          padding: EdgeInsets.only(
                                            left: Get.width * 0.27,
                                            right: Get.width * 0.27,
                                          ),
                                          child: SizedBox(
                                            height: mode == LoadStatus.loading
                                                ? 55
                                                : Get.height * 0.04,
                                            child: Stack(
                                              alignment: Alignment.topCenter,
                                              children: [
                                                Container(
                                                  height:
                                                      mode == LoadStatus.loading
                                                          ? 55
                                                          : Get.height * 0.045,
                                                  decoration: BoxDecoration(
                                                      color: mode ==
                                                              LoadStatus.loading
                                                          ? Colors.transparent
                                                          : AppColors
                                                              .secondaryColor,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              18)),
                                                  child: Center(child: body),
                                                ),
                                              ],
                                            ),
                                          )),
                                    );
                                  },
                                ),
                                controller: controller.refreshController,
                                onRefresh: controller.getListOfRefresh,
                                onLoading: controller.getListOfLoading,
                                child: GetBuilder<OrderHistoryControllers>(
                                    init: controller,
                                    builder: (set) => AnimationLimiter(
                                          child: ListView.builder(
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              padding: EdgeInsets.only(
                                                  bottom: Get.height * 0.01),
                                              shrinkWrap: true,
                                              primary: false,
                                              itemCount: controller
                                                  .orderHistory.length,
                                              itemBuilder: (context, index) {
                                                OrderModel item = controller
                                                    .orderHistory[index];
                                                return AnimationConfiguration
                                                    .staggeredGrid(
                                                        position: index,
                                                        duration: const Duration(
                                                            milliseconds: 500),
                                                        columnCount: 2,
                                                        child: ScaleAnimation(
                                                            duration:
                                                                const Duration(
                                                                    milliseconds:
                                                                        900),
                                                            curve: Curves
                                                                .fastLinearToSlowEaseIn,
                                                            child:
                                                                FadeInAnimation(
                                                              child: Container(
                                                                margin:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        top:
                                                                            10),
                                                                child:
                                                                    ALOrderHistory(
                                                                  key:
                                                                      UniqueKey(),
                                                                  onTap: () {
                                                                    Get.toNamed(
                                                                        Routes
                                                                            .OrderDetails,
                                                                        arguments: {
                                                                          'order':
                                                                              item,
                                                                          'title': controller
                                                                              .title
                                                                              .tr
                                                                        });
                                                                  },
                                                                  orderHistoryM:
                                                                      item,
                                                                ),
                                                              ),
                                                            )));
                                              }),
                                        )))),
                controller.changeIndexState.value
                    ? loadingPage()
                    : Container(
                        height: Get.height * 0.7,
                        width: Get.width,
                        margin:
                            const EdgeInsets.only(top: 0, left: 20, right: 20),
                        child: controller.orderHistory.isEmpty
                            ? ALConstantsWidget.NotFoundData(
                                TranslationKeys.notFoundData.tr)
                            : SmartRefresher(
                                primary: true,
                                enablePullDown: true,
                                enablePullUp: true,
                                header: WaterDropHeader(
                                    waterDropColor: AppColors.secondaryColor,
                                    refresh: ALConstantsWidget.loading(
                                        width: Get.width * 0.1,
                                        height: Get.width * 0.1,
                                        color: AppColors.basicColor),
                                    complete: ALConstantsWidget.smartRefresh()),
                                footer: CustomFooter(
                                  builder:
                                      (BuildContext context, LoadStatus? mode) {
                                    Widget body;
                                    if (mode == LoadStatus.idle) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else if (mode == LoadStatus.loading) {
                                      body = Platform.isAndroid
                                          ? const CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 1,
                                              backgroundColor:
                                                  AppColors.secondaryColor,
                                            )
                                          : CupertinoActivityIndicator(
                                              color: Theme.of(Get.context!)
                                                  .primaryColorDark);
                                    } else if (mode == LoadStatus.failed) {
                                      body = const Text('');
                                    } else if (mode == LoadStatus.canLoading) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else {
                                      body = Text(TranslationKeys.noMore.tr);
                                    }
                                    return DefaultTextStyle(
                                      style: const TextStyle(
                                          fontSize: 14, color: Colors.white),
                                      child: Padding(
                                          padding: EdgeInsets.only(
                                            left: Get.width * 0.27,
                                            right: Get.width * 0.27,
                                          ),
                                          child: SizedBox(
                                            height: mode == LoadStatus.loading
                                                ? 55
                                                : Get.height * 0.04,
                                            child: Stack(
                                              alignment: Alignment.topCenter,
                                              children: [
                                                Container(
                                                  height:
                                                      mode == LoadStatus.loading
                                                          ? 55
                                                          : Get.height * 0.045,
                                                  decoration: BoxDecoration(
                                                      color: mode ==
                                                              LoadStatus.loading
                                                          ? Colors.transparent
                                                          : AppColors
                                                              .secondaryColor,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              18)),
                                                  child: Center(child: body),
                                                ),
                                              ],
                                            ),
                                          )),
                                    );
                                  },
                                ),
                                controller: controller.refreshController,
                                onRefresh: controller.getListOfRefresh,
                                onLoading: controller.getListOfLoading,
                                child: GetBuilder<OrderHistoryControllers>(
                                    init: controller,
                                    builder: (set) => AnimationLimiter(
                                          child: ListView.builder(
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              padding: EdgeInsets.only(
                                                  bottom: Get.height * 0.01),
                                              shrinkWrap: true,
                                              primary: false,
                                              itemCount: controller
                                                  .orderHistory.length,
                                              itemBuilder: (context, index) {
                                                OrderModel item = controller
                                                    .orderHistory[index];
                                                return AnimationConfiguration
                                                    .staggeredGrid(
                                                        position: index,
                                                        duration: const Duration(
                                                            milliseconds: 500),
                                                        columnCount: 2,
                                                        child: ScaleAnimation(
                                                            duration:
                                                                const Duration(
                                                                    milliseconds:
                                                                        900),
                                                            curve: Curves
                                                                .fastLinearToSlowEaseIn,
                                                            child:
                                                                FadeInAnimation(
                                                              child: Container(
                                                                margin:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        top:
                                                                            10),
                                                                child:
                                                                    ALOrderHistory(
                                                                  key:
                                                                      UniqueKey(),
                                                                  onTap: () {
                                                                    Get.toNamed(
                                                                        Routes
                                                                            .OrderDetails,
                                                                        arguments: {
                                                                          'order':
                                                                              item,
                                                                          'title': controller
                                                                              .title
                                                                              .tr
                                                                        });
                                                                  },
                                                                  orderHistoryM:
                                                                      item,
                                                                ),
                                                              ),
                                                            )));
                                              }),
                                        )))),
                controller.changeIndexState.value
                    ? loadingPage()
                    : Container(
                        height: Get.height * 0.7,
                        width: Get.width,
                        margin:
                            const EdgeInsets.only(top: 0, left: 20, right: 20),
                        child: controller.orderHistory.isEmpty
                            ? ALConstantsWidget.NotFoundData(
                                TranslationKeys.notFoundData.tr)
                            : SmartRefresher(
                                primary: true,
                                enablePullDown: true,
                                enablePullUp: true,
                                header: WaterDropHeader(
                                    waterDropColor: AppColors.secondaryColor,
                                    refresh: ALConstantsWidget.loading(
                                        width: Get.width * 0.1,
                                        height: Get.width * 0.1,
                                        color: AppColors.basicColor),
                                    complete: ALConstantsWidget.smartRefresh()),
                                footer: CustomFooter(
                                  builder:
                                      (BuildContext context, LoadStatus? mode) {
                                    Widget body;
                                    if (mode == LoadStatus.idle) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else if (mode == LoadStatus.loading) {
                                      body = Platform.isAndroid
                                          ? const CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 1,
                                              backgroundColor:
                                                  AppColors.secondaryColor,
                                            )
                                          : CupertinoActivityIndicator(
                                              color: Theme.of(Get.context!)
                                                  .primaryColorDark);
                                    } else if (mode == LoadStatus.failed) {
                                      body = const Text('');
                                    } else if (mode == LoadStatus.canLoading) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else {
                                      body = Text(TranslationKeys.noMore.tr);
                                    }
                                    return DefaultTextStyle(
                                      style: const TextStyle(
                                          fontSize: 14, color: Colors.white),
                                      child: Padding(
                                          padding: EdgeInsets.only(
                                            left: Get.width * 0.27,
                                            right: Get.width * 0.27,
                                          ),
                                          child: SizedBox(
                                            height: mode == LoadStatus.loading
                                                ? 55
                                                : Get.height * 0.04,
                                            child: Stack(
                                              alignment: Alignment.topCenter,
                                              children: [
                                                Container(
                                                  height:
                                                      mode == LoadStatus.loading
                                                          ? 55
                                                          : Get.height * 0.045,
                                                  decoration: BoxDecoration(
                                                      color: mode ==
                                                              LoadStatus.loading
                                                          ? Colors.transparent
                                                          : AppColors
                                                              .secondaryColor,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              18)),
                                                  child: Center(child: body),
                                                ),
                                              ],
                                            ),
                                          )),
                                    );
                                  },
                                ),
                                controller: controller.refreshController,
                                onRefresh: controller.getListOfRefresh,
                                onLoading: controller.getListOfLoading,
                                child: GetBuilder<OrderHistoryControllers>(
                                    init: controller,
                                    builder: (set) => AnimationLimiter(
                                          child: ListView.builder(
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              padding: EdgeInsets.only(
                                                  bottom: Get.height * 0.01),
                                              shrinkWrap: true,
                                              primary: false,
                                              itemCount: controller
                                                  .orderHistory.length,
                                              itemBuilder: (context, index) {
                                                OrderModel item = controller
                                                    .orderHistory[index];
                                                return AnimationConfiguration
                                                    .staggeredGrid(
                                                        position: index,
                                                        duration: const Duration(
                                                            milliseconds: 500),
                                                        columnCount: 2,
                                                        child: ScaleAnimation(
                                                            duration:
                                                                const Duration(
                                                                    milliseconds:
                                                                        900),
                                                            curve: Curves
                                                                .fastLinearToSlowEaseIn,
                                                            child:
                                                                FadeInAnimation(
                                                              child: Container(
                                                                margin:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        top:
                                                                            10),
                                                                child:
                                                                    ALOrderHistory(
                                                                  key:
                                                                      UniqueKey(),
                                                                  onTap: () {
                                                                    Get.toNamed(
                                                                        Routes
                                                                            .OrderDetails,
                                                                        arguments: {
                                                                          'order':
                                                                              item,
                                                                          'title': controller
                                                                              .title
                                                                              .tr
                                                                        });
                                                                  },
                                                                  orderHistoryM:
                                                                      item,
                                                                ),
                                                              ),
                                                            )));
                                              }),
                                        )))),
                controller.changeIndexState.value
                    ? loadingPage()
                    : Container(
                        height: Get.height * 0.7,
                        width: Get.width,
                        margin:
                            const EdgeInsets.only(top: 0, left: 20, right: 20),
                        child: controller.orderHistory.isEmpty
                            ? ALConstantsWidget.NotFoundData(
                                TranslationKeys.notFoundData.tr)
                            : SmartRefresher(
                                primary: true,
                                enablePullDown: true,
                                enablePullUp: true,
                                header: WaterDropHeader(
                                    waterDropColor: AppColors.secondaryColor,
                                    refresh: ALConstantsWidget.loading(
                                        width: Get.width * 0.1,
                                        height: Get.width * 0.1,
                                        color: AppColors.basicColor),
                                    complete: ALConstantsWidget.smartRefresh()),
                                footer: CustomFooter(
                                  builder:
                                      (BuildContext context, LoadStatus? mode) {
                                    Widget body;
                                    if (mode == LoadStatus.idle) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else if (mode == LoadStatus.loading) {
                                      body = Platform.isAndroid
                                          ? const CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 1,
                                              backgroundColor:
                                                  AppColors.secondaryColor,
                                            )
                                          : CupertinoActivityIndicator(
                                              color: Theme.of(Get.context!)
                                                  .primaryColorDark);
                                    } else if (mode == LoadStatus.failed) {
                                      body = const Text('');
                                    } else if (mode == LoadStatus.canLoading) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else {
                                      body = Text(TranslationKeys.noMore.tr);
                                    }
                                    return DefaultTextStyle(
                                      style: const TextStyle(
                                          fontSize: 14, color: Colors.white),
                                      child: Padding(
                                          padding: EdgeInsets.only(
                                            left: Get.width * 0.27,
                                            right: Get.width * 0.27,
                                          ),
                                          child: SizedBox(
                                            height: mode == LoadStatus.loading
                                                ? 55
                                                : Get.height * 0.04,
                                            child: Stack(
                                              alignment: Alignment.topCenter,
                                              children: [
                                                Container(
                                                  height:
                                                      mode == LoadStatus.loading
                                                          ? 55
                                                          : Get.height * 0.045,
                                                  decoration: BoxDecoration(
                                                      color: mode ==
                                                              LoadStatus.loading
                                                          ? Colors.transparent
                                                          : AppColors
                                                              .secondaryColor,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              18)),
                                                  child: Center(child: body),
                                                ),
                                              ],
                                            ),
                                          )),
                                    );
                                  },
                                ),
                                controller: controller.refreshController,
                                onRefresh: controller.getListOfRefresh,
                                onLoading: controller.getListOfLoading,
                                child: GetBuilder<OrderHistoryControllers>(
                                    init: controller,
                                    builder: (set) => AnimationLimiter(
                                          child: ListView.builder(
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              padding: EdgeInsets.only(
                                                  bottom: Get.height * 0.01),
                                              shrinkWrap: true,
                                              primary: false,
                                              itemCount: controller
                                                  .orderHistory.length,
                                              itemBuilder: (context, index) {
                                                OrderModel item = controller
                                                    .orderHistory[index];
                                                return AnimationConfiguration
                                                    .staggeredGrid(
                                                        position: index,
                                                        duration: const Duration(
                                                            milliseconds: 500),
                                                        columnCount: 2,
                                                        child: ScaleAnimation(
                                                            duration:
                                                                const Duration(
                                                                    milliseconds:
                                                                        900),
                                                            curve: Curves
                                                                .fastLinearToSlowEaseIn,
                                                            child:
                                                                FadeInAnimation(
                                                              child: Container(
                                                                margin:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        top:
                                                                            10),
                                                                child:
                                                                    ALOrderHistory(
                                                                  key:
                                                                      UniqueKey(),
                                                                  onTap: () {
                                                                    Get.toNamed(
                                                                        Routes
                                                                            .OrderDetails,
                                                                        arguments: {
                                                                          'order':
                                                                              item,
                                                                          'title': controller
                                                                              .title
                                                                              .tr
                                                                        });
                                                                  },
                                                                  orderHistoryM:
                                                                      item,
                                                                ),
                                                              ),
                                                            )));
                                              }),
                                        )))),
                controller.changeIndexState.value
                    ? loadingPage()
                    : Container(
                        height: Get.height * 0.7,
                        width: Get.width,
                        margin:
                            const EdgeInsets.only(top: 0, left: 20, right: 20),
                        child: controller.orderHistory.isEmpty
                            ? ALConstantsWidget.NotFoundData(
                                TranslationKeys.notFoundData.tr)
                            : SmartRefresher(
                                primary: true,
                                enablePullDown: true,
                                enablePullUp: true,
                                header: WaterDropHeader(
                                    waterDropColor: AppColors.secondaryColor,
                                    refresh: ALConstantsWidget.loading(
                                        width: Get.width * 0.1,
                                        height: Get.width * 0.1,
                                        color: AppColors.basicColor),
                                    complete: ALConstantsWidget.smartRefresh()),
                                footer: CustomFooter(
                                  builder:
                                      (BuildContext context, LoadStatus? mode) {
                                    Widget body;
                                    if (mode == LoadStatus.idle) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else if (mode == LoadStatus.loading) {
                                      body = Platform.isAndroid
                                          ? const CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 1,
                                              backgroundColor:
                                                  AppColors.secondaryColor,
                                            )
                                          : CupertinoActivityIndicator(
                                              color: Theme.of(Get.context!)
                                                  .primaryColorDark);
                                    } else if (mode == LoadStatus.failed) {
                                      body = const Text('');
                                    } else if (mode == LoadStatus.canLoading) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else {
                                      body = Text(TranslationKeys.noMore.tr);
                                    }
                                    return DefaultTextStyle(
                                      style: const TextStyle(
                                          fontSize: 14, color: Colors.white),
                                      child: Padding(
                                          padding: EdgeInsets.only(
                                            left: Get.width * 0.27,
                                            right: Get.width * 0.27,
                                          ),
                                          child: SizedBox(
                                            height: mode == LoadStatus.loading
                                                ? 55
                                                : Get.height * 0.04,
                                            child: Stack(
                                              alignment: Alignment.topCenter,
                                              children: [
                                                Container(
                                                  height:
                                                      mode == LoadStatus.loading
                                                          ? 55
                                                          : Get.height * 0.045,
                                                  decoration: BoxDecoration(
                                                      color: mode ==
                                                              LoadStatus.loading
                                                          ? Colors.transparent
                                                          : AppColors
                                                              .secondaryColor,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              18)),
                                                  child: Center(child: body),
                                                ),
                                              ],
                                            ),
                                          )),
                                    );
                                  },
                                ),
                                controller: controller.refreshController,
                                onRefresh: controller.getListOfRefresh,
                                onLoading: controller.getListOfLoading,
                                child: GetBuilder<OrderHistoryControllers>(
                                    init: controller,
                                    builder: (set) => AnimationLimiter(
                                          child: ListView.builder(
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              padding: EdgeInsets.only(
                                                  bottom: Get.height * 0.01),
                                              shrinkWrap: true,
                                              primary: false,
                                              itemCount: controller
                                                  .orderHistory.length,
                                              itemBuilder: (context, index) {
                                                OrderModel item = controller
                                                    .orderHistory[index];
                                                return AnimationConfiguration
                                                    .staggeredGrid(
                                                        position: index,
                                                        duration: const Duration(
                                                            milliseconds: 500),
                                                        columnCount: 2,
                                                        child: ScaleAnimation(
                                                            duration:
                                                                const Duration(
                                                                    milliseconds:
                                                                        900),
                                                            curve: Curves
                                                                .fastLinearToSlowEaseIn,
                                                            child:
                                                                FadeInAnimation(
                                                              child: Container(
                                                                margin:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        top:
                                                                            10),
                                                                child:
                                                                    ALOrderHistory(
                                                                  key:
                                                                      UniqueKey(),
                                                                  onTap: () {
                                                                    Get.toNamed(
                                                                        Routes
                                                                            .OrderDetails,
                                                                        arguments: {
                                                                          'order':
                                                                              item,
                                                                          'title': controller
                                                                              .title
                                                                              .tr
                                                                        });
                                                                  },
                                                                  orderHistoryM:
                                                                      item,
                                                                ),
                                                              ),
                                                            )));
                                              }),
                                        )))),
                controller.changeIndexState.value
                    ? loadingPage()
                    : Container(
                        height: Get.height * 0.7,
                        width: Get.width,
                        margin:
                            const EdgeInsets.only(top: 0, left: 20, right: 20),
                        child: controller.orderHistory.isEmpty
                            ? ALConstantsWidget.NotFoundData(
                                TranslationKeys.notFoundData.tr)
                            : SmartRefresher(
                                primary: true,
                                enablePullDown: true,
                                enablePullUp: true,
                                header: WaterDropHeader(
                                    waterDropColor: AppColors.secondaryColor,
                                    refresh: ALConstantsWidget.loading(
                                        width: Get.width * 0.1,
                                        height: Get.width * 0.1,
                                        color: AppColors.basicColor),
                                    complete: ALConstantsWidget.smartRefresh()),
                                footer: CustomFooter(
                                  builder:
                                      (BuildContext context, LoadStatus? mode) {
                                    Widget body;
                                    if (mode == LoadStatus.idle) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else if (mode == LoadStatus.loading) {
                                      body = Platform.isAndroid
                                          ? const CircularProgressIndicator(
                                              color: Colors.white,
                                              strokeWidth: 1,
                                              backgroundColor:
                                                  AppColors.secondaryColor,
                                            )
                                          : CupertinoActivityIndicator(
                                              color: Theme.of(Get.context!)
                                                  .primaryColorDark);
                                    } else if (mode == LoadStatus.failed) {
                                      body = const Text('');
                                    } else if (mode == LoadStatus.canLoading) {
                                      body =
                                          Text(TranslationKeys.moreProduct.tr);
                                    } else {
                                      body = Text(TranslationKeys.noMore.tr);
                                    }
                                    return DefaultTextStyle(
                                      style: const TextStyle(
                                          fontSize: 14, color: Colors.white),
                                      child: Padding(
                                          padding: EdgeInsets.only(
                                            left: Get.width * 0.27,
                                            right: Get.width * 0.27,
                                          ),
                                          child: SizedBox(
                                            height: mode == LoadStatus.loading
                                                ? 55
                                                : Get.height * 0.04,
                                            child: Stack(
                                              alignment: Alignment.topCenter,
                                              children: [
                                                Container(
                                                  height:
                                                      mode == LoadStatus.loading
                                                          ? 55
                                                          : Get.height * 0.045,
                                                  decoration: BoxDecoration(
                                                      color: mode ==
                                                              LoadStatus.loading
                                                          ? Colors.transparent
                                                          : AppColors
                                                              .secondaryColor,
                                                      borderRadius:
                                                          BorderRadius.circular(
                                                              18)),
                                                  child: Center(child: body),
                                                ),
                                              ],
                                            ),
                                          )),
                                    );
                                  },
                                ),
                                controller: controller.refreshController,
                                onRefresh: controller.getListOfRefresh,
                                onLoading: controller.getListOfLoading,
                                child: GetBuilder<OrderHistoryControllers>(
                                    init: controller,
                                    builder: (set) => AnimationLimiter(
                                          child: ListView.builder(
                                              physics:
                                                  NeverScrollableScrollPhysics(),
                                              padding: EdgeInsets.only(
                                                  bottom: Get.height * 0.01),
                                              shrinkWrap: true,
                                              primary: false,
                                              itemCount: controller
                                                  .orderHistory.length,
                                              itemBuilder: (context, index) {
                                                OrderModel item = controller
                                                    .orderHistory[index];
                                                return AnimationConfiguration
                                                    .staggeredGrid(
                                                        position: index,
                                                        duration: const Duration(
                                                            milliseconds: 500),
                                                        columnCount: 2,
                                                        child: ScaleAnimation(
                                                            duration:
                                                                const Duration(
                                                                    milliseconds:
                                                                        900),
                                                            curve: Curves
                                                                .fastLinearToSlowEaseIn,
                                                            child:
                                                                FadeInAnimation(
                                                              child: Container(
                                                                margin:
                                                                    const EdgeInsets
                                                                        .only(
                                                                        top:
                                                                            10),
                                                                child:
                                                                    ALOrderHistory(
                                                                  key:
                                                                      UniqueKey(),
                                                                  onTap: () {
                                                                    Get.toNamed(
                                                                        Routes
                                                                            .OrderDetails,
                                                                        arguments: {
                                                                          'order':
                                                                              item,
                                                                          'title': controller
                                                                              .title
                                                                              .tr
                                                                        });
                                                                  },
                                                                  orderHistoryM:
                                                                      item,
                                                                ),
                                                              ),
                                                            )));
                                              }),
                                        )))),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget errorPage() {
    return ALConstantsWidget.errorServer(callBack: () {
      controller.onInit();
    });
  }
}
