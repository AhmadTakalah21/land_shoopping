import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh_flutter3/pull_to_refresh_flutter3.dart';
import 'package:shopping_land/Model/Model/OrderHistory.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/OrderHistory/Repositories/OrderHistoryRepositories.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';

class OrderHistoryControllers extends GetxController
    with GetTickerProviderStateMixin {
  RefreshController refreshController =
      RefreshController(initialRefresh: false);
  OrderHistoryStatus orderHistoryStatus = OrderHistoryStatus.pending;
  RxInt pageState = 1.obs;
  RxBool changeIndexState = false.obs;
  String title = TranslationKeys.pending.tr;
  RxList<OrderModel> orderHistory = <OrderModel>[].obs;
  late TabController tapController =
      TabController(length: 6, initialIndex: 0, vsync: this);
  GlobalKey<FormState> form = GlobalKey<FormState>();
  bool empty = false;
  int page = 2;

  Future<void> get_orders() async {
    pageState.value = 0;
    OrderHistoryRepositories repositories = OrderHistoryRepositories();
    if (await repositories.display_orders(
        bodyData: {'perPage': '10', 'status': orderHistoryStatus.name})) {
      if (repositories.message.data != null) {
        var data = json.decode(json.decode(repositories.message.data));
        print(json.encode(data['orders']));
        orderHistory.value =
            dataOrderHistoryMFromJson(json.encode(data['orders']));
      }
      pageState.value = 1;
    } else {
      pageState.value = 2;
    }
  }

  Future<void> getOrdersStatus() async {
    OrderHistoryRepositories repositories = OrderHistoryRepositories();
    if (await repositories
        .display_orders(bodyData: {'status': orderHistoryStatus.name})) {
      orderHistory.clear();
      if (repositories.message.data != null) {
        var data = json.decode(json.decode(repositories.message.data));
        orderHistory.value =
            dataOrderHistoryMFromJson(json.encode(data['orders']));
      }
      changeIndexState.value = false;
    } else {
      pageState.value = 2;
    }
  }

  Future<void> changedIndex({required int index}) async {
    refreshController = RefreshController(initialRefresh: false);
    OrderHistoryStatus newOrderHistoryStatus = OrderHistoryStatus.delivered;
    switch (index) { 
      case 0:
        {
          newOrderHistoryStatus = OrderHistoryStatus.pending;
          title = TranslationKeys.pending.tr;
          break;
        }
      case 1:
        {
          newOrderHistoryStatus = OrderHistoryStatus.delivered;
          title = TranslationKeys.delivered.tr;
          break;
        }
      case 2:
        {
          newOrderHistoryStatus = OrderHistoryStatus.canceled;
          title = TranslationKeys.canceled.tr;
          break;
        }
      case 3:
        {
          newOrderHistoryStatus = OrderHistoryStatus.unacceptable;
          title = TranslationKeys.unacceptable.tr;
          break;
        }

      case 4:
        {
          newOrderHistoryStatus = OrderHistoryStatus.under_delivery;
          title = TranslationKeys.processing.tr;
          break;
        }
      case 5:
        {
          newOrderHistoryStatus = OrderHistoryStatus.processing;
          title = TranslationKeys.processing.tr;
          break;
        }
    }
    if (newOrderHistoryStatus != orderHistoryStatus) {
      orderHistoryStatus = newOrderHistoryStatus;
      changeIndexState.value = true;
      await getOrdersStatus();
    }
  }

  Future<void> getListOfRefresh() async {
    try {
      page = 2;
      empty = false;
      OrderHistoryRepositories repositories = OrderHistoryRepositories();
      if (await repositories.display_orders(
          bodyData: {'perPage': '10', 'status': orderHistoryStatus.name})) {
        if (repositories.message.data != null) {
          var data = json.decode(json.decode(repositories.message.data));
          orderHistory.value =
              dataOrderHistoryMFromJson(json.encode(data['orders']));
        }
        refreshController.refreshCompleted();
      } else {
        refreshController.refreshFailed();
      }
    } catch (e) {
      refreshController.refreshFailed();
    }
  }

  Future<void> getListOfLoading() async {
    if (empty) {
      refreshController.loadNoData();
    } else {
      try {
        OrderHistoryRepositories repositories = OrderHistoryRepositories();

        Map<String, String> body = {
          'perPage': '10',
          'status': orderHistoryStatus.name,
          'page': page.toString(),
        };
        if (await repositories.display_orders(bodyData: body)) {
          RxList<OrderModel> orderHistoryNew = <OrderModel>[].obs;
          if (repositories.message.data != null) {
            var data = json.decode(json.decode(repositories.message.data));

            orderHistoryNew.value =
                dataOrderHistoryMFromJson(json.encode(data));
          }
          if (orderHistoryNew.isEmpty) {
            empty = true;
            refreshController.loadNoData();
          } else {
            orderHistory.addAll(orderHistoryNew);
            refreshController.loadComplete();
            update();
            page++;
          }
        } else {
          refreshController.loadFailed();
        }
      } catch (e) {
        refreshController.loadFailed();
      }
    }
  }

  @override
  void onInit() {

    super.onInit();
    get_orders();
  }
}
