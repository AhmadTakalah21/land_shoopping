

import 'dart:async';

import 'package:animated_custom_dropdown/custom_dropdown.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:get/get.dart';
import 'package:shopping_land/ALConstants/ALConstantsWidget.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/ALProfileWidget.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/ClassModel/ProfileModel.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/Profile/Controllers/ProfileControllers.dart';
import 'package:shopping_land/Pages/MainScreenView/Controllers/MainScreenViewControllers.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';
import 'package:shopping_land/main.dart';

class Profile extends StatefulWidget {
  const Profile({super.key});

  @override
  State<Profile> createState() => _ProfileState();
}

class _ProfileState extends State<Profile> {

  ProfileControllers controller = Get.put(ProfileControllers());
  MainScreenViewControllers controllers = Get.find();
  @override
  Widget build(BuildContext context) {
    return  Scaffold(body:Obx(() {
      switch (controller.pageState.value) {
        case 0:
          {
            return loadingPage();
          }
        case 1:
          {
            return previewPage();
          }
        case 2:
          {
            return errorPage();
          }
        default:
          return Container(width: Get.width, height: Get.height, color: Theme
              .of(Get.context!)
              .colorScheme
              .background,);
      }
    }));


  }



  Widget loadingPage () {
    return Center(child: ALConstantsWidget.loading(height: Get.width/12,width:Get.width/12),);
  }
  Widget previewPage () {
    return  Column(
      children: [
        SingleChildScrollView(
          physics: const NeverScrollableScrollPhysics(),
          child: Column(
            children: [
              Padding(
                padding:  EdgeInsets.only(left: 8,right: 8,top: Get.height*0.04),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceAround,
                  children: [
                    Expanded(child: Text(TranslationKeys.profile.tr,style: const TextStyle(fontSize: 21,fontWeight: FontWeight.w700),)),
                    GetX<ProfileControllers>(init: controller,builder: (set)=>controller.isSaveProfile.value  ?  Container(margin: EdgeInsets.only(left: Get.width*0.04,bottom: 18,top: 5),child: ALConstantsWidget.loading(height: Get.width/16,width:Get.width/16)) :
                    TextButton(onPressed: (){
                      controller.saveProfile();
                    }, child: Text('حفظ'),style: ButtonStyle(
                        overlayColor:  MaterialStateProperty.all(AppColors.basicColor.withOpacity(0.1)),
                        foregroundColor: MaterialStateProperty.all(AppColors.basicColor)),))
                  ],
                ),
              ),
            ],
          ),
        ),
        SizedBox(height: 10,),
        Expanded(child:
        AnimationLimiter(
          child: ListView.builder(

              physics:
              const BouncingScrollPhysics(parent:  AlwaysScrollableScrollPhysics()),
              itemCount: controller.profile.length,
              itemBuilder: (BuildContext context, int index) {
                var item =controller.profile[index];

                return AnimationConfiguration.staggeredGrid(
                    position: index,
                    duration: const Duration(milliseconds: 500),
                    columnCount: 2,
                    child: ScaleAnimation(
                        duration: const Duration(milliseconds: 900),
                        curve: Curves.fastLinearToSlowEaseIn,
                        child: FadeInAnimation(
                          child:item.styleTypeType== ProfileModelStyleType.dropDown?

                          Container(
                            height: Get.height*0.08,
                            child: GetBuilder<MainScreenViewControllers>(init: controllers,builder: (state)=>controllers.cities.isEmpty  ?const SizedBox():
                            CustomDropdown<String>(
                              maxlines: 5,
                              decoration: CustomDropdownDecoration(
                                closedBorderRadius: BorderRadius.zero,


                                  closedFillColor: const Color(0xFFF2F2F2),
                                  listItemStyle: TextStyle(fontSize: 13),
                                  headerStyle: TextStyle(fontSize: 13),


                                  closedBorder: Border.all(color: AppColors.grayColor,width: 0.2),


                                  searchFieldDecoration: SearchFieldDecoration(

                                    suffixIcon: (onClear){
                                      return IconButton(splashRadius: 20,onPressed:  onClear, icon: Icon(Icons.close,color: AppColors.secondaryColor,));
                                    },
                                    prefixIcon: Icon(Icons.search,color: AppColors.secondaryColor,),
                                  )
                              ),
                              closedHeaderPadding: EdgeInsets.only(top: 10,bottom: 10,right: 16,left:16),
                              items: controllers.cities.map((element) => element.name.toString()).toList(),
                              excludeSelected: false,

                              hintText: controllers.citiesName.value,


                              onChanged: (value)async {
                                if(controllers.citiesName.value!=value)
                                {

                                  alSettings.citiesId.value=controllers.cities.value.where((element) => element.name==value).first.id.toString();
                                  alSettings.update();
                                  controllers.citiesName.value=controllers.cities.value.where((element) => element.id.toString()== alSettings.citiesId.value).first.name.toString();
                                  alSettings.currentUser!.citiesId=alSettings.citiesId.value;
                                  ALMethode.setUserInfo(data: alSettings.currentUser!);

                                }
                              },
                            ),),
                          )
                         : item.styleTypeType== ProfileModelStyleType.textForm?
                          TextFormField(
                            textDirection: TextDirection.rtl,
                            controller: item.controller,
                              keyboardType: item.withPhone!=null? TextInputType.number:null,
                            inputFormatters:  item.withPhone!=null?[
                                FilteringTextInputFormatter.deny(RegExp(r'[-,]')),
                              ]:[],
                            cursorColor: AppColors.secondaryColor,
                            decoration: InputDecoration(
                              contentPadding: const EdgeInsets.only(right: 10,left: 10),
                              focusedErrorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(0),borderSide: const BorderSide(width: .8,color: AppColors.grayColor)) ,
                              errorBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(0),borderSide: BorderSide(width: .8,color: Colors.redAccent.shade100)),
                              disabledBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(0),borderSide: const BorderSide(width: .4,color: AppColors.grayColor)) ,
                              focusedBorder: OutlineInputBorder(borderRadius: BorderRadius.circular(0),borderSide: const BorderSide(width: .8,color: AppColors.grayColor)) ,
                              enabledBorder:OutlineInputBorder(borderRadius: BorderRadius.circular(0),borderSide: const BorderSide(width: .4,color: AppColors.grayColor)) ,
                              border: InputBorder.none,
                              hintMaxLines: 1,
                              filled: true,
                              fillColor: Colors.white,
                              hintStyle: const TextStyle(fontSize: 14, color: AppColors.grayColor),
                            ),
                          )
                          :item.title!='العناوين' ?InkWell(
                              borderRadius: BorderRadius.circular(12),
                              child: ALProfileWidget(
                                key: UniqueKey(),
                                profileModel: item,
                              ),onTap:item.styleTypeType== ProfileModelStyleType.logOut || item.styleTypeType== ProfileModelStyleType.onTap ?()async{
                            controller.onPressProfileButton(type: item.type);
                          }:null):
                              Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                mainAxisAlignment: MainAxisAlignment.start,
                                children: [
                                  InkWell(
                                      borderRadius: BorderRadius.circular(12),
                                      child: ALProfileWidget(
                                        key: UniqueKey(),
                                        profileModel: item,
                                      ),onTap:item.styleTypeType== ProfileModelStyleType.logOut || item.styleTypeType== ProfileModelStyleType.onTap ?()async{
                                    controller.onPressProfileButton(type: item.type);
                                  }:null),
                                  InkWell(
                                      borderRadius: BorderRadius.circular(12),
                                      child: DefaultTextStyle(
                                        style: const TextStyle(
                                            fontSize: 14,
                                            fontWeight: FontWeight.w500
                                        ),
                                        child: Padding(
                                          padding:  EdgeInsets.only(bottom: 0),
                                          child: Container(
                                            width: Get.width,
                                            height: Get.height*0.06,
                                            padding: EdgeInsets.all(Get.width*0.03),
                                            decoration: BoxDecoration(
                                                color:   Colors.white,
                                                border:Border.all(color: AppColors.grayColor,width: 0.2)
                                            ),
                                            child: Text('اضف عنوان',style: TextStyle(color:AppColors.grayColor.withOpacity(0.5)),),
                                          ),
                                        ),
                                      )

                                      ,onTap:()async{
                                    await ALConstantsWidget.awesomeDialog(
                                        controller: controller.btnController,
                                        child:  SingleChildScrollView(
                                            physics: const NeverScrollableScrollPhysics(),
                                            child: Padding(
                                                padding: const EdgeInsets.only(left: 8.0,right: 8),
                                                child: StatefulBuilder(
                                                    builder: (context, State) {

                                                      return  Form(
                                                        key:controller.form,
                                                        child: Column(
                                                            children: [
                                                              Text('عنوان جديد',style: const TextStyle(fontSize: 24,color: AppColors.grayColor,fontWeight: FontWeight.w800),),
                                                              SizedBox(height: Get.height*0.025,),
                                                              ValueListenableBuilder<TextDirection>(
                                                                  valueListenable: controller.addressTextDirection,
                                                                  child: const SizedBox(),
                                                                  builder: (context, valueTextDirection, child) =>
                                                                      TextFormField(
                                                                          textDirection: valueTextDirection,
                                                                          validator: (val){
                                                                            if (val!.trim().isEmpty)
                                                                            {
                                                                              return TranslationKeys.required.tr;
                                                                            }
                                                                            else {
                                                                              return null;
                                                                            }
                                                                          },
                                                                          enabled: true,
                                                                          controller:controller.addressForm,
                                                                          textInputAction: null,
                                                                          maxLines: 1,
                                                                          decoration: InputDecoration(
                                                                              contentPadding:  EdgeInsets.only(top: 5,left: Get.width*0.05,right: Get.width*0.05),
                                                                              hintStyle: TextStyle(color: AppColors.grayColor,fontSize: 13),                                                                  alignLabelWithHint: true,
                                                                              border: OutlineInputBorder(
                                                                                borderSide: const BorderSide(
                                                                                    color: Colors.black, width: 0.5),
                                                                                borderRadius: BorderRadius.circular(100),
                                                                              ),
                                                                              focusedBorder: OutlineInputBorder(
                                                                                borderSide: const BorderSide(
                                                                                    color: Colors.black, width: 0.5),
                                                                                borderRadius: BorderRadius.circular(100),
                                                                              ),
                                                                              enabledBorder: OutlineInputBorder(
                                                                                borderSide: const BorderSide(
                                                                                    color: Colors.black, width: 0.5),
                                                                                borderRadius: BorderRadius.circular(100),
                                                                              ),
                                                                              hintText: 'عنوان'
                                                                          ),
                                                                          style: const TextStyle(color: Colors.black,fontSize: 18))),
                                                              SizedBox(height: Get.height*0.02,),
                                                              ValueListenableBuilder<TextDirection>(
                                                                  valueListenable: controller.addressTextDirection,
                                                                  child: const SizedBox(),
                                                                  builder: (context, valueTextDirection, child) =>
                                                                      TextFormField(
                                                                          textDirection: valueTextDirection,
                                                                          validator: (val){
                                                                            if (val!.trim().isEmpty)
                                                                            {
                                                                              return TranslationKeys.required.tr;
                                                                            }
                                                                            else {
                                                                              return null;
                                                                            }
                                                                          },
                                                                          enabled: true,
                                                                          controller:controller.streetName,
                                                                          textInputAction: null,
                                                                          maxLines: 1,
                                                                          decoration: InputDecoration(
                                                                              contentPadding:  EdgeInsets.only(top: 5,left: Get.width*0.05,right: Get.width*0.05),
                                                                              hintStyle: TextStyle(color: AppColors.grayColor,fontSize: 13),                                                                  alignLabelWithHint: true,
                                                                              border: OutlineInputBorder(
                                                                                borderSide: const BorderSide(
                                                                                    color: Colors.black, width: 0.5),
                                                                                borderRadius: BorderRadius.circular(100),
                                                                              ),
                                                                              focusedBorder: OutlineInputBorder(
                                                                                borderSide: const BorderSide(
                                                                                    color: Colors.black, width: 0.5),
                                                                                borderRadius: BorderRadius.circular(100),
                                                                              ),
                                                                              enabledBorder: OutlineInputBorder(
                                                                                borderSide: const BorderSide(
                                                                                    color: Colors.black, width: 0.5),
                                                                                borderRadius: BorderRadius.circular(100),
                                                                              ),
                                                                              hintText: 'الشارع'
                                                                          ),
                                                                          style: const TextStyle(color: Colors.black,fontSize: 18))),


                                                              SizedBox(height: Get.height*0.03,)

                                                            ]),
                                                      );}))),
                                        title: TranslationKeys.choseLanguage.tr,
                                        btnCancelText: TranslationKeys.cancel,
                                        btnOkText: TranslationKeys.confirm.tr,
                                        onPressed: ()async{
                                          SystemChannels.textInput.invokeMethod('TextInput.hide');
                                          var states = controller.form.currentState;
                                          if (states!.validate()) {
                                            await SystemChannels.textInput.invokeMethod('TextInput.hide');

                                            Map<String,String> body ={
                                              'address':controller.addressForm.text.trim(),
                                               'street_name':controller.streetName.text.trim(),
                                            };
                                            if(await controller.repositories.add_address(body: body))
                                            {

                                              controller.btnController.success();
                                              Timer(const Duration(seconds: 1), () {
                                                Get.back();
                                                controller.onInit();
                                              },
                                              );
                                            }
                                            else
                                            {
                                              controller.btnController.error();
                                              ALMethode.showToast(
                                                  title: TranslationKeys.somethingWentWrong.tr,
                                                  message: controller.repositories.message.description??TranslationKeys.errorEmail.tr,
                                                  type: ToastType.error, context: Get.context!);
                                              Timer(
                                                const Duration(seconds: 1),
                                                    () {
                                                      controller.btnController.reset();
                                                },
                                              );
                                            }
                                            // });

                                          }
                                          else
                                          {
                                            controller.btnController.reset();
                                            SystemChannels.textInput.invokeMethod('TextInput.hide');
                                          }
                                        });
                                  }),
                                  for(int i=0;i<controller.address.length;i++)
                                    DefaultTextStyle(
                                      style: const TextStyle(
                                          fontSize: 14,
                                          fontWeight: FontWeight.w500
                                      ),
                                      child: Padding(
                                        padding:  EdgeInsets.only(bottom: 0),
                                        child: Container(
                                          width: Get.width,

                                          padding: EdgeInsets.all(Get.width*0.03),
                                          decoration: BoxDecoration(
                                              color:   Colors.white,
                                              border:Border.all(color: AppColors.grayColor,width: 0.2)
                                          ),
                                          child: Row(
                                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                            crossAxisAlignment: CrossAxisAlignment.start,
                                            children: [
                                              Expanded(child: Text(controller.address[i].address!+(controller.address[i].streetName!.isNotEmpty?' , شارع : ${controller.address[i].streetName!}':''),maxLines: 5,style: TextStyle(color:AppColors.grayColor),)),
                                              InkWell(
                                                onTap: (){
                                                  ALConstantsWidget.showDialogIosOrAndroid(
                                                      content: " سيتم حذف هذا العنوان \"${controller.address[i].address.toString()} \"" ,
                                                      onPressOKButton: ()async{
                                                        Get.back();
                                                        controller.delete(addressId:controller.address[i].id.toString());

                                                      },
                                                      delete: true,
                                                      towButton: true);
                                                },
                                                focusColor: Colors.transparent,
                                                  hoverColor: Colors.transparent,
                                                  splashColor: Colors.transparent,
                                                  highlightColor: Colors.transparent,
                                                  child: Icon(Icons.remove_circle,size: 18,color: AppColors.readColor)),

                                            ],
                                          ),
                                        ),
                                      ),
                                    )

                                ],
                              )

                          ,)));
              }),))
      ],
    );
  }

  Widget errorPage () {
    return ALConstantsWidget.errorServer(callBack: (){
      controller.onInit();
    });
  }

}
