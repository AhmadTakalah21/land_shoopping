








import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_staggered_animations/flutter_staggered_animations.dart';
import 'package:shopping_land/Services/helper/status_bar.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh_flutter3/pull_to_refresh_flutter3.dart';
import 'package:shopping_land/ALConstants/ALConstantsWidget.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/ALConstants/AppPages.dart';
import 'package:shopping_land/ALWidget/SLItem.dart';
import 'package:shopping_land/Model/Model/OptionWidget.dart';
import 'package:shopping_land/Pages/BuildScreens/Search/Controllers/SearchControllers.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';
import 'package:skeletonizer/skeletonizer.dart';

class Search extends GetView<SearchControllers> {
  bool? withSection;
  Search({
    this.withSection,
    Key? key
  }) : super(key: key);


  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
            statusBarIconBrightness: Brightness.light,
            systemNavigationBarIconBrightness: Brightness.light,
            systemNavigationBarColor: AppColors.basicColor,
            statusBarColor: AppColors.basicColor,
            systemNavigationBarDividerColor: AppColors.basicColor
        ), child: Material(
        child:Scaffold(
            appBar: AppBar(backgroundColor: Colors.transparent,elevation: 0,leading: Padding(
              padding:  EdgeInsets.only(right: Get.height*0.015,left:   Get.height*0.015,top: Get.height*0.0),
              child: IconButton(icon: const Icon(Icons.arrow_back_ios,color: Colors.black),onPressed: (){Get.back();},),
            ),
              actions: [
                Padding(
                    padding: const EdgeInsets.only(top: 10,bottom: 10,left: 10.0),
                    child: SizedBox(
                      width: Get.width*0.85,
                      height: Get.height*0.05,
                      child:GetBuilder<SearchControllers>(init: controller,builder: (set)=>ValueListenableBuilder<TextDirection>(
                        valueListenable: controller.textDir,
                        child: const SizedBox(),
                        builder: (context, valueTextDirection, child) =>GetX<SearchControllers>(init: controller,builder: (set)=> TextFormField(
                          focusNode: controller.focusNode,
                          controller:  controller.searchController,
                          style: const TextStyle(textBaseline: TextBaseline.alphabetic),
                          cursorColor: AppColors.basicColor,
                          decoration:  InputDecoration(
                            prefixIcon: Icon(CupertinoIcons.search,color: AppColors.grayColor,size: 18),
                            suffixIcon: controller.isClear.value?InkWell(
                                onTap: (){
                                  controller.isClear.value=false;
                                  controller.searchController.clear();
                                  controller.optionWidgetSearch.clear();
                                  controller.pageSearchBool.value=false;
                                  controller.update();
                                }, child: const Icon(Icons.clear,color: AppColors.secondaryColor)):null,
                            contentPadding:  const EdgeInsets.only(top: 0,left: 15,right: 15),
                            hintText:TranslationKeys.search.tr,
                            focusedBorder:OutlineInputBorder(borderRadius: BorderRadius.circular(25),borderSide: const BorderSide(width: 0.3,color:AppColors.grayColor)),
                            enabledBorder:  OutlineInputBorder(borderRadius: BorderRadius.circular(25),borderSide: const BorderSide(width: 0.2,color: AppColors.grayColor)),
                            border: OutlineInputBorder(borderRadius: BorderRadius.circular(25),borderSide: const BorderSide(width: 0.2,color: AppColors.grayColor)),
                            hintMaxLines: 1,
                            fillColor: const Color(0xFFF2F2F2),
                            filled: true,
                            hintStyle: const TextStyle(fontSize: 14),
                          ),
                          readOnly: controller.pageStateSearch.value==0 || !controller.isGetTypes.value ,
                          onFieldSubmitted: (value) {
                            if(value.isNotEmpty )
                            {
                              controller.pageSearchBool.value=true;
                              controller.isClear.value=true;
                              controller.filterProduct();
                              controller.showSearch.value=false;

                            }
                            else
                            {
                              controller.isClear.value=false;
                              controller.optionWidgetSearch.clear();
                              controller.pageSearchBool.value=false;
                              controller.showSearch.value=true;
                            }

                          },
                          onChanged: (value) {
                            final dir = ALMethode.getDirection(value.trim());
                            if (dir != valueTextDirection)
                            {
                              controller.textDir.value = dir;
                            }
                            if(value.isNotEmpty)
                            {
                              controller.isClear.value=true;
                              controller.pageSearchBool.value=true;
                            }
                            else
                            {
                              controller.isClear.value=false;
                              controller.pageSearchBool.value=false;
                              controller.optionWidgetSearch.clear();
                            }
                            controller.update();
                          },

                        )),
                      ),
                      ),
                    )),
              ],


            ),
            body: Obx(() {
              switch (controller.pageState.value) {
                case 1:
                  {
                    return previewPage();
                  }
                case 2:
                  {
                    return errorPage();
                  }
                default:
                  return Container(width: Get.width, height: Get.height, color: Theme
                      .of(Get.context!)
                      .colorScheme
                      .background,);
              }
            }))));
  }




  Widget loadingPage () {
    return Center(child: ALConstantsWidget.loading(height: Get.width/12,width:Get.width/12),);
  }

  Widget previewPage () {
    return Padding(
      padding:  EdgeInsets.only(right: Get.width*0.04,left: Get.width*0.04,),
      child: Column(
        children: [
          SingleChildScrollView(
            physics: NeverScrollableScrollPhysics(),

            child: Column(
              children: [


                if(!controller.isGetTypes.value)
                  Container(
                    height: Get.height*0.85,
                    child: AnimationLimiter(

                      child: GridView.builder(
                          physics:const BouncingScrollPhysics(parent:  AlwaysScrollableScrollPhysics()),
                          padding: EdgeInsets.only(bottom: Get.height*0.01),
                          shrinkWrap: true,
                          primary: false,
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: 2,
                            childAspectRatio: 0.7,
                          ),
                          itemCount: 10,
                          itemBuilder: (BuildContext context, int index) {

                            return AnimationConfiguration.staggeredGrid(
                                position: index,
                                duration: const Duration(milliseconds: 500),
                                columnCount: 2,
                                child: ScaleAnimation(
                                    duration: const Duration(milliseconds: 900),
                                    curve: Curves.fastLinearToSlowEaseIn,
                                    child: FadeInAnimation(
                                      child:  Padding(
                                          padding: EdgeInsets.only(bottom: Get.width*0.05),
                                          child:  Container(
                                            width: Get.width*0.25,
                                            height: Get.height*0.75,
                                            child: Skeletonizer(
                                                enabled: true,
                                                child:Skeleton.unite(
                                                    borderRadius: BorderRadius.circular(15),
                                                    child : const Card(
                                                      color:Color(0xFFE8E8E8) ,
                                                      child: ListTile(
                                                        focusColor:Color(0xFFE8E8E8) ,
                                                      ),
                                                    )
                                                )),
                                          )
                                      ),)));
                          }),),
                  ),



                if(!controller.isGetTypes.value)
                  SizedBox(height: Get.height*0.01,),




              ],
            ),
          ),

          if(controller.isGetTypes.value)
            if(controller.isGetSub.value )
              SizedBox(height: Get.height*0.01,)
            else
              SizedBox(height: Get.height*0.000,),
          if(controller.isGetTypes.value)
            Expanded(child:  Container(child:
            controller.pageStateProduct.value==1 && ( ( controller.optionWidgetSearch.isEmpty && controller.searchController.text.trim().isNotEmpty))? ALConstantsWidget.NotFoundData(TranslationKeys.notFoundData.tr):
            controller.pageStateProduct.value==0  ? loadingPage():
            Stack(
              children: [
                GetX<SearchControllers>(init:controller,builder: (set)=>Container(
                  child: SmartRefresher(
                    primary: true,
                    enablePullDown:true,
                    enablePullUp: true ,
                    header: WaterDropHeader(waterDropColor: AppColors.secondaryColor,refresh: ALConstantsWidget.loading(width:Get.width*0.1,height: Get.width*0.1,color: AppColors.basicColor), complete:ALConstantsWidget.smartRefresh() ),
                    footer: CustomFooter(
                      builder: (BuildContext context,LoadStatus? mode){
                        Widget body ;
                        if(mode==LoadStatus.idle){
                          body =   Text(TranslationKeys.moreProduct.tr);
                        }
                        else if(mode==LoadStatus.loading){
                          body = Platform.isAndroid? const CircularProgressIndicator(color: Colors.white,strokeWidth: 1,backgroundColor: AppColors.secondaryColor,) :  CupertinoActivityIndicator(color: Theme.of(Get.context!).primaryColorDark);
                        }
                        else if(mode == LoadStatus.failed){
                          body = const Text('');
                        }
                        else if(mode == LoadStatus.canLoading){
                          body =  Text(TranslationKeys.moreProduct.tr);
                        }
                        else{
                          body =  Text(TranslationKeys.noMore.tr);
                        }
                        return DefaultTextStyle(
                          style: const TextStyle(fontSize: 14, color:Colors.white),
                          child: Padding(padding:  EdgeInsets.only(left:  Get.width*0.27,right:  Get.width*0.27,) ,child:SizedBox(
                            height: mode==LoadStatus.loading ? 55 :Get.height*0.04,
                            child: Stack(
                              alignment: Alignment.topCenter,
                              children: [
                                Container(
                                  height: mode==LoadStatus.loading ? 55 :Get.height*0.045,
                                  decoration: BoxDecoration(
                                      color: mode==LoadStatus.loading ? Colors.transparent :AppColors.secondaryColor,
                                      borderRadius: BorderRadius.circular(18)),
                                  child: Center(child:body),
                                ),
                              ],
                            ),
                          )),
                        );
                      },
                    ),
                    controller: controller.refreshController,
                    onRefresh: controller.getListOfRefresh,
                    onLoading: controller.getListOfLoading,
                    child: AnimationLimiter(
                      child: GridView.builder(
                          physics: const NeverScrollableScrollPhysics(),
                          padding: EdgeInsets.only(bottom: Get.height*0.01),
                          shrinkWrap: true,
                          primary: true,
                          gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                              crossAxisCount: 2,
                              childAspectRatio: 0.45,
                              crossAxisSpacing: 5,
                              mainAxisSpacing: 5
                          ),
                          itemCount: controller.optionWidgetSearch.isNotEmpty  ? controller.optionWidgetSearch.length:  !controller.pageSearchBool.value && (controller.searchController.text.isNotEmpty ||controller.optionWidgetSearch.isNotEmpty)? controller.optionWidgetSearch.length : controller.optionWidget.length,
                          itemBuilder: (BuildContext context, int index) {
                            dynamic item = controller.optionWidgetSearch.isNotEmpty ? controller.optionWidgetSearch[index]: !controller.pageSearchBool.value && (controller.searchController.text.isNotEmpty ||controller.optionWidgetSearch.isNotEmpty)?controller.optionWidgetSearch[index]: controller.optionWidget[index];

                            return AnimationConfiguration.staggeredGrid(
                                position: index,
                                duration: const Duration(milliseconds: 500),
                                columnCount: 2,
                                child: ScaleAnimation(
                                    duration: const Duration(milliseconds: 900),
                                    curve: Curves.fastLinearToSlowEaseIn,
                                    child: FadeInAnimation(
                                      child:  Padding(
                                          padding: EdgeInsets.only(bottom: Get.width*0.05),
                                          child: InkWell(
                                              onTap: (){
                                                FlutterStatusbarcolor.setNavigationBarColor(AppColors.whiteColor);
                                                FlutterStatusbarcolor.setStatusBarColor(AppColors.whiteColor);
                                                Get.toNamed(Routes.ItemsDetails,arguments:item )!.then((value) async {
                                                  await FlutterStatusbarcolor.setNavigationBarColor(AppColors.whiteColor);
                                                  FlutterStatusbarcolor.setStatusBarColor(AppColors.whiteColor);
                                                });
                                              },
                                              borderRadius: BorderRadius.circular(12),
                                              child: SLItem(
                                                  controller: controller,
                                                  item: item,
                                                  onLike: (Items item){
                                                    item.isFav!.value=item.isFav!.value==0?1:0;
                                                    controller.add_item_or_cancel_favourite(item);
                                                  }
                                              ))
                                      ),)));
                          }),),
                  ),
                )),

              ],
            )),),
        ],
      ),
    ) ;
  }

  Widget errorPage () {
    return ALConstantsWidget.errorServer(callBack: (){
      controller.onInit();
    });
  }

}