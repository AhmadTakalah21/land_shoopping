



import 'dart:convert';

import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh_flutter3/pull_to_refresh_flutter3.dart';
import 'package:shopping_land/packages/rounded_loading_button-2.1.0/rounded_loading_button.dart';
import 'package:shopping_land/Model/Model/ItemStore.dart';
import 'package:shopping_land/Model/Model/OptionWidget.dart';
import 'package:shopping_land/Pages/BuildScreens/Home/Home/Repositories/HomeRepositories.dart';
import 'package:shopping_land/Pages/BuildScreens/Search/Repositories/SearchRepositories.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';
import 'package:shopping_land/main.dart';

class SearchControllers extends GetxController {


  bool offer=false;
  RxInt pageStateProduct=0.obs;
  RxInt pageState=1.obs;
  Rx<ItemStore> itemStore =ItemStore().obs;
  TextEditingController controller =TextEditingController(text:'1');
  RoundedLoadingButtonController btnController =  RoundedLoadingButtonController();
  int page =2;
  bool empty =false;
  RxString title=''.obs;
  RxInt pageStateSearch=1.obs;
  RxInt pageSearch=1.obs;
  RxBool isGetTypes=false.obs;
  RxBool isGetItems=false.obs;
  RxBool isGetSub=false.obs;
  TextEditingController searchController=TextEditingController();
  RxBool isClear= false.obs;
  RxBool isSearch = false.obs;
  FocusNode focusNode = FocusNode();
  RxBool showSearch = false.obs;
  RxBool pageSearchBool=false.obs;
  RxString masterId=''.obs;
  RxString subId=''.obs;

  RxList<Items> optionWidget =<Items>[].obs;
  RxList<Items> optionWidgetSearch =<Items>[].obs;
  late ValueNotifier<TextDirection> textDir ;
  late RefreshController refreshController ;
  SearchControllers(){
    textDir = ValueNotifier(alSettings.currentUser!=null && alSettings.currentUser!.locale!='ar' ?TextDirection.ltr : TextDirection.rtl);
    refreshController= RefreshController(initialRefresh: false);
  }


  // Future<void> showItemStoreOffers() async{
  //   pageStateProduct.value=0;
  //   pageState.value=1;
  //   SearchRepositories repositories  =SearchRepositories();
  //   if(await repositories.show_offer(bodyData: {'offerId':items.offerId.toString(),'agentId':alSettings.citiesId.toString()}))
  //   {
  //     var data = json.decode(repositories.message.data);
  //     itemStore.value =dataItemStoreFromJson([data].toString()).first;
  //     pageStateProduct.value=1;
  //   }
  //   else
  //   {
  //     pageState.value=2;
  //   }
  // }


  Future<void> get_search_all() async{
    isGetTypes.value=false;
    isGetItems.value=false;

    SearchRepositories repositories  =SearchRepositories();
    if(await repositories.get_search_all(bodyData: {'search':''}))
    {
      if(repositories.message.data!=null)
      {
        var data = json.decode(json.decode(repositories.message.data));
        optionWidget.value =dataItemsWidgetFromJson(json.encode(data['items']).toString());


        isGetTypes.value=true;
        pageStateProduct.value=1;
      }
    }
    else
    {
      pageState.value=2;
    }
  }





  Future<void> getListOfRefresh()async{
    try{
      page=2;
      SearchRepositories repositories  =SearchRepositories();
      Map<String,String> body = {'perPage':'10','page':'1','city_id':alSettings.citiesId.value,};

      if(searchController.text.trim().isNotEmpty)
      {
        body.addAll({'search':searchController.text.trim().toString()});
      }
      else
        {
          body.addAll({'search':''});
        }
      RxList<Items> dataList =<Items>[].obs;
      if(await repositories.get_search_all(bodyData: body))
      {
        if(repositories.message.data!=null)
        {
          var data = json.decode(json.decode(repositories.message.data));
          dataList.value =dataItemsWidgetFromJson(json.encode(data['items']).toString());
        }
        if(searchController.text.trim().isNotEmpty)
        {
          optionWidgetSearch=dataList;
        }
        else
        {
          optionWidget=dataList;
        }
        refreshController.refreshCompleted();
      }
      else
      {
        refreshController.refreshFailed();
      }
    }
    catch(e) {
      refreshController.refreshFailed();
    }

  }

  Future<void> getListOfLoading()async{
    update();
    if(empty)
    {
      title.value=TranslationKeys.noMore.tr;
    }
    else
    {
      try{

        SearchRepositories repositories  =SearchRepositories();
        Map<String,String> body = {'perPage':'10','page':page.toString(),
          'city_id':alSettings.citiesId.value,
          'master_id':masterId.value,};
        if(searchController.text.trim().isNotEmpty)
        {
          body.addAll({'search':searchController.text.trim().toString()});
        }
        else
        {
          body.addAll({'search':''});
        }
        RxList<Items> dataList =<Items>[].obs;
        if(await repositories.get_search_all(bodyData: body))
        {
          if(repositories.message.data!=null)
          {
            page++;
            if(repositories.message.data!=null)
            {
              var data =  repositories.message.data==null?null :json.decode(json.decode(repositories.message.data));
              dataList.value =data!=null ?dataItemsWidgetFromJson(json.encode(data['items']).toString()):[];
            }
            if(searchController.text.trim().isNotEmpty)
            {
              optionWidgetSearch.addAll(dataList);
            }
            else
            {
              optionWidget.addAll(dataList);
            }
            update();

          }
          else
          {
            empty=true;
            title.value=TranslationKeys.noMore.tr;
          }
          refreshController.loadComplete();

        }
        else
        {
          refreshController.loadComplete();
        }

      }
      catch(e) {
        refreshController.loadFailed();
        update();
      }
    }
  }

  Future<void> add_item_or_cancel_favourite(Items item) async{
    HomeRepositories repositories  =HomeRepositories();
    await repositories.add_item_or_cancel_favourite(bodyData: {'item_id':item.id.toString()});
  }

  Future<void> filterProduct()async {
    SearchRepositories repositories  =SearchRepositories();
    pageStateSearch.value=0;
    pageStateProduct.value=0;
    page=2;
    Map<String,String> body = {
      'perPage':'10',
      'page':'1',
      'city_id':alSettings.citiesId.value,
      'master_id':masterId.value,
    };
    if(searchController.text.trim().isNotEmpty)
    {
      body.addAll({'search':searchController.text.trim(),});
    }
    else
    {
      body.addAll({'search':''});
    }

    if(await repositories.get_search_all(bodyData:body))
    {
      RxList<Items> dataList =<Items>[].obs;

      if(repositories.message.data!=null)
      {
        var data =  repositories.message.data==null?null :json.decode(json.decode(repositories.message.data));
        dataList.value =data!=null ?dataItemsWidgetFromJson(json.encode(data['items']).toString()):[];
      }
      if(searchController.text.trim().isNotEmpty)
      {
        optionWidgetSearch=dataList;
      }
      else
      {
        optionWidget=dataList;
      }
      update();
      pageStateSearch.value=1;
      pageStateProduct.value=1;


      pageSearchBool.value=false;
    }
    else
    {
      pageState.value=2;
    }

  }


  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();
    // showItemStoreOffers();
    get_search_all();
  }

}