import 'dart:io';

import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_custom_carousel_slider/flutter_custom_carousel_slider.dart';
import 'package:shopping_land/Model/Model/Post.dart';
import 'package:shopping_land/Services/helper/status_bar.dart';
import 'package:get/get.dart';
import 'package:photo_view/photo_view.dart';
import 'package:photo_view/photo_view_gallery.dart';
import 'package:shopping_land/ALConstants/ALConstantsWidget.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';

class PostDetails extends StatelessWidget {
  PostModel post;

  PostDetails({required this.post, Key? key}) : super(key: key);

  a() {
    if (true && false) {
      print('');
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: SystemUiOverlayStyle(
            statusBarIconBrightness: Brightness.light,
            statusBarBrightness: Brightness.light,
            systemNavigationBarIconBrightness: Brightness.light,
            systemNavigationBarColor: Colors.white,
            systemNavigationBarDividerColor: Colors.transparent),
        child: Material(child: Scaffold(body: previewPage())));
  }
  Widget previewPage() {
    return ListView(
      children: [
        Stack(
          children: [
            CustomCarouselSlider(
              items: post.files!.isEmpty
                  ? []
                  : post.files!
                      .map((e) => CarouselItem(
                            image: ExtendedImage.network(
                                e.url.toString().replaceAll('\\', ''),
                                fit: BoxFit.cover,
                                cache: true,
                                handleLoadingProgress: true,
                                timeRetry: const Duration(seconds: 1),
                                printError: true,
                                timeLimit: const Duration(seconds: 1),
                                borderRadius: BorderRadius.circular(0),
                                loadStateChanged: (ExtendedImageState state) {
                              switch (state.extendedImageLoadState) {
                                case LoadState.failed:
                                  return GestureDetector(
                                    key: UniqueKey(),
                                    onTap: () {
                                      state.reLoadImage();
                                    },
                                    child: Container(
                                      width: Get.width,
                                      height: Get.height * 0.20,
                                      decoration: BoxDecoration(
                                        color: Colors.grey.shade50,
                                        borderRadius: BorderRadius.circular(0),
                                      ),
                                      child: const Icon(
                                        CupertinoIcons.refresh_circled_solid,
                                        size: 40,
                                        color: AppColors.basicColor,
                                        semanticLabel: 'failed',
                                      ),
                                    ),
                                  );
                                case LoadState.loading:
                                  return Stack(
                                    alignment: Alignment.center,
                                    children: [
                                      Container(
                                        width: Get.width,
                                        height: Get.height * 0.20,
                                        decoration: BoxDecoration(
                                          color: Colors.grey.shade50,
                                          borderRadius:
                                              BorderRadius.circular(0),
                                        ),
                                      ),
                                      Container(
                                        child: Platform.isAndroid
                                            ? const CircularProgressIndicator(
                                                color: AppColors.grayColor,
                                                strokeWidth: 1,
                                                backgroundColor:
                                                    AppColors.whiteColor,
                                              )
                                            : CupertinoActivityIndicator(
                                                radius: 15),
                                      )
                                    ],
                                  );
                                case LoadState.completed:
                                  break;
                              }
                              return null;
                            }
                                //cancelToken: cancellationToken,
                                ).image,
                            onImageTap: (v) async {
                              await FlutterStatusbarcolor.setNavigationBarColor(
                                  Colors.black);
                              await FlutterStatusbarcolor.setStatusBarColor(
                                  Colors.black);
                              Get.to(Scaffold(
                                backgroundColor: Colors.black,
                                appBar: AppBar(
                                    backgroundColor: Colors.black,
                                    elevation: 0),
                                body: PhotoViewGallery.builder(
                                  scrollPhysics: const BouncingScrollPhysics(),
                                  itemCount: post.files!.length,
                                  builder: (BuildContext context, int index) {
                                    return PhotoViewGalleryPageOptions(
                                      imageProvider: NetworkImage(
                                          post.files![index].url.toString()),
                                      initialScale:
                                          PhotoViewComputedScale.contained * 1,
                                      heroAttributes: PhotoViewHeroAttributes(
                                          tag:
                                              post.files![index].id.toString()),
                                    );
                                  },
                                  pageController:
                                      PageController(initialPage: v),
                                  backgroundDecoration:
                                      BoxDecoration(color: Colors.black),
                                ),
                              ))!
                                  .then((value) {
                                FlutterStatusbarcolor.setNavigationBarColor(
                                    AppColors.basicColor);
                                FlutterStatusbarcolor.setStatusBarColor(
                                    AppColors.basicColor);
                              });
                            },
                            boxDecoration: BoxDecoration(
                              gradient: LinearGradient(
                                begin: FractionalOffset.bottomCenter,
                                end: FractionalOffset.topCenter,
                                colors: [
                                  Colors.blueAccent.withOpacity(1),
                                  Colors.black.withOpacity(.3),
                                ],
                                stops: const [0.0, 1.0],
                              ),
                            ),
                          ))
                      .toList(),
              height: Get.height * 0.5,
              // borderRadius: 0,
              dotSpacing: 1,
              width: Get.width,
              autoplay: true,

              showSubBackground: false,
              showText: false,
              selectedDotWidth: 6,
              unselectedDotWidth: 4.5,
              selectedDotHeight: 6,
              unselectedDotHeight: 4.5,
              unselectedDotColor: AppColors.grayColor,
              selectedDotColor: AppColors.basicColor,
            ),
            Padding(
              padding: EdgeInsets.only(
                  left: Get.width * 0.02, right: Get.width * 0.02),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Padding(
                    padding: EdgeInsets.only(
                        right: Get.height * 0.015,
                        left: Get.height * 0.015,
                        top: Get.height * 0.01),
                    child: IconButton(
                      icon:
                          const Icon(Icons.arrow_back_ios, color: Colors.black),
                      onPressed: () {
                        Get.back();
                      },
                    ),
                  ),
                ],
              ),
            )
          ],
        ),
        Container(
          padding: EdgeInsets.only(
              left: Get.width * 0.02,
              right: Get.width * 0.02,
              bottom: Get.width * 0.02,
              top: Get.width * 0.02),
          decoration: BoxDecoration(
              // color: Color(0xffF5F5F5),
              borderRadius: BorderRadius.only(
                  bottomLeft: Radius.circular(15),
                  bottomRight: Radius.circular(15))),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Container(
                width: Get.width * 0.5,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    Text(post.title.toString(),
                        textAlign: TextAlign.center,
                        maxLines: 2,
                        style: TextStyle(
                            fontSize: 20,
                            fontWeight: FontWeight.w700,
                            color: Colors.black)),
                    SizedBox(
                      height: 5,
                    ),
                    Text(
                      post.description.toString(),
                      textAlign: TextAlign.center,
                      maxLines: 2,
                      style: TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w300,
                          color: Colors.black),
                    ),
                  ],
                ),
              ),
              SizedBox(
                height: 3,
              ),
            ],
          ),
        ),
      ],
    );
  }
}
