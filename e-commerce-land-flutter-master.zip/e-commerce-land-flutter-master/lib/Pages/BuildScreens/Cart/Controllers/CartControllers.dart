import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:flutter/cupertino.dart';
import 'package:flutter/services.dart';
import 'package:flutter_svprogresshud/flutter_svprogresshud.dart';
import 'package:get/get.dart';
import 'package:pull_to_refresh_flutter3/pull_to_refresh_flutter3.dart';
import 'package:shopping_land/packages/rounded_loading_button-2.1.0/rounded_loading_button.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/Model/Model/Address.dart';
import 'package:shopping_land/Model/Model/CartModel.dart';
import 'package:shopping_land/Model/Model/Cities.dart';
import 'package:shopping_land/Model/Model/DeliveryTypes.dart';
import 'package:shopping_land/Model/Model/Discount.dart';
import 'package:shopping_land/Model/Model/MethodTypes.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Repositories/CartRepositories.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/Profile/Repositories/ProfileRepositories.dart';
import 'package:shopping_land/Pages/MainScreenView/Controllers/MainScreenViewControllers.dart';
import 'package:shopping_land/Pages/SignUp/Repositories/SingUpRepositories.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';

class CartControllers extends GetxController {
  RxInt pageState2 = 0.obs;

  RxInt pageState = 1.obs;
  RxInt pageStateCart = 0.obs;
  RxString citiesName = ''.obs;
  RxString citiesId = ''.obs;
  RxString countriesName = ''.obs;
  RxString countriesId = ''.obs;
  GlobalKey<FormState> form = GlobalKey<FormState>();
  TextEditingController quantity = TextEditingController(text: '1');
  RxList<Cities> cities = <Cities>[].obs;
  RxList<Cities> countries = <Cities>[].obs;
  RoundedLoadingButtonController btnController =
      RoundedLoadingButtonController();
  RoundedLoadingButtonController btnController2 =
      RoundedLoadingButtonController();
  RoundedLoadingButtonController btnController3 =
      RoundedLoadingButtonController();
  TextEditingController code = TextEditingController(text: '');

  TextEditingController name = TextEditingController(text: '');
  TextEditingController middleName = TextEditingController(text: '');
  TextEditingController name2 = TextEditingController(text: '');
  TextEditingController phone = TextEditingController(text: '');
  TextEditingController address = TextEditingController(text: '');
  List<Address> addressList = [];

  RxString addressListName = ''.obs;
  RxString addressListID = ''.obs;

  CartRepositories repositories = CartRepositories();

  RxString methodTypesName = ''.obs;
  RxString methodTypesId = ''.obs;

  RxString deliveryTypesName = ''.obs;
  RxString deliveryTypesId = ''.obs;

  RxString discountName = ''.obs;
  RxString discountId = ''.obs;
  late RefreshController refreshController;
  RxBool isCheckDiscount = false.obs;
  RxBool isCheckDiscountEnd = false.obs;

  RxList<CartModel> carts = <CartModel>[].obs;
  RxList<MethodTypes> methodTypes = <MethodTypes>[].obs;
  RxList<DeliveryTypes> deliveryTypes = <DeliveryTypes>[].obs;
  RxList<Discount> discount = <Discount>[].obs;
  String? findCartIdByItemId(int itemId) {
    for (var cartModel in carts) {
      if (cartModel.carts != null) {
        for (var cart in cartModel.carts!) {
          if (cart.item?.id == itemId) {
            return cart.id?.toString();
          }
        }
      }
    }
    return null;
  }

  CartControllers() {
    refreshController = RefreshController(initialRefresh: false);
  }

  Future<void> delete({required String itemId}) async {
    try {
      if (Platform.isIOS) {
        SVProgressHUD.setDefaultAnimationType(
            SVProgressHUDAnimationType.native);
      }
      SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.light);

      SVProgressHUD.show();

      CartRepositories repositories = CartRepositories();
      if (await repositories.delete(body: {
        'item_id': itemId,
        'cart_id': findCartIdByItemId(int.parse(itemId))
      })) {
        print(carts.last.carts!.last.id.toString());
        MainScreenViewControllers mainScreenViewControllers = Get.find();
        await mainScreenViewControllers.count_item_in_cart();
        SVProgressHUD.dismiss();
        onInit();
      } else {
        SVProgressHUD.dismiss();
      }
    } catch (e) {
      print(e);
      SVProgressHUD.dismiss();
    }
  }

  Future<void> display_carts() async {
    try {
      pageState.value = 1;
      pageStateCart.value = 0;
      carts.clear();
      addressList.clear();

      ProfileRepositories repositoriesProfile = ProfileRepositories();
      if (await repositoriesProfile.display_address()) {
        var data = json.decode(json.decode(repositoriesProfile.message.data));
        addressList = dataAddressFromJson(json.encode(data).toString());
        await display_all_countries();
        if (addressList.isNotEmpty) {
          addressListName.value = addressList.first.address.toString();
          addressListID.value = addressList.first.id.toString();
        } else {
          addressList.add(Address(
              address: 'لا يوجد عناوين يرجى اضافة عنوان في الملف الشخصي'));
        }
      }
      if (await repositories.display_carts()) {
        if (repositories.message.data != null) {
          var data = json.decode(json.decode(repositories.message.data));
          carts.value = dataCartModelFromJson(json.encode([data]));
          if (carts.isNotEmpty) {
            if (await repositories.display_payment_method()) {
              if (repositories.message.data != null) {
                var data = json.decode(json.decode(repositories.message.data));
                methodTypes.value = dataMethodTypesFromJson(
                    json.encode(data['paymentMethods']['data']));
                methodTypesName.value = TranslationKeys.select.tr;
              }
              if (await repositories.display_delivery_types()) {
                if (repositories.message.data != null) {
                  var data =
                      json.decode(json.decode(repositories.message.data));
                  deliveryTypes.value = dataDeliveryTypesFromJson(
                      json.encode(data['deliveryTypes']['data']));
                  deliveryTypesName.value = TranslationKeys.select.tr;
                }
                pageStateCart.value = 1;
                refreshController.refreshCompleted();
              } else {
                pageState.value = 2;
                 refreshController.refreshFailed();
              }
            } else {
              pageState.value = 2;
               refreshController.refreshFailed();
            }
          }
        }
        pageStateCart.value = 1;
         refreshController.refreshCompleted();
      } else {
        pageState.value = 2;
         refreshController.refreshFailed();
      }
    } catch (e) {
      print(e);
      pageState.value = 2;
       refreshController.refreshFailed();
    }
  }

  Future<void> check_coupon() async {
    try {
      SystemChannels.textInput.invokeMethod('TextInput.hide');
      discount.clear();
      if (Platform.isIOS) {
        SVProgressHUD.setDefaultAnimationType(
            SVProgressHUDAnimationType.native);
      }
      SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.light);

      SVProgressHUD.show(status: 'تحقق');
      Map<String, String> body = {
        'code': code.text.trim().toString(),
      };
      if (await repositories.check_coupon(body: body)) {
        SVProgressHUD.showSuccess(status: 'تم');
        var data = json.decode(json.decode(repositories.message.data));
        double percentageValue =
            (data['percent'] / 100) * carts.first.totalPriceAfterDiscount;
        // Subtract the percentage value from the original number
        double result = carts.first.totalPriceAfterDiscount! - percentageValue;
        discount
            .add(Discount(amount: data['percent'], percent: result.toInt()));
        SVProgressHUD.dismiss();
      } else {
        SVProgressHUD.showError(
            status: 'لم يتم العثور على نسبة حسم مرتبطة بالكود');
        await Future.delayed(Duration(seconds: 2));
        SVProgressHUD.dismiss();
      }
    } catch (e) {
      SVProgressHUD.dismiss();
      print(e);
    }
  }

  Future<void> addOrder() async {
    try {
      Map<String, String> body = {
        'last_name': name2.text.trim(),
        'delivery_type_id': deliveryTypesId.value.trim(),
        'payment_method_id': methodTypesId.value.trim(),
        'address_id': addressListID.value.trim(),
        'first_name': name.text.trim(),
        'middle_name': middleName.text.trim(),
        'phone': phone.text.trim(),
        'city_id': citiesId.value
      };
      if (discount.isNotEmpty) {
        body.addAll({'coupon': code.text.trim()});
      }
      if (await repositories.add_order(body: body)) {
        MainScreenViewControllers mainScreenViewControllers = Get.find();
        await mainScreenViewControllers.count_item_in_cart();
        btnController.success();
        Timer(
          const Duration(seconds: 1),
          () {
            Get.back();
            onInit();
          },
        );
      } else {
        btnController.error();
        ALMethode.showToast(
            title: TranslationKeys.somethingWentWrong.tr,
            message: repositories.message.description ??
                TranslationKeys.errorEmail.tr,
            type: ToastType.error,
            context: Get.context!);
        Timer(
          const Duration(seconds: 1),
          () {
            btnController.reset();
          },
        );
      }
    } catch (e) {
      SVProgressHUD.dismiss();
      print(e);
    }
  }

  Future<void> edit_cart({required String cartId}) async {
    try {
      if (Platform.isIOS) {
        SVProgressHUD.setDefaultAnimationType(
            SVProgressHUDAnimationType.native);
      }
      SVProgressHUD.setDefaultStyle(SVProgressHUDStyle.light);

      SVProgressHUD.show();

      CartRepositories repositories = CartRepositories();
      if (await repositories.update_cart(
          body: {'cart_id': cartId, 'quantity': quantity.text.toString()})) {
        quantity.clear();
        MainScreenViewControllers mainScreenViewControllers = Get.find();
        await mainScreenViewControllers.count_item_in_cart();
        update();
        SVProgressHUD.dismiss();
        onInit();
      } else {
        SVProgressHUD.dismiss();
      }
    } catch (e) {
      print(e);
      SVProgressHUD.dismiss();
    }
  }

  Future<void> display_all_cities() async {
    pageState2.value = 0;
    SingUpRepositories repositories = SingUpRepositories();
    if (await repositories.display_all_cities(countryId: countriesId.value)) {
      if (repositories.message.data != null) {
        var data = json.decode(json.decode(repositories.message.data));
        cities.value = dataCitiesFromJson(json.encode(data['cities']));
        citiesName.value = cities.first.name.toString();
        citiesId.value = cities.first.id.toString();
      }
      pageState2.value = 1;
    } else {
      pageState.value = 2;
    }
  }

  Future<void> display_all_countries() async {
    SingUpRepositories repositories = SingUpRepositories();
    if (await repositories.display_all_countries()) {
      if (repositories.message.data != null) {
        var data = json.decode(json.decode(repositories.message.data));
        countries.value = dataCitiesFromJson(json.encode(data['countries']));
        countriesName.value = countries.first.name.toString();
        countriesId.value = countries.first.id.toString();
        display_all_cities();
      }
    }
  }

  @override
  void onInit() {
    super.onInit();
    display_carts();
  }
}
