




import 'package:get/get.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Controllers/CartControllers.dart';

class CartBindingsBindings extends Bindings {
  @override
  void dependencies() {
    Get.put(CartControllers());
  }
}



