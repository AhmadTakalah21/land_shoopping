import 'package:get/get.dart';
import 'package:shopping_land/Pages/SignIn/Controllers/SingInControllers.dart';

class SingInBinding extends Bindings {
  @override
  void dependencies() {
    Get.put(SingInControllers());
  }
}



