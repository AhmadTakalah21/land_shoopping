
import 'dart:async';
import 'dart:convert';

import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:get/get.dart';
import 'package:shopping_land/packages/rounded_loading_button-2.1.0/rounded_loading_button.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppPages.dart';
import 'package:shopping_land/Model/Model/CurrentUser.dart';
import 'package:shopping_land/Pages/SignIn/Repositories/SingInRepositories.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';
import 'package:shopping_land/main.dart';

class SingInControllers extends GetxController with GetSingleTickerProviderStateMixin
{

  late Rx<AnimationController> controller;
  late Rx<Animation<double>> animation;
  late Rx<Animation<double>> opacity;
  late Rx<Animation<double>> transform;
  late ScrollController scrollController;
  late  GlobalKey<ScaffoldState> scaffoldKey;
  late TextEditingController email ;
  late TextEditingController password ;
   RoundedLoadingButtonController btnController =  RoundedLoadingButtonController();
  RxBool validator= true.obs;
  RxBool validatorEmail= false.obs;
  RxBool isCatchError= false.obs;
  BuildContext? context;
  late GlobalKey<FormState> login ;
  AnimationController? animationController;
  RxInt stateLogin= 1.obs;
  RxBool keyboardVisibility=false.obs;
  RxBool visiblePassword = true.obs;
 late ValueNotifier<TextDirection> textDir ;
  SingInControllers() {
    textDir = ValueNotifier(alSettings.currentUser!=null && alSettings.currentUser!.locale!='ar' ?TextDirection.ltr : TextDirection.rtl);
    scrollController=ScrollController();
    scaffoldKey = GlobalKey<ScaffoldState>();
    controller = AnimationController(
      vsync: this,
      duration: const Duration(seconds: 3),
    ).obs;
    login = GlobalKey<FormState>();
    opacity = Tween<double>(begin: 0, end: 1).animate(CurvedAnimation(
        parent: controller.value,
        curve: Curves.ease,
      ),).obs;
    opacity.value.addListener(() {
      update();
    });
    transform = Tween<double>(begin: 2, end: 1).animate(CurvedAnimation(
        parent: controller.value,
        curve: Curves.fastLinearToSlowEaseIn,
      ),).obs;

    controller.value.forward();
    email=TextEditingController();
    password=TextEditingController();

  }

  void  updateController(){
    update();
  }

  void onPressedIconWithText() async {
    SingInRepositories repositories =SingInRepositories();
  try{
    var states = login.currentState;
    if (states!.validate()) {
      await SystemChannels.textInput.invokeMethod('TextInput.hide');
      await FirebaseMessaging.instance.getToken().then((token) async{

        if(await repositories.login(email: email.text.trim(),token:token.toString(), password: password.text.trim()))
        {
          var data = json.decode(json.decode(repositories.message.data));
          alSettings.currentUser=CurrentUser(locale: 'ar');
          alSettings.currentUser!.userId=data['id'].toString();
          alSettings.currentUser!.userName=data['user_name'];
          alSettings.currentUser!.apiKey=data['token'];
          alSettings.currentUser!.locale='ar';
          await ALMethode.setUserInfo(data: alSettings.currentUser!);

          btnController.success();
          Timer(const Duration(seconds: 1), () {
            Get.offAllNamed(Routes.MAIN_SCREEN);
          },
          );
        }
        else
        {
          btnController.error();
          ALMethode.showToast(
              title: TranslationKeys.somethingWentWrong.tr,
              message: 'تأكد من اسم المستخدم  أو كلمة المرور',
              type: ToastType.error, context: context!);
          Timer(
            const Duration(seconds: 1),
                () {
              btnController.reset();
            },
          );
        }
      });

    }
    else
    {
      btnController.reset();
      SystemChannels.textInput.invokeMethod('TextInput.hide');
    }
  }
  catch(e)
    {
      btnController.error();
      ALMethode.showToast(
          title: TranslationKeys.somethingWentWrong.tr,
          message:'تأكد من اسم المستخدم  أو كلمة المرور',
          type: ToastType.error, context: Get.context!);
      Timer(
        const Duration(seconds: 1),
            () {
          btnController.reset();
        },
      );
      Timer(
        const Duration(seconds: 1),
            () {
          btnController.reset();
        },
      );
    }
  }






  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();


  }

  @override
  void onClose() {
    // TODO: implement onClose
    super.onClose();
    controller.close();
    opacity.close();
    transform.close();
    scrollController.dispose();


  }


}