import 'package:animated_custom_dropdown/custom_dropdown.dart';
import 'package:bottom_bar_matu/bottom_bar/bottom_bar_bubble.dart';
import 'package:extended_image/extended_image.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
// import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:get/get.dart';
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/ALConstants/AppImages.dart';
import 'package:shopping_land/ALConstants/AppPages.dart';
import 'package:shopping_land/Pages/BuildScreens/Brands/Brands/Controllers/BrandsControllers.dart';
import 'package:shopping_land/Pages/BuildScreens/Brands/Brands/Views/Brands.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Controllers/CartControllers.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Views/Cart.dart';
import 'package:shopping_land/Pages/BuildScreens/Favorite/Controllers/FavoriteControllers.dart';
import 'package:shopping_land/Pages/BuildScreens/Favorite/Views/Favorite.dart';
import 'package:shopping_land/Pages/BuildScreens/Home/Home/Views/Home.dart';
import 'package:shopping_land/Pages/BuildScreens/Notifications/Views/Notifications.dart';
import 'package:shopping_land/Pages/BuildScreens/Profile/Profile/Views/Profile.dart';
import 'package:shopping_land/Pages/MainScreenView/Controllers/MainScreenViewControllers.dart';
import 'package:shopping_land/Services/Translations/TranslationKeys/TranslationKeys.dart';
import 'package:shopping_land/main.dart';
import 'package:uuid/uuid.dart';
import 'package:cool_nav/cool_nav.dart';

class MainScreenView extends StatefulWidget {
  bool? cart;
  MainScreenView({this.cart, super.key});

  @override
  State<MainScreenView> createState() => _MainScreenViewState();
}

class _MainScreenViewState extends State<MainScreenView>
    with WidgetsBindingObserver {
  MainScreenViewControllers controller = Get.put(MainScreenViewControllers());

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addObserver(this);
    if (widget.cart != null) {
      controller.currentpage.value = 3;
    }
  }

  @override
  void dispose() {
    super.dispose();
    WidgetsBinding.instance.removeObserver(this);
  }

  @override
  void didChangeAppLifecycleState(AppLifecycleState state) {
    super.didChangeAppLifecycleState(state);

    if (state == AppLifecycleState.resumed) {
      Future.delayed(Duration.zero, () async {
        alSettings.security.value = await ALMethode.security();

        if (alSettings.security.value) {
          alSettings.security.value = true;
          SystemNavigator.pop();
        }
      });
    }

    // Handle other states if needed
  }

  @override
  Widget build(BuildContext context) {
    final screenSize = MediaQuery.of(context).size;
    final screenWidth = screenSize.width;

    return GetX<MainScreenViewControllers>(
        init: controller,
        builder: (set) => AnnotatedRegion<SystemUiOverlayStyle>(
            value: const SystemUiOverlayStyle(
              statusBarIconBrightness: Brightness.light,
              statusBarBrightness: Brightness.light,
              statusBarColor: AppColors.basicColor,
              systemNavigationBarColor: AppColors.basicColor,
              systemNavigationBarIconBrightness: Brightness.light,
              systemNavigationBarDividerColor: Colors.transparent,
            ),
            child: Material(
                color: Theme.of(context).scaffoldBackgroundColor,
                child: DefaultTextStyle(
                    style: TextStyle(fontFamily: 'Almarai-Light'),
                    child: Container(
                        child: Scaffold(
                            backgroundColor: Colors.transparent,
                            appBar: controller.currentpage.value != 0
                                ? null
                                : AppBar(
                                    elevation: 0,
                                    centerTitle: true,
                                    leadingWidth: Get.width * 0.11,
                                    backgroundColor: Colors.transparent,
                                    title: Padding(
                                      padding: const EdgeInsets.only(
                                          top: 10.0, bottom: 10, right: 170),
                                      child: SizedBox(
                                        //     width: Get.width * 0.90,
                                        height: Get.height * 0.05,
                                        child: Container(
                                          //     width: Get.width * 0.81,
                                          height: Get.height * 0.060,
                                          child: Padding(
                                            padding: EdgeInsets.only(
                                                top: Get.height * 0.00),
                                            child:
                                                CustomDropdown<String>.search(
                                              maxlines: 5,
                                              decoration:
                                                  CustomDropdownDecoration(
                                                      noResultFoundStyle:
                                                          TextStyle(
                                                              color: AppColors
                                                                  .grayColor),
                                                      closedSuffixIcon: Icon(
                                                        Icons.arrow_drop_down,
                                                        size: 25,
                                                        color:
                                                            AppColors.grayColor,
                                                      ),
                                                      listItemStyle: TextStyle(
                                                          fontSize: 13),
                                                      headerStyle: TextStyle(
                                                          color: AppColors
                                                              .grayColor,
                                                          fontSize: 15),
                                                      closedFillColor:
                                                          const Color(
                                                              0xFFF2F2F2),
                                                      closedBorderRadius:
                                                          BorderRadius.circular(
                                                              10),
                                                      closedBorder: Border.all(
                                                          color: AppColors
                                                              .grayColor,
                                                          width: 0.5),
                                                      searchFieldDecoration:
                                                          SearchFieldDecoration(
                                                        suffixIcon: (onClear) {
                                                          return IconButton(
                                                              splashRadius: 20,
                                                              onPressed:
                                                                  onClear,
                                                              icon: const Icon(
                                                                Icons.close,
                                                                color: AppColors
                                                                    .basicColor,
                                                              ));
                                                        },
                                                        prefixIcon: const Icon(
                                                          Icons.search,
                                                          color: AppColors
                                                              .basicColor,
                                                        ),
                                                      )),
                                              noResultFoundText:
                                                  TranslationKeys.notFound.tr,
                                              closedHeaderPadding:
                                                  EdgeInsets.only(
                                                      top: Get.height * 0.011,
                                                      bottom:
                                                          Get.height * 0.011,
                                                      right: Get.width * 0.04,
                                                      left: Get.width * 0.04),
                                              items: controller.cities.value
                                                  .map((e) => e.name.toString())
                                                  .toList(),
                                              excludeSelected: false,
                                              hintText:
                                                  controller.citiesName.value,
                                              onChanged: (value) {
                                                // controller.citiesName.value =
                                                //     value!;
                                                setState(() {
                                                  alSettings.citiesId.value =
                                                      // value.toString();
                                                      // controller.cities
                                                      //     .value =
                                                      controller.cities.value
                                                          .where((element) =>
                                                              element.name ==
                                                              value)
                                                          .first
                                                          .id
                                                          .toString();
                                                });
                                                alSettings.update();
                                                // controller.display_all_cities();
                                              },
                                            ),
                                          ),
                                        ),
                                      ),
                                    ),
                                    leading: Row(
                                      children: [
                                        Container(
                                            height: 35,
                                            padding: EdgeInsets.only(
                                                right: Get.width * 0.02),
                                            alignment: Alignment.centerRight,
                                            child: ExtendedImage.asset(
                                              AppImages.logo2,
                                            )),
                                        SizedBox(
                                          width: 7,
                                        ),
                                        Text(
                                          "Shopping land",
                                          style: TextStyle(
                                              fontFamily: 'comicbd',
                                              fontSize: 19,
                                              color: AppColors.basicColor),
                                        ),
                                      ],
                                    ),
                                    actions: [
                                      Container(
                                        margin: EdgeInsets.only(left: 3),
                                        width: Get.width * 0.1,
                                        child: FloatingActionButton(
                                          heroTag: const Uuid().v4(),
                                          elevation: 0,
                                          backgroundColor: Colors.transparent,
                                          onPressed: () {
                                            Get.to(const Notifications());
                                          },
                                          child: ShaderMask(
                                              shaderCallback: (Rect bounds) {
                                                const gradient = LinearGradient(
                                                  colors: <Color>[
                                                    Color(0xff707070),
                                                    Color(0xff707070),
                                                  ],
                                                );
                                                return gradient
                                                    .createShader(bounds);
                                              },
                                              blendMode: BlendMode
                                                  .srcIn, // This is important to preserve icon's transparency
                                              child: Icon(
                                                CupertinoIcons.bell,
                                              )),
                                        ),
                                      ),
                                    ],
                                  ),
                            body: GetBuilder<MainScreenViewControllers>(
                                builder: (state) {
                              switch (controller.currentpage.value) {
                                case 0:
                                  {
                                    // try {
                                    //   HomeController controllers = Get.find();
                                    //   controllers.onInit();
                                    // }
                                    // catch(e){}
                                    return Home();
                                  }
                                case 1:
                                  {
                                    try {
                                      BrandsControllers controllers =
                                          Get.find();
                                      controllers.onInit();
                                    } catch (e) {}
                                    return const Brands();
                                  }
                                case 2:
                                  {
                                    try {
                                      FavoriteControllers controllers =
                                          Get.find();
                                      controllers.onInit();
                                    } catch (e) {}
                                    return const Favorite();
                                  }
                                case 3:
                                  {
                                    // try {
                                    //   CartControllers controllers = Get.find();
                                    //   controllers.onInit();
                                    // }
                                    // catch(e){}
                                    return const Cart();
                                  }
                                case 4:
                                  {
                                    return const Profile();
                                  }

                                default:
                                  {
                                    return const SizedBox();
                                  }
                              }
                            }),
                            bottomNavigationBar: Stack(
                              clipBehavior: Clip.none,
                              children: [
                                FlipBoxNavigationBar(
                                  textStyle: TextStyle(color: Colors.white),
                                  selectedItemTheme:
                                      IconThemeData(color: Color(0xFFF7C633)),
                                  currentIndex: controller.currentpage.value,
                                  verticalPadding: 30.0,
                                  items: <FlipBoxNavigationBarItem>[
                                    FlipBoxNavigationBarItem(
                                      name: 'الصفحة الرئيسية',
                                      selectedIcon: CupertinoIcons.home,
                                      selectedBackgroundColor: Colors.white,
                                      unselectedBackgroundColor:
                                          Color(0xFF45C1A6),
                                    ),
                                    FlipBoxNavigationBarItem(
                                      name: 'المنتجات',
                                      selectedIcon:
                                          CupertinoIcons.square_grid_2x2,
                                      selectedBackgroundColor: Colors.white,
                                      unselectedBackgroundColor:
                                          Color(0xFF45C1A6),
                                    ),
                                    FlipBoxNavigationBarItem(
                                      name: 'المفضلة',
                                      selectedIcon: Icons.favorite_border,
                                      selectedBackgroundColor: Colors.white,
                                      unselectedBackgroundColor:
                                          Color(0xFF45C1A6),
                                    ),
                                    FlipBoxNavigationBarItem(
                                      name: 'السلة',
                                      selectedIcon: CupertinoIcons.cart,
                                      selectedBackgroundColor: Colors.white,
                                      unselectedBackgroundColor:
                                          Color(0xFF45C1A6),
                                    ),
                                    FlipBoxNavigationBarItem(
                                      name: 'البروفايل',
                                      selectedIcon: CupertinoIcons.person,
                                      selectedBackgroundColor: Colors.white,
                                      unselectedBackgroundColor:
                                          Color(0xFF45C1A6),
                                    ),
                                  ],
                                  backgroundColor: Color(0xFF45C1A6),
                                  onTap: (value) {
                                    setState(() {
                                      controller.changePage(value);
                                    });
                                    try {
                                      controller.currentpage.value = value;
                                      controller.update();

                                      CartControllers controllers = Get.find();
                                      controllers.isCheckDiscount.value = false;
                                      controllers.discountId.value = '';
                                      controllers.isCheckDiscount.value = false;
                                      controllers.discount.clear();
                                    } catch (e) {
                                      print(e);
                                    }
                                  },
                                ),
                                if (controller.count.toString() != "0")
                                  Positioned(
                                    bottom: MediaQuery.of(context).size.height *
                                        0.06,
                                    left: MediaQuery.of(context).size.width *
                                        0.24,
                                    child: Container(
                                      padding: EdgeInsets.all(5),
                                      decoration: BoxDecoration(
                                        color: Colors.red,
                                        shape: BoxShape.circle,
                                      ),
                                      constraints: BoxConstraints(
                                        minWidth:
                                            MediaQuery.of(context).size.width *
                                                0.045,
                                        minHeight:
                                            MediaQuery.of(context).size.width *
                                                0.045,
                                      ),
                                      child: Center(
                                        child: Text(
                                          '${controller.count.toString()}',
                                          style: TextStyle(
                                            color: Colors.white,
                                            fontSize: MediaQuery.of(context)
                                                    .size
                                                    .width *
                                                0.03,
                                            fontWeight: FontWeight.bold,
                                          ),
                                        ),
                                      ),
                                    ),
                                  ),
                              ],
                            ))

                        //  Directionality(
                        //   key: ValueKey(controller.currentpage.value),
                        //   textDirection: TextDirection.ltr,
                        //   child: Container(
                        //     height: 85,
                        //     child: Stack(
                        //       children: [
                        //         Positioned(
                        //           bottom: 0,
                        //           left: 0,
                        //           right: 0,
                        //           child: Container(
                        //             decoration: BoxDecoration(
                        //               borderRadius: BorderRadius.only(
                        //                   topLeft: Radius.circular(35),
                        //                   topRight: Radius.circular(35)),
                        //               color: Color(0xFF45C1A6),
                        //             ),
                        //             height: 60,
                        //             child: Row(
                        //               mainAxisAlignment:
                        //                   MainAxisAlignment.spaceAround,
                        //               children: List.generate(
                        //                   controller.listIcons.length,
                        //                   (index) {
                        //                 return _buildBottomBarItem(index);
                        //               }),
                        //             ),
                        //           ),
                        //         ),
                        //         AnimatedPositioned(
                        //           duration: Duration(milliseconds: 200),
                        //           curve: Curves.easeInOut,
                        //           bottom: 22,
                        //           left: MediaQuery.of(context).size.width /
                        //                   5.4 *
                        //                   controller.currentpage.value +
                        //               (MediaQuery.of(context).size.width /
                        //                           5 -
                        //                       60) /
                        //                   2,
                        //           child: Container(
                        //             width:
                        //                 MediaQuery.of(context).size.width *
                        //                     0.15,
                        //             height:
                        //                 MediaQuery.of(context).size.width *
                        //                     0.15,
                        //             decoration: BoxDecoration(
                        //               boxShadow: [
                        //                 BoxShadow(
                        //                     color: Colors.black
                        //                         .withOpacity(0.5),
                        //                     spreadRadius: 0,
                        //                     offset: const Offset(0, 3),
                        //                     blurRadius: 5)
                        //               ],
                        //               shape: BoxShape.circle,
                        //               color: Colors.white,
                        //             ),
                        //             child: Icon(
                        //               controller.listIcons[
                        //                   controller.currentpage.value],
                        //               color: Color(0xFFF7C633),
                        //               size: 30,
                        //             ),
                        //           ),
                        //         ),
                        //       ],
                        //     ),
                        //   ),
                        // )
                        //  Stack(
                        //   children: [
                        //     Container(
                        //       height: 65,
                        //       color: AppColors.basicColor,
                        //       child: Row(
                        //           mainAxisAlignment:
                        //               MainAxisAlignment.spaceAround,
                        //           children: List.generate(
                        //               controller.listConvex.length, (index) {
                        //             return GestureDetector(
                        //               onTap: () {
                        //                 setState(() {
                        //                   controller.changePage(index);
                        //                 });
                        //                 try {
                        //                   controller.indexScreen.value =
                        //                       index;
                        //                   controller.update();
                        //                   CartControllers controllers =
                        //                       Get.find();
                        //                   controllers.isCheckDiscount.value =
                        //                       false;
                        //                   controllers.discountId.value = '';
                        //                   controllers.isCheckDiscount.value =
                        //                       false;
                        //                   controllers.discount.clear();
                        //                 } catch (E) {
                        //                   print(E);
                        //                 }
                        //               },
                        //          child:
                        // Stack(
                        //                 children: [
                        //                   if (controller.currentpage.value ==
                        //                       index)
                        //                     Positioned(
                        //                       bottom: 10,
                        //                       child: Container(
                        //                         margin: const EdgeInsets.only(
                        //                             top: 4.0),
                        //                         width: 70,
                        //                         height: 70,
                        //                         decoration: BoxDecoration(
                        //                           boxShadow: [
                        //                             BoxShadow(
                        //                                 color: Colors.black
                        //                                     .withOpacity(0.5),
                        //                                 spreadRadius: 0,
                        //                                 offset: const Offset(
                        //                                     0, 3),
                        //                                 blurRadius: 5)
                        //                           ],
                        //                           shape: BoxShape.circle,
                        //                           color: Colors.white,
                        //                           // boxShadow: [
                        //                           //   BoxShadow(
                        //                           //     color: Colors.grey.withOpacity(0.5),
                        //                           //     blurRadius: 3,
                        //                           //     spreadRadius: 2,
                        //                           //   ),
                        //                           // ],
                        //                         ),
                        //                       ),
                        //                     ),
                        //                   Stack(
                        //                     children: [
                        //                       Container(
                        //                         margin:
                        //                             EdgeInsets.only(top: 5),
                        //                         width: 52,
                        //                         height: 52,
                        //                         child: Center(
                        //                           child: Icon(
                        //                             size: 25,
                        //                             controller.getIcon(index),
                        //                             color: controller
                        //                                         .currentpage
                        //                                         .value ==
                        //                                     index
                        //                                 ? AppColors
                        //                                     .secondaryColor3
                        //                                 : const Color
                        //                                     .fromARGB(255,
                        //                                     255, 255, 255),
                        //                           ),
                        //                         ),
                        //                       ),
                        //                       if (controller.count.value !=
                        //                               0 &&
                        //                           index == 1)
                        //                         Padding(
                        //                           padding:
                        //                               const EdgeInsets.only(
                        //                                   right: 5.0,
                        //                                   left: 40,
                        //                                   top: 7),
                        //                           child: Container(
                        //                               margin: EdgeInsets.only(
                        //                                   right: 0),
                        //                               child: CircleAvatar(
                        //                                 radius: 7,
                        //                                 backgroundColor:
                        //                                     AppColors
                        //                                         .secondaryColor2,
                        //                                 child: Text(
                        //                                   controller
                        //                                       .count.value
                        //                                       .toString(),
                        //                                   style: TextStyle(
                        //                                       fontWeight:
                        //                                           FontWeight
                        //                                               .bold,
                        //                                       color: AppColors
                        //                                           .readColor,
                        //                                       fontSize: 13),
                        //                                 ),
                        //                               )),
                        //                         ),
                        //                     ],
                        //                   ),
                        //                 ],
                        //               ),
                        //             );
                        //           })),
                        //     ),
                        //   ],
                        // ),

                        //  BottomBarBubble(

                        //     backgroundColor: AppColors.basicColor,
                        //     color: AppColors.secondaryColor3,
                        //     key: ValueKey(controller.indexScreen.value),
                        //     bubbleSize: 60,
                        //     // lable:controller.count>0?controller.count.toString():null,
                        //     selectedIndex: controller.indexScreen.value,
                        //     items: controller.listConvex,
                        //     onSelect: (index) {
                        //       print(index);
                        //       try {
                        //         controller.indexScreen.value = index;
                        //         controller.update();
                        //         CartControllers controllers = Get.find();
                        //         controllers.isCheckDiscount.value = false;
                        //         controllers.discountId.value = '';
                        //         controllers.isCheckDiscount.value = false;
                        //         controllers.discount.clear();
                        //       } catch (E) {
                        //         print(E);
                        //       }
                        //     }),
                        //     )),
                        //    ),
                        //    ))

                        //  )
                        //   );

                        // Widget bottomNavigationBar() {
                        //   return Directionality(
                        //     textDirection: TextDirection.ltr,
                        //     child: BottomBarBubble(
                        //         backgroundColor: AppColors.basicColor,
                        //         color: AppColors.secondaryColor3,
                        //         bubbleSize: 15,
                        //         // lable:controller.count>0?controller.count.toString():null,
                        //         selectedIndex: controller.indexScreen.value,
                        //         items: controller.listConvex,
                        //         onSelect: (index) {
                        //           print(index);
                        //           try {
                        //             controller.indexScreen.value = index;
                        //             controller.update();
                        //             CartControllers controllers = Get.find();
                        //             controllers.isCheckDiscount.value = false;
                        //             controllers.discountId.value = '';
                        //             controllers.isCheckDiscount.value = false;
                        //             controllers.discount.clear();
                        //           } catch (E) {
                        //             print(E);
                        //           }
                        //         }),

                        //   )
                        //  ListView.builder(
                        //         itemCount: controller.listConvex.length,
                        //         scrollDirection: Axis.horizontal,
                        //         padding: EdgeInsets.only(right: Get.width * .02,left:Get.width * .05 ),
                        //         itemBuilder: (context, index) => InkWell(
                        //           onTap: () {
                        //               controller.indexScreen.value = index;
                        //               HapticFeedback.lightImpact();
                        //               controller.update();
                        //               try{
                        //                 CartControllers controllers = Get.find();
                        //                 controllers.isCheckDiscount.value=false;
                        //                 controllers.discountId.value='';
                        //                 controllers.isCheckDiscount.value=false;
                        //                 controllers.discount.clear();
                        //               }
                        //               catch(E){
                        //
                        //               }
                        //           },
                        //           splashColor: Colors.transparent,
                        //           highlightColor: Colors.transparent,
                        //           child: Stack(
                        //             children: [
                        //               AnimatedContainer(
                        //                 duration: const Duration(seconds: 1),
                        //                 curve: Curves.fastLinearToSlowEaseIn,
                        //                 width: index == controller.indexScreen.value
                        //                     ?controller.listConvex[index].title.tr.length>=9? Get.width * .4 :  Get.width * .30
                        //                     : Get.width * .16,
                        //                 alignment: Alignment.center,
                        //                 child: AnimatedContainer(
                        //                   duration: const Duration(seconds: 1),
                        //                   curve: Curves.fastLinearToSlowEaseIn,
                        //                   height: index == controller.indexScreen.value ? Get.width * .09 : 0,
                        //                   width: index == controller.indexScreen.value ? controller.listConvex[index].title.tr.length>=9? Get.width * .33 : Get.width * .30 : 0,
                        //                   decoration: BoxDecoration(
                        //                     color: index == controller.indexScreen.value
                        //                         ?  Colors.white
                        //                         : Colors.transparent,
                        //                     borderRadius: BorderRadius.circular(25),
                        //                   ),
                        //                 ),
                        //               ),
                        //               AnimatedContainer(
                        //                 duration: const Duration(seconds: 1),
                        //                 curve: Curves.fastLinearToSlowEaseIn,
                        //                 width: index == controller.indexScreen.value
                        //                     ? Get.width * .35
                        //                     : Get.width * .15,
                        //                 alignment: Alignment.center,
                        //                 child: Stack(
                        //                   children: [
                        //                     Row(
                        //                       children: [
                        //                         AnimatedContainer(
                        //                           duration: const Duration(seconds: 1),
                        //                           curve: Curves.fastLinearToSlowEaseIn,
                        //                           width:
                        //                           index == controller.indexScreen.value ?  controller.listConvex[index].title.tr.length>=9? Get.width * .09 :Get.width * .12 : 0,
                        //                         ),
                        //                         AnimatedOpacity(
                        //                           opacity: index == controller.indexScreen.value ? 1 : 0,
                        //                           duration: const Duration(seconds: 1),
                        //                           curve: Curves.fastLinearToSlowEaseIn,
                        //                           child: Text(
                        //                             index == controller.indexScreen.value
                        //                                 ? controller.listConvex[index].title.tr
                        //                                 : '',
                        //                             style: const TextStyle(
                        //                               color: AppColors.grayColor,
                        //                               fontWeight: FontWeight.w700,
                        //                               fontSize: 14,
                        //                             ),
                        //                           ),
                        //                         ),
                        //                       ],
                        //                     ),
                        //                     Row(
                        //                       children: [
                        //                         AnimatedContainer(
                        //                           duration: const Duration(seconds: 1),
                        //                           curve: Curves.fastLinearToSlowEaseIn,
                        //                           width:
                        //                           index == controller.indexScreen.value ? controller.listConvex[index].title.tr.length>=9? Get.width * .04 : Get.width * .06 : 10,
                        //                         ),
                        //                         Icon(
                        //                           controller.listConvex[index].icon,
                        //                           size: Get.width * .050,
                        //                           color: index == controller.indexScreen.value
                        //                               ? AppColors.secondaryColor
                        //                               : Colors.white,
                        //                         ),
                        //                       ],
                        //                     ),
                        //                   ],
                        //                 ),
                        //               ),
                        //             ],
                        //           ),
                        //         ),
                        //       ),
                        //   ;
                        // }
                        )))));
  }

  Widget _buildBottomBarItem(int index) {
    return Stack(
      // alignment: Alignment.center,
      children: [
        IconButton(
          icon: Icon(
            size: controller.currentpage.value == index ? 30 : 30,
            controller.listIcons[index],
            color: controller.currentpage.value == index
                ? Colors.transparent
                : Colors.white,
          ),
          onPressed: () {
            setState(() {
              controller.changePage(index);
            });
            try {
              controller.update();
              CartControllers controllers = Get.find();
              controllers.isCheckDiscount.value = false;
              controllers.discountId.value = '';
              controllers.isCheckDiscount.value = false;
              controllers.discount.clear();
            } catch (E) {
              print(E);
            }
          },
        ),
        if (controller.currentpage.value == index)
          Container(
            width: 60,
            height: 20,
            color: Color(0xFF45C1A6), // لإخفاء الأيقونة تحت الزر
          ),
      ],
    );
  }
}
