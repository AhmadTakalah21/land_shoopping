import 'dart:convert';

import 'package:bottom_bar_matu/bottom_bar_item.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get_rx/get_rx.dart';
import 'package:shopping_land/Model/Model/CartModel.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Controllers/CartControllers.dart';
import 'package:shopping_land/Services/helper/status_bar.dart';
import 'package:get/get.dart';
import 'package:permission_handler/permission_handler.dart' as permission;
import 'package:shopping_land/ALConstants/ALMethode.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/Model/Model/Agent.dart';
import 'package:shopping_land/Model/Model/Category.dart';
import 'package:shopping_land/Model/Model/Cities.dart';
import 'package:shopping_land/Pages/SignUp/Repositories/SingUpRepositories.dart';
import 'package:shopping_land/main.dart';

class MainScreenViewControllers extends GetxController {
  RxString count = ''.obs;
  late List<BottomBarItem> listConvex = [];
  late List<IconData> listIcons = [];
  RxList<Agent> agent = <Agent>[].obs;
  RxList<Cities> cities = <Cities>[].obs;

  final CartControllers cartController = CartControllers();
  RxList<Category> category = <Category>[].obs;
  RxString citiesName = ''.obs;
  RxInt currentpage = 0.obs;

  MainScreenViewControllers() {
    Get.put(() => CartControllers());
    listConvex = [
      BottomBarItem(
        iconSize: 25,
        iconData: CupertinoIcons.home,
      ),
      BottomBarItem(iconSize: 25, iconData: CupertinoIcons.square_grid_2x2),
      BottomBarItem(iconSize: 25, iconData: Icons.favorite_border),
      BottomBarItem(iconSize: 25, iconData: CupertinoIcons.cart),
      BottomBarItem(
        iconSize: 25,
        iconData: CupertinoIcons.person,
      ),
    ];

    listIcons = [
      CupertinoIcons.person,
      CupertinoIcons.cart,
      Icons.favorite_border,
      CupertinoIcons.square_grid_2x2,
      CupertinoIcons.home
    ];
  }

  Future<void> display_all_cities() async {
    SingUpRepositories repositories = SingUpRepositories();
    if (await repositories.display_all_cities(countryId: '1')) {
      if (repositories.message.data != null) {
        var data = json.decode(json.decode(repositories.message.data));
        cities.value = dataCitiesFromJson(json.encode(data['cities']));
        citiesName.value = cities.first.name.toString();
        alSettings.citiesId.value = cities.first.id.toString();
        if (alSettings.currentUser != null) {
          alSettings.currentUser!.citiesId = alSettings.citiesId.value;
          ALMethode.setUserInfo(data: alSettings.currentUser!);
        }
        update();
      }
    }
  }

  Future<void> count_item_in_cart() async {
    SingUpRepositories repositories = SingUpRepositories();
    if (await repositories.count_item_in_cart(countryId: '1')) {
      if (repositories.message.data != null) {
        var data = json.decode(json.decode(repositories.message.data));
        count.value = data['count_item'];
        update();
      }
    }
  }

  // int getTotalCartQuantity() {
  //   int totalQuantity = 0;
  //   for (CartModel cartModel in cartController.carts) {
  //     if (cartModel.carts != null) {
  //       for (Carts cart in cartModel.carts!) {
  //         totalQuantity += cart.quantity ?? 0;
  //       }
  //     }
  //   }

  //   return totalQuantity;
  // }

  @override
  void onInit() {
    // TODO: implement onInit
    super.onInit();

    Future.delayed(Duration(seconds: 1), () async {
      permission.Permission.notification.request();
      FlutterStatusbarcolor.setNavigationBarColor(AppColors.basicColor);
      FlutterStatusbarcolor.setStatusBarColor(AppColors.basicColor);
    });
    display_all_cities();
    count_item_in_cart();
  }

  changePage(int i) {
    currentpage.value = i;
    update();
  }

  IconData getIcon(int index) {
    switch (index) {
      case 4:
        return CupertinoIcons.home;
      case 3:
        return CupertinoIcons.square_grid_2x2;
      case 2:
        return Icons.favorite_border;
      case 1:
        return CupertinoIcons.cart;
      case 0:
        return CupertinoIcons.person;
      default:
        return CupertinoIcons.home;
    }
  }
}
