import 'package:get/get.dart';
import 'package:shopping_land/Pages/BuildScreens/Cart/Controllers/CartControllers.dart';

class MainScreenViewBinding extends Bindings {
  @override
  void dependencies() {
    Get.put<MainScreenViewBinding>(MainScreenViewBinding());
    
    // Get.put(() => CartControllers());
  }
}
