


import 'dart:async';

import 'package:extended_image/extended_image.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:shopping_land/Services/helper/status_bar.dart';
import 'package:get/get.dart';
import 'package:shopping_land/ALConstants/AppColors.dart';
import 'package:shopping_land/Pages/MainScreenView/Views/MainScreenView.dart';
import 'package:shopping_land/Pages/WelcomePage/WelcomePage.dart';
import 'package:shopping_land/main.dart';


class SplashScreen extends StatefulWidget  {
  @override
  _SplashScreenState createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>  with TickerProviderStateMixin{
  // late GifController controller1;

  @override
  void initState() {
    super.initState();
    // controller1=GifController(vsync: this);
      Future.delayed(Duration(seconds: 2),(){
        if(alSettings.currentUser==null)
          {
            FlutterStatusbarcolor.setNavigationBarColor(AppColors.secondaryColor3);
            FlutterStatusbarcolor.setStatusBarColor(AppColors.secondaryColor3);

          }
        else
          {
            FlutterStatusbarcolor.setNavigationBarColor(AppColors.basicColor);
            FlutterStatusbarcolor.setStatusBarColor(AppColors.basicColor);

          }
        Get.offAll(() =>alSettings.currentUser!=null?  MainScreenView() :const WelcomePage());
      });



  }

  @override
  void dispose() {
// TODO: implement dispose
    super.dispose();
  }


  @override
  Widget build(BuildContext context) {
    return AnnotatedRegion<SystemUiOverlayStyle>(
        value: const SystemUiOverlayStyle(
        statusBarIconBrightness: Brightness.light,
        statusBarBrightness:Brightness.light,
        systemNavigationBarIconBrightness: Brightness.light,
        systemNavigationBarColor: AppColors.basicColor,
        statusBarColor: AppColors.basicColor,
        systemNavigationBarDividerColor: AppColors.basicColor
    ),
    child: Material(
    color: AppColors.basicColor,
    child: ExtendedImage.asset(
        'assets/splash.png',
      fit: BoxFit.cover,
      height: Get.height,
      width: Get.width,
    )));
  }
}











class ThisIsFadeRoute extends PageRouteBuilder {
  Widget? page;
  final Widget route;

  ThisIsFadeRoute({this.page, required this.route})
      : super(
    pageBuilder: (
        BuildContext context,
        Animation<double> animation,
        Animation<double> secondaryAnimation,
        ) =>
    page!,
    transitionsBuilder: (
        BuildContext context,
        Animation<double> animation,
        Animation<double> secondaryAnimation,
        Widget child,
        ) =>
        FadeTransition(
          opacity: animation,
          child: route,
        ),
  );
}
