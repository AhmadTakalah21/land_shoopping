package com.example.shopping_land

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
