package com.levant.shoppingland.client

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
